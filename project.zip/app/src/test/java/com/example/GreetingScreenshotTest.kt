package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.settings.AppThemeMode
import com.example.data.settings.GroupingMode
import com.example.data.settings.SortMode
import com.example.data.settings.ViewMode
import com.example.ui.components.EveTopBar
import com.example.ui.theme.EveTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      EveTheme(themeMode = AppThemeMode.AMOLED) {
        EveTopBar(
          isScanning = false,
          selectedCount = 0,
          viewMode = ViewMode.GRID,
          groupingMode = GroupingMode.BY_NAME,
          sortMode = SortMode.NAME,
          sortAscending = true,
          onSearchClick = {},
          onToggleViewMode = {},
          onSetGrouping = {},
          onSetSort = {},
          onToggleSortAscending = {},
          onRefresh = {},
          onClearSelection = {},
          onPlaySelected = {},
          onAppendSelected = {},
          onDeleteSelected = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
