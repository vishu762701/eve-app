package com.example

import android.app.Application
import com.example.data.db.AppDatabase
import com.example.data.media.MediaStoreScanner
import com.example.data.settings.SettingsRepository
import com.example.playback.MediaPlaybackManager

class EveApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var playbackManager: MediaPlaybackManager
        private set

    lateinit var mediaScanner: MediaStoreScanner
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        playbackManager = MediaPlaybackManager(this)
        mediaScanner = MediaStoreScanner(this)
    }

    override fun onTerminate() {
        playbackManager.release()
        super.onTerminate()
    }
}
