package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.data.settings.AppThemeMode

val LocalEveIconTint = staticCompositionLocalOf { IconTintDark }
val LocalEveTrackInactive = staticCompositionLocalOf { TrackInactiveDark }

private val AmoledColorScheme = darkColorScheme(
    primary = EveAccent,
    onPrimary = Color.White,
    primaryContainer = Color(0x33FF0000),
    onPrimaryContainer = EveAccent,
    secondary = EveAccent,
    onSecondary = Color.White,
    background = AmoledBackground,
    onBackground = AmoledOnSurface,
    surface = AmoledSurface,
    onSurface = AmoledOnSurface,
    surfaceVariant = AmoledSurfaceVariant,
    onSurfaceVariant = AmoledOnSurfaceVariant,
    outline = Color(0x33A0A0AB)
)

private val DarkEveColorScheme = darkColorScheme(
    primary = EveAccent,
    onPrimary = Color.White,
    primaryContainer = Color(0x33FF0000),
    onPrimaryContainer = EveAccent,
    secondary = EveAccent,
    onSecondary = Color.White,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = Color(0x33A0A0AB)
)

private val LightEveColorScheme = lightColorScheme(
    primary = EveAccent,
    onPrimary = Color.White,
    primaryContainer = Color(0x22FF0000),
    onPrimaryContainer = EveAccent,
    secondary = EveAccent,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = Color(0x335A5A66)
)

@Composable
fun EveTheme(
    themeMode: AppThemeMode = AppThemeMode.AMOLED,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        AppThemeMode.AMOLED -> true
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme: ColorScheme = when (themeMode) {
        AppThemeMode.AMOLED -> AmoledColorScheme
        AppThemeMode.DARK -> DarkEveColorScheme
        AppThemeMode.LIGHT -> LightEveColorScheme
        AppThemeMode.SYSTEM -> if (isDark) DarkEveColorScheme else LightEveColorScheme
    }

    val iconTint = if (isDark) IconTintDark else IconTintLight
    val trackInactive = if (isDark) TrackInactiveDark else TrackInactiveLight

    CompositionLocalProvider(
        LocalEveIconTint provides iconTint,
        LocalEveTrackInactive provides trackInactive
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
