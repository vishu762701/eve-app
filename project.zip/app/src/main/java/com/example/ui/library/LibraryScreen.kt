package com.example.ui.library

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.local.PlaylistEntity
import com.example.data.mediastore.MediaItemModel
import com.example.player.MediaPlaybackManager
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.CreatePlaylistDialog
import com.example.ui.components.EqualizerBottomSheet
import com.example.ui.components.MiniPlayer
import com.example.ui.components.SleepTimerDialog
import com.example.ui.components.SortBottomSheet
import com.example.ui.theme.EveRedPrimary
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class MainNavTab(val title: String, val icon: ImageVector) {
    VIDEO("Video", Icons.Default.Movie),
    AUDIO("Audio", Icons.Default.Audiotrack),
    BROWSE("Browse", Icons.Default.Folder),
    PLAYLISTS("Playlists", Icons.Default.PlaylistPlay),
    MORE("More", Icons.Default.MoreHoriz)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    playbackManager: MediaPlaybackManager,
    onNavigateToVideoPlayer: (MediaItemModel) -> Unit,
    onNavigateToAudioPlayer: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current

    // Android 13+ runtime permissions check including POST_NOTIFICATIONS
    val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS
        )
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    var hasPermissions by remember {
        mutableStateOf(
            requiredPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasPermissions = results.values.any { it }
        if (hasPermissions) {
            viewModel.refreshLibrary()
        }
    }

    LaunchedEffect(hasPermissions) {
        if (hasPermissions) {
            viewModel.refreshLibrary()
        }
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var isSearchActive by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val userSettings by viewModel.userSettings.collectAsState()

    val videos by viewModel.videos.collectAsState()
    val audios by viewModel.audios.collectAsState()
    val videoFolders by viewModel.videoFolders.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val history by viewModel.history.collectAsState()
    val favorites by viewModel.favorites.collectAsState()

    // Multi-select state
    var selectedMediaItems by remember { mutableStateOf<Set<MediaItemModel>>(emptySet()) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    // Video grouping state
    var videoGrouping by remember { mutableStateOf(VideoGrouping.NONE) }

    // Player states
    val currentMedia by playbackManager.currentMediaItem.collectAsState()
    val isPlaying by playbackManager.isPlaying.collectAsState()
    val currentPosition by playbackManager.currentPosition.collectAsState()
    val duration by playbackManager.duration.collectAsState()
    val equalizerState by playbackManager.equalizerState.collectAsState()
    val sleepTimerSec by playbackManager.sleepTimerRemainingSeconds.collectAsState()

    // Dialog & Sheet states
    var showSortSheet by remember { mutableStateOf(false) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var mediaItemsForPlaylist by remember { mutableStateOf<List<MediaItemModel>?>(null) }

    // Clear selection on tab change
    LaunchedEffect(selectedTab) {
        selectedMediaItems = emptySet()
    }

    val handleShare: (MediaItemModel) -> Unit = { item ->
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = item.mimeType
                putExtra(Intent.EXTRA_STREAM, item.uri)
                putExtra(Intent.EXTRA_SUBJECT, item.title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share ${item.title}"))
        } catch (e: Exception) {
            android.util.Log.e("LibraryScreen", "Failed to share media", e)
        }
    }

    // Floating Play Button action (Video or Audio tab: plays all / continues last item)
    val handleFloatingPlay: () -> Unit = {
        if (selectedTab == MainNavTab.VIDEO.ordinal) {
            if (videos.isNotEmpty()) {
                // Find last watched video or default to first
                val continueItem = videos.maxByOrNull { it.lastPositionMs } ?: videos.first()
                playbackManager.playMedia(continueItem, newQueue = videos)
                onNavigateToVideoPlayer(continueItem)
            }
        } else if (selectedTab == MainNavTab.AUDIO.ordinal) {
            if (audios.isNotEmpty()) {
                val continueItem = audios.first()
                playbackManager.playMedia(continueItem, newQueue = audios)
                onNavigateToAudioPlayer()
            }
        }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(top = 4.dp)
            ) {
                if (selectedMediaItems.isNotEmpty()) {
                    // Multi-select contextual top app bar
                    TopAppBar(
                        navigationIcon = {
                            IconButton(onClick = { selectedMediaItems = emptySet() }) {
                                Icon(Icons.Default.Close, contentDescription = "Close Selection")
                            }
                        },
                        title = {
                            Text(
                                "${selectedMediaItems.size} selected",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        actions = {
                            // Select All
                            IconButton(onClick = {
                                val currentItems = if (selectedTab == MainNavTab.VIDEO.ordinal) videos else audios
                                selectedMediaItems = currentItems.toSet()
                            }) {
                                Icon(Icons.Default.SelectAll, contentDescription = "Select All")
                            }

                            // Play selected
                            IconButton(onClick = {
                                val queue = selectedMediaItems.toList()
                                if (queue.isNotEmpty()) {
                                    val first = queue.first()
                                    playbackManager.playMedia(first, newQueue = queue)
                                    if (first.isVideo) {
                                        onNavigateToVideoPlayer(first)
                                    } else {
                                        onNavigateToAudioPlayer()
                                    }
                                }
                                selectedMediaItems = emptySet()
                            }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play Selected")
                            }

                            // Add to Queue
                            IconButton(onClick = {
                                selectedMediaItems.forEach { playbackManager.addToQueueNext(it) }
                                selectedMediaItems = emptySet()
                            }) {
                                Icon(Icons.Default.PlaylistAdd, contentDescription = "Add to Queue")
                            }

                            // Add to Playlist
                            IconButton(onClick = {
                                mediaItemsForPlaylist = selectedMediaItems.toList()
                            }) {
                                Icon(Icons.Default.PlaylistPlay, contentDescription = "Add to Playlist")
                            }

                            // Delete selected
                            IconButton(onClick = {
                                showDeleteConfirmDialog = true
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Selected", tint = EveRedPrimary)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                } else {
                    // Standard Top Bar: logo + "eve" on left, search and overflow on right
                    TopAppBar(
                        title = {
                            if (!isSearchActive) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_eve_logo),
                                        contentDescription = "eve logo",
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.Black)
                                            .padding(2.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        "eve",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                }
                            } else {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { viewModel.setSearchQuery(it) },
                                    placeholder = { Text("Search media...") },
                                    singleLine = true,
                                    trailingIcon = {
                                        if (searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                                            }
                                        }
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = EveRedPrimary,
                                        unfocusedBorderColor = Color.Transparent
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = {
                                isSearchActive = !isSearchActive
                                if (!isSearchActive) viewModel.setSearchQuery("")
                            }) {
                                Icon(
                                    imageVector = if (isSearchActive) Icons.Default.Clear else Icons.Default.Search,
                                    contentDescription = "Search"
                                )
                            }

                            // Overflow Menu (Sort by, Grid/List, Group by, Refresh)
                            Box {
                                IconButton(onClick = { showOverflowMenu = true }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "More options")
                                }

                                DropdownMenu(
                                    expanded = showOverflowMenu,
                                    onDismissRequest = { showOverflowMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Sort by") },
                                        leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null) },
                                        onClick = {
                                            showOverflowMenu = false
                                            showSortSheet = true
                                        }
                                    )

                                    if (selectedTab == MainNavTab.VIDEO.ordinal) {
                                        DropdownMenuItem(
                                            text = { Text(if (userSettings.isVideoGridView) "List view" else "Grid view") },
                                            leadingIcon = {
                                                Icon(
                                                    if (userSettings.isVideoGridView) Icons.Default.ViewList else Icons.Default.GridView,
                                                    contentDescription = null
                                                )
                                            },
                                            onClick = {
                                                showOverflowMenu = false
                                                viewModel.toggleVideoGridView()
                                            }
                                        )

                                        DropdownMenuItem(
                                            text = { Text(if (videoGrouping == VideoGrouping.FOLDER) "Group by: None" else "Group by: Folders") },
                                            leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null) },
                                            onClick = {
                                                showOverflowMenu = false
                                                videoGrouping = if (videoGrouping == VideoGrouping.FOLDER) VideoGrouping.NONE else VideoGrouping.FOLDER
                                            }
                                        )
                                    }

                                    DropdownMenuItem(
                                        text = { Text("Refresh") },
                                        leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) },
                                        onClick = {
                                            showOverflowMenu = false
                                            viewModel.refreshLibrary()
                                        }
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    )
                }

                // Thin indeterminate progress bar under top bar while scanning media
                if (isScanning) {
                    LinearProgressIndicator(
                        color = EveRedPrimary,
                        trackColor = Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.5.dp)
                    )
                }
            }
        },
        bottomBar = {
            Column(modifier = Modifier.navigationBarsPadding()) {
                // Mini Player sits directly above the bottom bar
                MiniPlayer(
                    currentMedia = currentMedia,
                    isPlaying = isPlaying,
                    currentPosition = currentPosition,
                    duration = duration,
                    onTogglePlayPause = { playbackManager.togglePlayPause() },
                    onPlayNext = { playbackManager.playNext() },
                    onClick = {
                        if (currentMedia?.isVideo == true) {
                            currentMedia?.let { onNavigateToVideoPlayer(it) }
                        } else {
                            onNavigateToAudioPlayer()
                        }
                    }
                )

                // 5 items in this order: Video, Audio, Browse, Playlists, More
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp
                ) {
                    MainNavTab.entries.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = EveRedPrimary,
                                selectedTextColor = EveRedPrimary,
                                indicatorColor = EveRedPrimary.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!hasPermissions) {
                // Permission Request State
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = CircleShape,
                        color = EveRedPrimary.copy(alpha = 0.15f),
                        modifier = Modifier.size(80.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = null,
                                tint = EveRedPrimary,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        "Permission Required",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "eve is a private, offline media player and needs storage access to find video and audio files on your device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { permissionLauncher.launch(requiredPermissions) },
                        colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary)
                    ) {
                        Text("Grant Storage Permission")
                    }
                }
            } else {
                // 5 Tabs Content
                when (MainNavTab.entries[selectedTab]) {
                    MainNavTab.VIDEO -> {
                        VideoTabContent(
                            videos = videos,
                            videoFolders = videoFolders,
                            isGridView = userSettings.isVideoGridView,
                            onToggleGridView = { viewModel.toggleVideoGridView() },
                            onOpenSort = { showSortSheet = true },
                            onRefresh = { viewModel.refreshLibrary() },
                            isScanning = isScanning,
                            grouping = videoGrouping,
                            onGroupingChanged = { videoGrouping = it },
                            selectedMediaItems = selectedMediaItems,
                            onToggleSelectMedia = { item ->
                                selectedMediaItems = if (selectedMediaItems.contains(item)) {
                                    selectedMediaItems - item
                                } else {
                                    selectedMediaItems + item
                                }
                            },
                            onStartMultiSelect = { item ->
                                selectedMediaItems = selectedMediaItems + item
                            },
                            onPlayVideo = { item, queue ->
                                playbackManager.playMedia(item, newQueue = queue)
                                onNavigateToVideoPlayer(item)
                            },
                            onPlayNext = { playbackManager.addToQueueNext(it) },
                            onAddToPlaylist = { mediaItemsForPlaylist = listOf(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onShare = handleShare,
                            onDelete = { viewModel.deleteMedia(it) },
                            getFolderVideos = { folderName ->
                                viewModel.getMediaInFolder(folderName, true)
                            }
                        )
                    }

                    MainNavTab.AUDIO -> {
                        AudioTabContent(
                            audios = audios,
                            playlists = playlists,
                            selectedMediaItems = selectedMediaItems,
                            onToggleSelectMedia = { item ->
                                selectedMediaItems = if (selectedMediaItems.contains(item)) {
                                    selectedMediaItems - item
                                } else {
                                    selectedMediaItems + item
                                }
                            },
                            onStartMultiSelect = { item ->
                                selectedMediaItems = selectedMediaItems + item
                            },
                            onPlayAudio = { item, queue ->
                                playbackManager.playMedia(item, newQueue = queue)
                                onNavigateToAudioPlayer()
                            },
                            onPlayNext = { playbackManager.addToQueueNext(it) },
                            onAddToPlaylist = { mediaItemsForPlaylist = listOf(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onShare = handleShare,
                            onDelete = { viewModel.deleteMedia(it) },
                            onShuffleAll = { tracks ->
                                if (tracks.isNotEmpty()) {
                                    val shuffled = tracks.shuffled()
                                    playbackManager.playMedia(shuffled.first(), newQueue = shuffled)
                                    onNavigateToAudioPlayer()
                                }
                            },
                            onRefresh = { viewModel.refreshLibrary() },
                            isScanning = isScanning,
                            onOpenPlaylist = {
                                selectedTab = MainNavTab.PLAYLISTS.ordinal
                            }
                        )
                    }

                    MainNavTab.BROWSE -> {
                        BrowseTabContent(
                            onPlayMedia = { item ->
                                playbackManager.playMedia(item)
                                if (item.isVideo) {
                                    onNavigateToVideoPlayer(item)
                                } else {
                                    onNavigateToAudioPlayer()
                                }
                            },
                            browsePath = { path ->
                                viewModel.browseStorage(path)
                            }
                        )
                    }

                    MainNavTab.PLAYLISTS -> {
                        val historyList = remember(history, videos, audios) {
                            val allMedia = (videos + audios).associateBy { it.uri.toString() }
                            history.mapNotNull { h -> allMedia[h.uri] }
                        }

                        val recentlyAdded = remember(videos, audios) {
                            (videos + audios).sortedByDescending { it.dateAdded }
                        }

                        val favoriteList = remember(favorites, videos, audios) {
                            val allMedia = (videos + audios).associateBy { it.uri.toString() }
                            favorites.mapNotNull { f -> allMedia[f.uri] }
                        }

                        PlaylistsTabContent(
                            playlists = playlists,
                            historyItems = historyList,
                            recentlyAddedItems = recentlyAdded,
                            favoriteItems = favoriteList,
                            onCreatePlaylist = { showCreatePlaylistDialog = true },
                            onRenamePlaylist = { pId, newName ->
                                viewModel.renamePlaylist(pId, newName)
                            },
                            onDeletePlaylist = { pId ->
                                viewModel.deletePlaylist(pId)
                            },
                            onPlayPlaylist = { items, shuffle ->
                                if (items.isNotEmpty()) {
                                    val q = if (shuffle) items.shuffled() else items
                                    val first = q.first()
                                    playbackManager.playMedia(first, newQueue = q)
                                    if (first.isVideo) {
                                        onNavigateToVideoPlayer(first)
                                    } else {
                                        onNavigateToAudioPlayer()
                                    }
                                }
                            },
                            onPlayItem = { item, queue ->
                                playbackManager.playMedia(item, newQueue = queue)
                                if (item.isVideo) {
                                    onNavigateToVideoPlayer(item)
                                } else {
                                    onNavigateToAudioPlayer()
                                }
                            },
                            onPlayNext = { playbackManager.addToQueueNext(it) },
                            onAddToPlaylist = { mediaItemsForPlaylist = listOf(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onShare = handleShare,
                            onDeleteItem = { viewModel.deleteMedia(it) },
                            getPlaylistItems = { pId ->
                                viewModel.getPlaylistItems(pId).first()
                            },
                            onRemoveFromPlaylist = { _, itemId ->
                                viewModel.removePlaylistItem(itemId)
                            },
                            onReorderPlaylist = { pId, from, to ->
                                viewModel.reorderPlaylistItem(pId, from, to)
                            }
                        )
                    }

                    MainNavTab.MORE -> {
                        MoreTabContent(
                            onNavigateToSettings = onNavigateToSettings,
                            onOpenEqualizer = { showEqualizerSheet = true },
                            onOpenSleepTimer = { showSleepTimerDialog = true },
                            onOpenHistory = { selectedTab = MainNavTab.PLAYLISTS.ordinal },
                            sleepTimerSec = sleepTimerSec
                        )
                    }
                }

                // Small round floating play button (bottom-right, above bottom bar) on Video and Audio tabs
                if ((selectedTab == MainNavTab.VIDEO.ordinal && videos.isNotEmpty()) ||
                    (selectedTab == MainNavTab.AUDIO.ordinal && audios.isNotEmpty())
                ) {
                    if (selectedMediaItems.isEmpty()) {
                        SmallFloatingActionButton(
                            onClick = handleFloatingPlay,
                            containerColor = EveRedPrimary,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 16.dp, bottom = 16.dp)
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play all / continue",
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Multi-select Delete Confirmation Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete ${selectedMediaItems.size} items?") },
            text = { Text("These files will be removed from your device storage.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteMultipleMedia(selectedMediaItems.toList())
                        selectedMediaItems = emptySet()
                        showDeleteConfirmDialog = false
                    }
                ) {
                    Text("Delete", color = EveRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Sort Bottom Sheet
    if (showSortSheet) {
        val isVideoTab = selectedTab == MainNavTab.VIDEO.ordinal
        val currentSort = if (isVideoTab) viewModel.videoSortBy.collectAsState().value else viewModel.audioSortBy.collectAsState().value
        val currentAsc = if (isVideoTab) viewModel.videoSortAsc.collectAsState().value else viewModel.audioSortAsc.collectAsState().value

        SortBottomSheet(
            currentSortBy = currentSort,
            currentSortAsc = currentAsc,
            onSortSelected = { sort, asc ->
                if (isVideoTab) {
                    viewModel.setVideoSorting(sort, asc)
                } else {
                    viewModel.setAudioSorting(sort, asc)
                }
                showSortSheet = false
            },
            onDismiss = { showSortSheet = false }
        )
    }

    // Create Playlist Dialog
    if (showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreatePlaylistDialog = false },
            onConfirm = {
                viewModel.createPlaylist(it)
                showCreatePlaylistDialog = false
            }
        )
    }

    // Add to Playlist Dialog
    if (mediaItemsForPlaylist != null) {
        AddToPlaylistDialog(
            playlists = playlists,
            onDismiss = { mediaItemsForPlaylist = null },
            onSelectPlaylist = { pId ->
                mediaItemsForPlaylist?.let { items ->
                    viewModel.addMediaListToPlaylist(pId, items)
                }
                mediaItemsForPlaylist = null
                selectedMediaItems = emptySet()
            },
            onCreateNewPlaylist = {
                showCreatePlaylistDialog = true
            }
        )
    }

    // Equalizer Bottom Sheet
    if (showEqualizerSheet) {
        EqualizerBottomSheet(
            equalizerState = equalizerState,
            onToggleEnabled = { playbackManager.setEqualizerEnabled(it) },
            onBandLevelChange = { index, level -> playbackManager.setEqualizerBandLevel(index, level) },
            onSelectPreset = { playbackManager.useEqualizerPreset(it) },
            onBassBoostChange = { playbackManager.setBassBoostStrength(it) },
            onDismiss = { showEqualizerSheet = false }
        )
    }

    // Sleep Timer Dialog
    if (showSleepTimerDialog) {
        SleepTimerDialog(
            currentRemainingSec = sleepTimerSec,
            onSetTimer = { mins -> playbackManager.startSleepTimer(mins) },
            onCancelTimer = { playbackManager.cancelSleepTimer() },
            onDismiss = { showSleepTimerDialog = false }
        )
    }
}
