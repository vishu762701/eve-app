package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.icons.EveIcons
import com.example.ui.theme.EveAccent
import com.example.ui.theme.LocalEveIconTint

enum class EveTab(val label: String) {
    VIDEO("Video"),
    AUDIO("Audio"),
    BROWSE("Browse"),
    PLAYLISTS("Playlists"),
    MORE("More")
}

@Composable
fun EveBottomNav(
    currentTab: EveTab,
    onTabSelected: (EveTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val unselectedTint = LocalEveIconTint.current.copy(alpha = 0.65f)

    NavigationBar(
        modifier = modifier.windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        EveTab.entries.forEach { tab ->
            val isSelected = currentTab == tab
            val icon = when (tab) {
                EveTab.VIDEO -> EveIcons.Video
                EveTab.AUDIO -> EveIcons.Audio
                EveTab.BROWSE -> EveIcons.Folder
                EveTab.PLAYLISTS -> EveIcons.Playlist
                EveTab.MORE -> EveIcons.More
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.label
                    )
                },
                label = {
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = EveAccent,
                    selectedTextColor = EveAccent,
                    indicatorColor = EveAccent.copy(alpha = 0.16f),
                    unselectedIconColor = unselectedTint,
                    unselectedTextColor = unselectedTint
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
