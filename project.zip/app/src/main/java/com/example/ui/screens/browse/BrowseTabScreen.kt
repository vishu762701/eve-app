package com.example.ui.screens.browse

import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.FavoriteEntity
import com.example.data.model.MediaModel
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.theme.EveAccent
import com.example.ui.theme.LocalEveIconTint
import java.io.File

data class BrowseItem(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val isVideo: Boolean = false,
    val isAudio: Boolean = false,
    val sizeBytes: Long = 0L,
    val itemCount: Int = 0
)

@Composable
fun BrowseTabScreen(
    favorites: List<FavoriteEntity>,
    onAddFavorite: (String, String, Boolean) -> Unit,
    onRemoveFavorite: (String) -> Unit,
    onPlayFile: (String, Boolean) -> Unit,
    allScannedMedia: List<MediaModel>,
    modifier: Modifier = Modifier
) {
    val rootDir = remember { Environment.getExternalStorageDirectory() }
    var currentDir by remember { mutableStateOf(rootDir) }

    // Breadcrumbs path elements
    val breadcrumbs = remember(currentDir) {
        val list = mutableListOf<File>()
        var f: File? = currentDir
        while (f != null && f.path.startsWith(rootDir.path)) {
            list.add(0, f)
            if (f.path == rootDir.path) break
            f = f.parentFile
        }
        if (list.isEmpty()) listOf(rootDir) else list
    }

    // List folder contents safely
    val itemsInDir = remember(currentDir) {
        val files = currentDir.listFiles() ?: emptyArray()
        val dirs = files.filter { it.isDirectory && !it.name.startsWith(".") }
            .sortedBy { it.name.lowercase() }
            .map { dir ->
                val count = dir.listFiles()?.size ?: 0
                BrowseItem(
                    name = dir.name,
                    path = dir.absolutePath,
                    isDirectory = true,
                    itemCount = count
                )
            }

        val mediaFiles = files.filter { it.isFile && !it.name.startsWith(".") }
            .sortedBy { it.name.lowercase() }
            .map { file ->
                val ext = file.extension.lowercase()
                val isVid = ext in listOf("mp4", "mkv", "avi", "webm", "mov", "flv", "3gp")
                val isAud = ext in listOf("mp3", "m4a", "wav", "flac", "ogg", "aac", "opus")
                BrowseItem(
                    name = file.name,
                    path = file.absolutePath,
                    isDirectory = false,
                    isVideo = isVid,
                    isAudio = isAud,
                    sizeBytes = file.length()
                )
            }

        dirs + mediaFiles
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Favorites Row if any
        if (favorites.isNotEmpty()) {
            Text(
                text = "Favorites",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                favorites.forEach { fav ->
                    Card(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                val file = File(fav.uri)
                                if (file.exists() && file.isDirectory) {
                                    currentDir = file
                                } else {
                                    onPlayFile(fav.uri, !fav.isFolder)
                                }
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = EveIcons.Favorite,
                                contentDescription = null,
                                tint = EveAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = fav.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
        }

        // Breadcrumb Row with horizontal scroll (PRD 6.2)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Internal storage",
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (currentDir.path == rootDir.path) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (currentDir.path == rootDir.path) EveAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { currentDir = rootDir }
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            )

            breadcrumbs.drop(1).forEach { crumb ->
                Text(
                    text = " / ",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val isCurrent = crumb.path == currentDir.path
                Text(
                    text = crumb.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                    ),
                    color = if (isCurrent) EveAccent else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { currentDir = crumb }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }

        HorizontalDivider()

        if (itemsInDir.isEmpty()) {
            // If device storage has no files in current folder, provide quick links to MediaStore buckets!
            val buckets = remember(allScannedMedia) {
                allScannedMedia.groupBy { it.bucketName }
            }

            if (buckets.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            text = "Media Folders",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    items(buckets.entries.toList(), key = { it.key }) { (bucketName, items) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    items.firstOrNull()?.let {
                                        onPlayFile(it.uri, it.isVideo)
                                    }
                                }
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = EveIcons.Folder,
                                contentDescription = null,
                                tint = LocalEveIconTint.current,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = bucketName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${items.size} media items",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Folder is empty",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(itemsInDir, key = { it.path }) { item ->
                    var itemMenuExpanded by remember { mutableStateOf(false) }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                if (item.isDirectory) {
                                    currentDir = File(item.path)
                                } else {
                                    onPlayFile(item.path, item.isVideo)
                                }
                            }
                            .padding(vertical = 8.dp, horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val icon = when {
                            item.isDirectory -> EveIcons.Folder
                            item.isVideo -> EveIcons.Video
                            item.isAudio -> EveIcons.Audio
                            else -> EveIcons.More
                        }

                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = LocalEveIconTint.current,
                            modifier = Modifier.size(24.dp)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val subtitle = if (item.isDirectory) {
                                "${item.itemCount} items"
                            } else {
                                "${item.sizeBytes / 1024 / 1024} MB"
                            }
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Box {
                            EveIconButton(
                                imageVector = EveIcons.More,
                                contentDescription = "Options",
                                onClick = { itemMenuExpanded = true },
                                iconSize = 20.dp
                            )

                            DropdownMenu(
                                expanded = itemMenuExpanded,
                                onDismissRequest = { itemMenuExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Add to favorites") },
                                    onClick = {
                                        itemMenuExpanded = false
                                        onAddFavorite(item.path, item.name, item.isDirectory)
                                    }
                                )
                                if (!item.isDirectory) {
                                    DropdownMenuItem(
                                        text = { Text("Play") },
                                        onClick = {
                                            itemMenuExpanded = false
                                            onPlayFile(item.path, item.isVideo)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
