package com.example.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.settings.AppThemeMode
import com.example.data.settings.EveSettings
import com.example.data.settings.GroupingMode
import com.example.data.settings.ResumeMode
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.theme.EveAccent

@Composable
fun SettingsScreen(
    settings: EveSettings,
    onBack: () -> Unit,
    onSetTheme: (AppThemeMode) -> Unit,
    onSetGrouping: (GroupingMode) -> Unit,
    onSetResumeMode: (ResumeMode) -> Unit,
    onSetHudTimeout: (Int) -> Unit,
    onSetJumpAmount: (Int) -> Unit,
    onSetDoubleTapJump: (Int) -> Unit,
    onSetFastPlaySpeed: (Float) -> Unit,
    onSetGesture: (String, Boolean) -> Unit,
    onSetShowThumbnails: (Boolean) -> Unit,
    onSetMediaSeenMarking: (Boolean) -> Unit,
    onSetIncognito: (Boolean) -> Unit,
    onSetAudioDucking: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            EveIconButton(
                imageVector = EveIcons.Back,
                contentDescription = "Back",
                onClick = onBack
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Settings",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 11.1 Interface Settings
            item {
                SettingsSectionHeader("Interface")
                ThemePicker(settings.theme, onSetTheme)
                SettingSwitch(
                    title = "Show thumbnails",
                    subtitle = "Display media video previews and album art",
                    checked = settings.showThumbnails,
                    onCheckedChange = onSetShowThumbnails
                )
                SettingSwitch(
                    title = "Mark watched videos",
                    subtitle = "Show completion status and progress bars",
                    checked = settings.mediaSeenMarking,
                    onCheckedChange = onSetMediaSeenMarking
                )
            }

            // 11.2 Video Settings
            item {
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingsSectionHeader("Video Player")
                ChoiceSetting(
                    title = "Resume playback",
                    currentValue = settings.resumeMode.name.lowercase().replaceFirstChar { it.uppercase() },
                    options = ResumeMode.entries.map { it.name.lowercase().replaceFirstChar { it.uppercase() } },
                    onSelect = { name ->
                        val mode = ResumeMode.entries.first { it.name.equals(name, ignoreCase = true) }
                        onSetResumeMode(mode)
                    }
                )
                ChoiceSetting(
                    title = "Controls timeout",
                    currentValue = "${settings.hudTimeoutSeconds} seconds",
                    options = listOf("2 seconds", "4 seconds", "6 seconds", "8 seconds", "10 seconds"),
                    onSelect = { str ->
                        val sec = str.filter { it.isDigit() }.toIntOrNull() ?: 4
                        onSetHudTimeout(sec)
                    }
                )
                ChoiceSetting(
                    title = "Jump interval",
                    currentValue = "${settings.jumpAmountSeconds}s",
                    options = listOf("10s", "20s", "30s"),
                    onSelect = { str ->
                        val sec = str.filter { it.isDigit() }.toIntOrNull() ?: 10
                        onSetJumpAmount(sec)
                    }
                )
                ChoiceSetting(
                    title = "Double-tap jump interval",
                    currentValue = "${settings.doubleTapJumpSeconds}s",
                    options = listOf("10s", "20s", "30s"),
                    onSelect = { str ->
                        val sec = str.filter { it.isDigit() }.toIntOrNull() ?: 20
                        onSetDoubleTapJump(sec)
                    }
                )
            }

            // 11.3 Gestures Settings
            item {
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingsSectionHeader("Gestures")
                SettingSwitch(
                    title = "Volume gesture",
                    subtitle = "Swipe vertically on right side to adjust volume",
                    checked = settings.volumeSwipe,
                    onCheckedChange = { onSetGesture("volume", it) }
                )
                SettingSwitch(
                    title = "Brightness gesture",
                    subtitle = "Swipe vertically on left side to adjust screen brightness",
                    checked = settings.brightnessSwipe,
                    onCheckedChange = { onSetGesture("brightness", it) }
                )
                SettingSwitch(
                    title = "Seek gesture",
                    subtitle = "Swipe horizontally across the screen to seek",
                    checked = settings.seekSwipe,
                    onCheckedChange = { onSetGesture("seek", it) }
                )
                SettingSwitch(
                    title = "Double-tap to seek",
                    subtitle = "Double tap left/right quarter to jump backwards/forwards",
                    checked = settings.doubleTapSeek,
                    onCheckedChange = { onSetGesture("double_tap_seek", it) }
                )
                SettingSwitch(
                    title = "Double-tap to play/pause",
                    subtitle = "Double tap middle of video to toggle play/pause",
                    checked = settings.doubleTapPlayPause,
                    onCheckedChange = { onSetGesture("double_tap_play_pause", it) }
                )
                SettingSwitch(
                    title = "Pinch to zoom",
                    subtitle = "Pinch on video surface to zoom from 0.5x to 3.0x",
                    checked = settings.pinchZoom,
                    onCheckedChange = { onSetGesture("pinch_zoom", it) }
                )
                SettingSwitch(
                    title = "Tap-and-hold fast-play",
                    subtitle = "Press and hold screen for 2.0x playback while holding",
                    checked = settings.tapAndHoldFastPlay,
                    onCheckedChange = { onSetGesture("tap_hold_fast_play", it) }
                )
            }

            // 11.4 Audio & Privacy Settings
            item {
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingsSectionHeader("Audio & Privacy")
                SettingSwitch(
                    title = "Audio ducking",
                    subtitle = "Lower volume when notifications sound",
                    checked = settings.audioDucking,
                    onCheckedChange = onSetAudioDucking
                )
                SettingSwitch(
                    title = "Incognito mode",
                    subtitle = "Do not save playback history or resume positions",
                    checked = settings.incognitoMode,
                    onCheckedChange = onSetIncognito
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onClearHistory() }
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Clear playback history",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = EveAccent
                        )
                        Text(
                            text = "Erase all recent items and saved positions",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = EveAccent,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
fun ThemePicker(
    currentTheme: AppThemeMode,
    onSetTheme: (AppThemeMode) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = true }
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Theme",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = when (currentTheme) {
                    AppThemeMode.AMOLED -> "AMOLED (Pure Black)"
                    AppThemeMode.DARK -> "Dark"
                    AppThemeMode.LIGHT -> "Light"
                    AppThemeMode.SYSTEM -> "Follow system"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            AppThemeMode.entries.forEach { mode ->
                val label = when (mode) {
                    AppThemeMode.AMOLED -> "AMOLED (Pure Black - Default)"
                    AppThemeMode.DARK -> "Dark"
                    AppThemeMode.LIGHT -> "Light"
                    AppThemeMode.SYSTEM -> "Follow system"
                }
                DropdownMenuItem(
                    text = {
                        Text(
                            text = label,
                            color = if (mode == currentTheme) EveAccent else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (mode == currentTheme) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    onClick = {
                        expanded = false
                        onSetTheme(mode)
                    }
                )
            }
        }
    }
}

@Composable
fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = EveAccent,
                uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }
}

@Composable
fun ChoiceSetting(
    title: String,
    currentValue: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = true }
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = currentValue,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = opt,
                            color = if (opt == currentValue) EveAccent else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (opt == currentValue) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    onClick = {
                        expanded = false
                        onSelect(opt)
                    }
                )
            }
        }
    }
}
