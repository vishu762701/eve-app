package com.example.ui.player

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EveRedPrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PlayerTopOverlay(
    title: String,
    playlistSize: Int,
    playbackSpeed: Float,
    sleepTimerSec: Int?,
    subtitleDelayMs: Long,
    audioDelayMs: Long,
    onBack: () -> Unit,
    onScreenshot: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenSpeed: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onOpenSubtitleSettings: () -> Unit,
    onResetSubtitleDelay: () -> Unit,
    onOpenAudioDelay: () -> Unit,
    onResetAudioDelay: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Current dynamic clock
    var currentTimeString by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (isActive) {
            currentTimeString = formatter.format(Date())
            delay(1000L)
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = 0.85f),
                        Color.Black.copy(alpha = 0.5f),
                        Color.Transparent
                    )
                )
            )
            .padding(bottom = 24.dp)
    ) {
        // TOP-LEFT: Back navigation button + Optional screenshot button (margin start 16dp, top 8dp)
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Outlined.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }

            IconButton(
                onClick = onScreenshot,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Screenshot",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // TOP-RIGHT: Clock at top-right (18sp, margin top 16dp, end 16dp)
        // and Queue button at top-right (only if playlist > 1, margin top 8dp, end 16dp)
        if (playlistSize > 1) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = 16.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (currentTimeString.isNotEmpty()) {
                    Text(
                        text = currentTimeString,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                IconButton(
                    onClick = onOpenQueue,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.QueueMusic,
                        contentDescription = "Queue",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        } else {
            if (currentTimeString.isNotEmpty()) {
                Text(
                    text = currentTimeString,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 16.dp, end = 16.dp)
                )
            }
        }

        // CENTER COLUMN:
        // Title centered: 22sp, single line, ellipsis, side margins 136dp, top margin 8dp.
        // Below the title, a row of small quick-action chips (background #141414 at 75% alpha).
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 136.dp)
            )

            // Quick-Action Chips Row
            val hasChips = (playbackSpeed != 1.0f) ||
                    (sleepTimerSec != null && sleepTimerSec > 0) ||
                    (subtitleDelayMs != 0L) ||
                    (audioDelayMs != 0L)

            if (hasChips) {
                Row(
                    modifier = Modifier.padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (playbackSpeed != 1.0f) {
                        QuickActionChip(
                            label = "${playbackSpeed}x",
                            icon = Icons.Default.Speed,
                            onClick = onOpenSpeed
                        )
                    }

                    if (sleepTimerSec != null && sleepTimerSec > 0) {
                        val m = sleepTimerSec / 60
                        val s = sleepTimerSec % 60
                        QuickActionChip(
                            label = String.format("%02d:%02d", m, s),
                            icon = Icons.Default.Timer,
                            onClick = onOpenSleepTimer
                        )
                    }

                    if (subtitleDelayMs != 0L) {
                        val sign = if (subtitleDelayMs > 0) "+${subtitleDelayMs}ms" else "${subtitleDelayMs}ms"
                        QuickActionChip(
                            label = "Sub $sign",
                            icon = Icons.Default.Subtitles,
                            onClick = onOpenSubtitleSettings,
                            onLongClick = onResetSubtitleDelay
                        )
                    }

                    if (audioDelayMs != 0L) {
                        val sign = if (audioDelayMs > 0) "+${audioDelayMs}ms" else "${audioDelayMs}ms"
                        QuickActionChip(
                            label = "Audio $sign",
                            icon = Icons.Default.Audiotrack,
                            onClick = onOpenAudioDelay,
                            onLongClick = onResetAudioDelay
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun QuickActionChip(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF141414).copy(alpha = 0.75f))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = EveRedPrimary,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            color = EveRedPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
