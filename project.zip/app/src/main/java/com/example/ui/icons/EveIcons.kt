package com.example.ui.icons

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.ripple
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalEveIconTint

object EveIcons {
    val Play = Icons.Filled.PlayArrow
    val Pause = Icons.Filled.Pause
    val Previous = Icons.Filled.SkipPrevious
    val Next = Icons.Filled.SkipNext
    val Replay = Icons.Filled.Replay
    val AudioTracks = Icons.Filled.Audiotrack
    val Subtitles = Icons.Filled.Subtitles
    val Orientation = Icons.Filled.ScreenRotation
    val AspectRatio = Icons.Filled.AspectRatio
    val More = Icons.Filled.MoreVert
    val Lock = Icons.Filled.Lock
    val Unlock = Icons.Filled.LockOpen
    val PiP = Icons.Filled.PictureInPictureAlt
    val Screenshot = Icons.Filled.AspectRatio
    val Queue = Icons.AutoMirrored.Filled.QueueMusic
    val Speed = Icons.Filled.Speed
    val SleepTimer = Icons.Filled.Timer
    val Equalizer = Icons.Filled.Equalizer
    val Repeat = Icons.Filled.Repeat
    val RepeatOne = Icons.Filled.RepeatOne
    val Shuffle = Icons.Filled.Shuffle
    val Bookmark = Icons.Filled.Bookmark
    val Delete = Icons.Filled.Delete
    val Share = Icons.Filled.Share
    val Info = Icons.Filled.Info
    val Search = Icons.Filled.Search
    val Sort = Icons.AutoMirrored.Filled.Sort
    val Grid = Icons.Filled.GridView
    val List = Icons.Filled.ViewList
    val Folder = Icons.Filled.Folder
    val Video = Icons.Filled.VideoLibrary
    val Audio = Icons.Filled.MusicNote
    val Playlist = Icons.AutoMirrored.Filled.PlaylistAdd
    val Settings = Icons.Filled.Settings
    val History = Icons.Filled.History
    val Favorite = Icons.Filled.Favorite
    val FavoriteBorder = Icons.Filled.FavoriteBorder
    val Volume = Icons.AutoMirrored.Filled.VolumeUp
    val Brightness = Icons.Filled.BrightnessMedium
    val Check = Icons.Filled.Check
    val Close = Icons.Filled.Close
    val Clear = Icons.Filled.Clear
    val Back = Icons.AutoMirrored.Filled.ArrowBack
    val Refresh = Icons.Filled.Refresh
    val Artist = Icons.Filled.Person
    val Album = Icons.Filled.Album
}

/**
 * Standard eve icon button strictly adhering to PRD 2.4:
 * - Size box 32dp for icon glyph (48dp for play/pause).
 * - Minimum touch target size 48dp with unbounded circular ripple.
 * - Icon color follows LocalEveIconTint (white in dark, #333333 in light) unless custom tint provided (e.g. accent).
 */
@Composable
fun EveIconButton(
    imageVector: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 32.dp,
    tint: Color = LocalEveIconTint.current,
    testTag: String? = null
) {
    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 24.dp),
                onClick = onClick
            )
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            modifier = Modifier.size(iconSize),
            tint = tint
        )
    }
}

/**
 * VLC-style Skip button with circular arrow and bold amount label (10/20/30) in center (PRD 2.4 / 9.3)
 */
@Composable
fun EveSkipButton(
    seconds: Int,
    isForward: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = LocalEveIconTint.current,
    testTag: String? = null
) {
    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 24.dp),
                onClick = onClick
            )
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.size(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Replay,
                contentDescription = if (isForward) "Forward $seconds seconds" else "Rewind $seconds seconds",
                modifier = Modifier
                    .size(32.dp)
                    .then(if (isForward) Modifier.size(32.dp) else Modifier),
                tint = tint
            )
            Text(
                text = "$seconds",
                color = tint,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 8.sp
            )
        }
    }
}
