package com.example.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.data.mediastore.MediaItemModel
import com.example.player.AspectRatioMode
import com.example.player.TrackOption
import com.example.ui.theme.EveRedPrimary

/**
 * Advanced Options Bottom Sheet (More icon):
 * 1. Lock player
 * 2. Sleep timer
 * 3. Playback speed
 * 4. Jump to time
 * 5. Equalizer
 * 6. Play as audio
 * 7. Picture-in-picture
 * 8. Repeat
 * 9. Shuffle
 * 10. A-B repeat
 * 11. Video information
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedOptionsBottomSheet(
    repeatMode: Int,
    shuffleMode: Boolean,
    playbackSpeed: Float,
    isSleepTimerActive: Boolean,
    onLockPlayer: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onOpenSpeed: () -> Unit,
    onOpenJumpToTime: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onPlayAsAudio: () -> Unit,
    onPictureInPicture: () -> Unit,
    onToggleRepeat: () -> Unit,
    onToggleShuffle: () -> Unit,
    onOpenAbRepeat: () -> Unit,
    onOpenVideoInfo: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF1C1C1C),
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Advanced Options",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.Lock,
                        title = "Lock Player",
                        subtitle = "Prevent accidental touch gestures",
                        onClick = {
                            onDismiss()
                            onLockPlayer()
                        }
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.Timer,
                        title = "Sleep Timer",
                        subtitle = if (isSleepTimerActive) "Active" else "Off",
                        badge = if (isSleepTimerActive) "ON" else null,
                        onClick = {
                            onDismiss()
                            onOpenSleepTimer()
                        }
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.Speed,
                        title = "Playback Speed",
                        subtitle = "${playbackSpeed}x",
                        badge = "${playbackSpeed}x",
                        onClick = {
                            onDismiss()
                            onOpenSpeed()
                        }
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.AccessTime,
                        title = "Jump to Time",
                        subtitle = "Go directly to specific timestamp",
                        onClick = {
                            onDismiss()
                            onOpenJumpToTime()
                        }
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.GraphicEq,
                        title = "Equalizer",
                        subtitle = "Audio frequencies and bass boost",
                        onClick = {
                            onDismiss()
                            onOpenEqualizer()
                        }
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.Headphones,
                        title = "Play as Audio",
                        subtitle = "Continue listening with screen off or in background",
                        onClick = {
                            onDismiss()
                            onPlayAsAudio()
                        }
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.PictureInPictureAlt,
                        title = "Picture-in-Picture",
                        subtitle = "Watch in floating window",
                        onClick = {
                            onDismiss()
                            onPictureInPicture()
                        }
                    )
                }

                item {
                    val repeatText = when (repeatMode) {
                        Player.REPEAT_MODE_ALL -> "Repeat All"
                        Player.REPEAT_MODE_ONE -> "Repeat One"
                        else -> "Off"
                    }
                    val repeatIcon = if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat
                    AdvancedOptionItem(
                        icon = repeatIcon,
                        title = "Repeat",
                        subtitle = repeatText,
                        badge = if (repeatMode != Player.REPEAT_MODE_OFF) repeatText else null,
                        onClick = onToggleRepeat
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.Shuffle,
                        title = "Shuffle",
                        subtitle = if (shuffleMode) "On" else "Off",
                        badge = if (shuffleMode) "ON" else null,
                        onClick = onToggleShuffle
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.Loop,
                        title = "A-B Repeat",
                        subtitle = "Loop a specific section of video",
                        onClick = {
                            onDismiss()
                            onOpenAbRepeat()
                        }
                    )
                }

                item {
                    AdvancedOptionItem(
                        icon = Icons.Default.Info,
                        title = "Video Information",
                        subtitle = "File details, resolution, codecs and tracks",
                        onClick = {
                            onDismiss()
                            onOpenVideoInfo()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AdvancedOptionItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = EveRedPrimary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f)
            )
        }
        if (badge != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(EveRedPrimary.copy(alpha = 0.2f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = badge,
                    color = EveRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Jump To Time Dialog
 */
@Composable
fun JumpToTimeDialog(
    currentPosition: Long,
    duration: Long,
    onJump: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val totalSec = (currentPosition / 1000).toInt()
    val initialH = totalSec / 3600
    val initialM = (totalSec % 3600) / 60
    val initialS = totalSec % 60

    var hoursText by remember { mutableStateOf(if (initialH > 0) initialH.toString() else "") }
    var minsText by remember { mutableStateOf(initialM.toString()) }
    var secsText by remember { mutableStateOf(initialS.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Jump to Time") },
        text = {
            Column {
                Text(
                    text = "Enter timestamp (Duration: ${MediaItemModel.formatDuration(duration)})",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = hoursText,
                        onValueChange = { if (it.length <= 2 && it.all { c -> c.isDigit() }) hoursText = it },
                        label = { Text("HH") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minsText,
                        onValueChange = { if (it.length <= 2 && it.all { c -> c.isDigit() }) minsText = it },
                        label = { Text("MM") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = secsText,
                        onValueChange = { if (it.length <= 2 && it.all { c -> c.isDigit() }) secsText = it },
                        label = { Text("SS") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val h = hoursText.toIntOrNull() ?: 0
                    val m = minsText.toIntOrNull() ?: 0
                    val s = secsText.toIntOrNull() ?: 0
                    val targetMs = ((h * 3600L) + (m * 60L) + s.toLong()) * 1000L
                    onJump(targetMs.coerceIn(0L, duration.coerceAtLeast(0L)))
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary)
            ) {
                Text("Jump")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

/**
 * Video Information Dialog
 */
@Composable
fun VideoInfoDialog(
    mediaItem: MediaItemModel?,
    duration: Long,
    videoWidth: Int,
    videoHeight: Int,
    audioTracksCount: Int,
    subtitlesCount: Int,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = null, tint = EveRedPrimary)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Video Information")
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    InfoRow("Title", mediaItem?.title ?: "Unknown")
                }
                if (videoWidth > 0 && videoHeight > 0) {
                    item {
                        InfoRow("Resolution", "${videoWidth} × ${videoHeight}")
                    }
                }
                item {
                    InfoRow("Duration", MediaItemModel.formatDuration(duration))
                }
                if (mediaItem != null && mediaItem.size > 0) {
                    item {
                        InfoRow("File Size", MediaItemModel.formatFileSize(mediaItem.size))
                    }
                }
                if (!mediaItem?.mimeType.isNullOrEmpty()) {
                    item {
                        InfoRow("Format", mediaItem?.mimeType ?: "")
                    }
                }
                item {
                    InfoRow("Audio Tracks", "$audioTracksCount track(s)")
                }
                item {
                    InfoRow("Subtitles", "$subtitlesCount stream(s)")
                }
                val location = mediaItem?.folderPath?.takeIf { it.isNotEmpty() } ?: mediaItem?.uri?.toString()
                if (!location.isNullOrEmpty()) {
                    item {
                        InfoRow("Location", location)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = EveRedPrimary,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

/**
 * Aspect Ratio Menu (shown on long-press of aspect-ratio icon)
 */
@Composable
fun AspectRatioMenuDialog(
    currentMode: AspectRatioMode,
    onSelectMode: (AspectRatioMode) -> Unit,
    onDismiss: () -> Unit
) {
    val modes = listOf(
        AspectRatioMode.FIT to ("Fit Screen" to "Preserve original aspect ratio with black bars if needed"),
        AspectRatioMode.FILL to ("Stretch / Fill" to "Stretch video to completely fill the screen"),
        AspectRatioMode.CROP to ("Crop to Fill" to "Zoom in to fill screen without distortion"),
        AspectRatioMode.RATIO_16_9 to ("16:9 Widescreen" to "Force standard 16:9 widescreen ratio"),
        AspectRatioMode.RATIO_4_3 to ("4:3 Standard" to "Force standard 4:3 box ratio")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AspectRatio, contentDescription = null, tint = EveRedPrimary)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Aspect Ratio")
            }
        },
        text = {
            Column {
                modes.forEach { (mode, details) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                onSelectMode(mode)
                                onDismiss()
                            }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = currentMode == mode,
                            onClick = {
                                onSelectMode(mode)
                                onDismiss()
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = EveRedPrimary)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = details.first,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (currentMode == mode) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                text = details.second,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

/**
 * Unified Tracks Selection Dialog (Audio & Subtitle tabs)
 */
@Composable
fun TracksSelectionDialog(
    audioTracks: List<TrackOption>,
    subtitleTracks: List<TrackOption>,
    onSelectAudio: (Int, Int) -> Unit,
    onSelectSubtitle: (Int, Int) -> Unit,
    onDisableSubtitle: () -> Unit,
    onLoadExternalSubtitle: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Audio, 1 = Subtitles

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tracks & Subtitles") },
        text = {
            Column(modifier = Modifier.height(340.dp)) {
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Audio (${audioTracks.size})") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Subtitles (${subtitleTracks.size})") }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (selectedTab == 0) {
                    // Audio Tracks
                    if (audioTracks.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No alternative audio tracks found", style = MaterialTheme.typography.bodyMedium)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(audioTracks) { track ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            onSelectAudio(track.groupIndex, track.trackIndex)
                                            onDismiss()
                                        }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = track.isSelected,
                                        onClick = {
                                            onSelectAudio(track.groupIndex, track.trackIndex)
                                            onDismiss()
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = EveRedPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            track.label,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (track.isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                        if (!track.language.isNullOrEmpty()) {
                                            Text(
                                                track.language,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Subtitle Tracks
                    Column(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = {
                                onLoadExternalSubtitle()
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Load External Subtitles (.srt, .vtt)")
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LazyColumn(modifier = Modifier.weight(1f)) {
                            val noneSelected = subtitleTracks.none { it.isSelected }
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            onDisableSubtitle()
                                            onDismiss()
                                        }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = noneSelected,
                                        onClick = {
                                            onDisableSubtitle()
                                            onDismiss()
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = EveRedPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Disable Subtitles")
                                }
                            }

                            items(subtitleTracks) { track ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            onSelectSubtitle(track.groupIndex, track.trackIndex)
                                            onDismiss()
                                        }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = track.isSelected,
                                        onClick = {
                                            onSelectSubtitle(track.groupIndex, track.trackIndex)
                                            onDismiss()
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = EveRedPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            track.label,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (track.isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                        if (!track.language.isNullOrEmpty()) {
                                            Text(
                                                track.language,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

/**
 * A-B Repeat Configuration Dialog
 */
@Composable
fun AbRepeatDialog(
    pointA: Long?,
    pointB: Long?,
    currentPosition: Long,
    onSetPointA: (Long) -> Unit,
    onSetPointB: (Long) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Loop, contentDescription = null, tint = EveRedPrimary)
                Spacer(modifier = Modifier.width(10.dp))
                Text("A-B Repeat Loop")
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Current position: ${MediaItemModel.formatDuration(currentPosition)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = EveRedPrimary
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Point A", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = if (pointA != null) MediaItemModel.formatDuration(pointA) else "Not set",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (pointA != null) EveRedPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = { onSetPointA(currentPosition) },
                        colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary)
                    ) {
                        Text("Set A")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Point B", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = if (pointB != null) MediaItemModel.formatDuration(pointB) else "Not set",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (pointB != null) EveRedPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = { onSetPointB(currentPosition) },
                        colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary)
                    ) {
                        Text("Set B")
                    }
                }

                if (pointA != null || pointB != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            onClear()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Clear Loop")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
