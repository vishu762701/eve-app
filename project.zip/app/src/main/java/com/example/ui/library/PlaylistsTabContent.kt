package com.example.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistItemEntity
import com.example.data.mediastore.MediaItemModel
import com.example.ui.components.MediaInfoDialog
import com.example.ui.components.MediaItemListRow
import com.example.ui.components.PlaylistCard
import com.example.ui.components.RenamePlaylistDialog
import com.example.ui.theme.EveRedPrimary

enum class SystemPlaylistType(val title: String, val icon: ImageVector) {
    HISTORY("Recently Played", Icons.Default.History),
    RECENTLY_ADDED("Recently Added", Icons.Default.NewReleases),
    FAVORITES("Favorites", Icons.Default.Favorite)
}

@Composable
fun PlaylistsTabContent(
    playlists: List<PlaylistEntity>,
    historyItems: List<MediaItemModel>,
    recentlyAddedItems: List<MediaItemModel>,
    favoriteItems: List<MediaItemModel>,
    onCreatePlaylist: () -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onPlayPlaylist: (List<MediaItemModel>, Boolean) -> Unit,
    onPlayItem: (MediaItemModel, List<MediaItemModel>) -> Unit,
    onPlayNext: (MediaItemModel) -> Unit,
    onAddToPlaylist: (MediaItemModel) -> Unit,
    onToggleFavorite: (MediaItemModel) -> Unit,
    onShare: (MediaItemModel) -> Unit,
    onDeleteItem: (MediaItemModel) -> Unit,
    getPlaylistItems: suspend (Long) -> List<PlaylistItemEntity>,
    onRemoveFromPlaylist: (Long, Long) -> Unit,
    onReorderPlaylist: (Long, Int, Int) -> Unit
) {
    // Detail view state: can be user playlist or system playlist
    var activeSystemPlaylist by remember { mutableStateOf<SystemPlaylistType?>(null) }
    var activeUserPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var userPlaylistItems by remember { mutableStateOf<List<PlaylistItemEntity>>(emptyList()) }

    var renamingPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var selectedItemForInfo by remember { mutableStateOf<MediaItemModel?>(null) }

    if (renamingPlaylist != null) {
        RenamePlaylistDialog(
            initialName = renamingPlaylist!!.name,
            onDismiss = { renamingPlaylist = null },
            onConfirm = { newName ->
                onRenamePlaylist(renamingPlaylist!!.id, newName)
                renamingPlaylist = null
            }
        )
    }

    if (selectedItemForInfo != null) {
        MediaInfoDialog(
            item = selectedItemForInfo!!,
            onDismiss = { selectedItemForInfo = null }
        )
    }

    // System playlist detail view
    if (activeSystemPlaylist != null) {
        val sysType = activeSystemPlaylist!!
        val items = when (sysType) {
            SystemPlaylistType.HISTORY -> historyItems
            SystemPlaylistType.RECENTLY_ADDED -> recentlyAddedItems
            SystemPlaylistType.FAVORITES -> favoriteItems
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { activeSystemPlaylist = null }) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        sysType.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${items.size} items",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (items.isNotEmpty()) {
                    IconButton(onClick = { onPlayPlaylist(items, false) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play All", tint = EveRedPrimary)
                    }
                    IconButton(onClick = { onPlayPlaylist(items, true) }) {
                        Icon(Icons.Default.Shuffle, contentDescription = "Shuffle", tint = EveRedPrimary)
                    }
                }
            }

            if (items.isEmpty()) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(32.dp)) {
                    Text(
                        "No items in ${sysType.title.lowercase()}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(items, key = { it.uri.toString() }) { item ->
                        MediaItemListRow(
                            item = item,
                            onClick = { onPlayItem(item, items) },
                            onToggleFavorite = { onToggleFavorite(item) },
                            onAddToPlaylist = { onAddToPlaylist(item) },
                            onAddToQueue = { onPlayNext(item) },
                            onDelete = { onDeleteItem(item) }
                        )
                    }
                }
            }
        }
        return
    }

    // User playlist detail view with reordering & item deletion
    if (activeUserPlaylist != null) {
        val playlist = activeUserPlaylist!!

        LaunchedEffect(playlist.id) {
            userPlaylistItems = getPlaylistItems(playlist.id)
        }

        // Convert playlist item entities into MediaItemModel objects for playback
        val mediaItems = remember(userPlaylistItems) {
            userPlaylistItems.map { pi ->
                val isVid = pi.mediaType == "video"
                MediaItemModel(
                    id = pi.id,
                    uri = android.net.Uri.parse(pi.uri),
                    title = pi.title,
                    displayName = pi.title,
                    artist = pi.artist,
                    album = "",
                    duration = pi.durationMs,
                    size = 0L,
                    mimeType = if (isVid) "video/*" else "audio/*",
                    dateModified = 0L,
                    isVideo = isVid
                )
            }
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { activeUserPlaylist = null }) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        playlist.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${userPlaylistItems.size} items",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (mediaItems.isNotEmpty()) {
                    IconButton(onClick = { onPlayPlaylist(mediaItems, false) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play All", tint = EveRedPrimary)
                    }
                    IconButton(onClick = { onPlayPlaylist(mediaItems, true) }) {
                        Icon(Icons.Default.Shuffle, contentDescription = "Shuffle", tint = EveRedPrimary)
                    }
                }
            }

            if (userPlaylistItems.isEmpty()) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(32.dp)) {
                    Text(
                        "Playlist is empty. Add songs or videos from the library!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(userPlaylistItems, key = { _, item -> item.id }) { index, item ->
                        val mediaItem = mediaItems.getOrNull(index)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (mediaItem != null) onPlayItem(mediaItem, mediaItems)
                                }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${index + 1}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(24.dp)
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    item.title,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    if (item.artist.isNotBlank()) "${item.artist} • ${MediaItemModel.formatDuration(item.durationMs)}" else MediaItemModel.formatDuration(item.durationMs),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Reorder Up
                            IconButton(
                                onClick = {
                                    if (index > 0) {
                                        onReorderPlaylist(playlist.id, index, index - 1)
                                        // update local list
                                        val mutable = userPlaylistItems.toMutableList()
                                        val moved = mutable.removeAt(index)
                                        mutable.add(index - 1, moved)
                                        userPlaylistItems = mutable
                                    }
                                },
                                enabled = index > 0,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.ArrowUpward,
                                    contentDescription = "Move Up",
                                    modifier = Modifier.size(16.dp),
                                    tint = if (index > 0) MaterialTheme.colorScheme.onSurfaceVariant else Color.Transparent
                                )
                            }

                            // Reorder Down
                            IconButton(
                                onClick = {
                                    if (index < userPlaylistItems.size - 1) {
                                        onReorderPlaylist(playlist.id, index, index + 1)
                                        val mutable = userPlaylistItems.toMutableList()
                                        val moved = mutable.removeAt(index)
                                        mutable.add(index + 1, moved)
                                        userPlaylistItems = mutable
                                    }
                                },
                                enabled = index < userPlaylistItems.size - 1,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.ArrowDownward,
                                    contentDescription = "Move Down",
                                    modifier = Modifier.size(16.dp),
                                    tint = if (index < userPlaylistItems.size - 1) MaterialTheme.colorScheme.onSurfaceVariant else Color.Transparent
                                )
                            }

                            // Remove item
                            IconButton(
                                onClick = {
                                    onRemoveFromPlaylist(playlist.id, item.id)
                                    userPlaylistItems = userPlaylistItems.filter { it.id != item.id }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Remove",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
        return
    }

    // Main Playlists Overview
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // System Playlists Section
        item {
            Text(
                "System Playlists",
                style = MaterialTheme.typography.titleSmall,
                color = EveRedPrimary,
                fontWeight = FontWeight.Bold
            )
        }

        items(SystemPlaylistType.entries) { sysType ->
            val count = when (sysType) {
                SystemPlaylistType.HISTORY -> historyItems.size
                SystemPlaylistType.RECENTLY_ADDED -> recentlyAddedItems.size
                SystemPlaylistType.FAVORITES -> favoriteItems.size
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { activeSystemPlaylist = sysType }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = EveRedPrimary.copy(alpha = 0.12f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(sysType.icon, contentDescription = null, tint = EveRedPrimary, modifier = Modifier.size(24.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(sysType.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("$count items", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = EveRedPrimary)
                }
            }
        }

        // User Playlists Section
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "My Playlists",
                    style = MaterialTheme.typography.titleSmall,
                    color = EveRedPrimary,
                    fontWeight = FontWeight.Bold
                )

                Button(
                    onClick = onCreatePlaylist,
                    colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Playlist", fontSize = 13.sp)
                }
            }
        }

        if (playlists.isEmpty()) {
            item {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp)
                ) {
                    Text(
                        "No custom playlists yet. Tap '+ New Playlist' to create one!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            items(playlists, key = { it.id }) { playlist ->
                PlaylistCard(
                    playlist = playlist,
                    onClick = { activeUserPlaylist = playlist },
                    onPlay = { activeUserPlaylist = playlist },
                    onRename = { renamingPlaylist = playlist },
                    onDelete = { onDeletePlaylist(playlist.id) }
                )
            }
        }
    }
}
