package com.example.ui.library

import android.os.Environment
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.mediastore.MediaItemModel
import com.example.data.mediastore.StorageFileItem
import com.example.ui.components.StorageFileRow
import com.example.ui.theme.EveRedPrimary
import java.io.File

@Composable
fun BrowseTabContent(
    onPlayMedia: (MediaItemModel) -> Unit,
    browsePath: suspend (String) -> List<StorageFileItem>
) {
    val rootPath = remember { Environment.getExternalStorageDirectory().absolutePath }
    var currentPath by remember { mutableStateOf(rootPath) }
    var fileItems by remember { mutableStateOf<List<StorageFileItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }

    LaunchedEffect(currentPath) {
        isLoading = true
        fileItems = browsePath(currentPath)
        isLoading = false
    }

    val canGoUp = currentPath != rootPath && currentPath != "/" && currentPath.length > rootPath.length

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Path Bar with Breadcrumbs & Up Button
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val parent = File(currentPath).parentFile
                        if (parent != null && parent.canRead()) {
                            currentPath = parent.absolutePath
                        }
                    },
                    enabled = canGoUp
                ) {
                    Icon(
                        Icons.Default.ArrowUpward,
                        contentDescription = "Up directory",
                        tint = if (canGoUp) EveRedPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                }

                // Breadcrumbs scrollable row
                val breadcrumbs = remember(currentPath, rootPath) {
                    val rel = if (currentPath.startsWith(rootPath)) {
                        currentPath.removePrefix(rootPath)
                    } else {
                        currentPath
                    }
                    val parts = rel.split(File.separatorChar).filter { it.isNotBlank() }
                    listOf("Internal Storage" to rootPath) + parts.scan(rootPath) { acc, part ->
                        "$acc/$part"
                    }.drop(1).zip(parts) { full, name -> name to full }
                }

                val breadcrumbScrollState = rememberScrollState()

                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(breadcrumbScrollState),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    breadcrumbs.forEachIndexed { index, (name, path) ->
                        if (index > 0) {
                            Icon(
                                Icons.Default.ChevronRight,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        }

                        val isLast = index == breadcrumbs.size - 1
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (isLast) FontWeight.Bold else FontWeight.Normal,
                            color = if (isLast) EveRedPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { currentPath = path }
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            maxLines = 1,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

        if (isLoading) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                CircularProgressIndicator(color = EveRedPrimary, strokeWidth = 2.dp)
            }
        } else if (fileItems.isEmpty()) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(32.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = Color.Black,
                        border = BorderStroke(1.dp, EveRedPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_eve_logo),
                                contentDescription = "eve logo",
                                modifier = Modifier
                                    .size(46.dp)
                                    .padding(4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.size(14.dp))
                    Text(
                        "Folder is empty",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text(
                        "No media files found in this folder",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(fileItems, key = { it.path }) { item ->
                    StorageFileRow(
                        item = item,
                        onClick = {
                            if (item.isDirectory) {
                                currentPath = item.path
                            } else if (item.isMedia) {
                                onPlayMedia(item.toMediaItem())
                            }
                        }
                    )
                }
            }
        }
    }
}
