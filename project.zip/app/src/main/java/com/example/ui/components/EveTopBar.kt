package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.settings.GroupingMode
import com.example.data.settings.SortMode
import com.example.data.settings.ViewMode
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.theme.EveAccent
import com.example.ui.theme.LocalEveIconTint

@Composable
fun EveTopBar(
    isScanning: Boolean,
    selectedCount: Int,
    viewMode: ViewMode,
    groupingMode: GroupingMode,
    sortMode: SortMode,
    sortAscending: Boolean,
    onSearchClick: () -> Unit,
    onToggleViewMode: () -> Unit,
    onSetGrouping: (GroupingMode) -> Unit,
    onSetSort: (SortMode) -> Unit,
    onToggleSortAscending: () -> Unit,
    onRefresh: () -> Unit,
    // Multi-select actions
    onClearSelection: () -> Unit = {},
    onPlaySelected: () -> Unit = {},
    onAppendSelected: () -> Unit = {},
    onAddToPlaylistSelected: () -> Unit = {},
    onDeleteSelected: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var overflowMenuExpanded by remember { mutableStateOf(false) }
    var sortSubMenuExpanded by remember { mutableStateOf(false) }
    var groupSubMenuExpanded by remember { mutableStateOf(false) }

    val isActionMode = selectedCount > 0

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isActionMode) {
                // Multi-select Action Bar mode (PRD 4.6)
                EveIconButton(
                    imageVector = EveIcons.Close,
                    contentDescription = "Close selection",
                    onClick = onClearSelection
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$selectedCount selected",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )

                EveIconButton(
                    imageVector = EveIcons.Play,
                    contentDescription = "Play selected",
                    onClick = onPlaySelected
                )
                EveIconButton(
                    imageVector = EveIcons.Playlist,
                    contentDescription = "Add to playlist",
                    onClick = onAddToPlaylistSelected
                )
                EveIconButton(
                    imageVector = EveIcons.Delete,
                    contentDescription = "Delete selected",
                    onClick = onDeleteSelected
                )
            } else {
                // Standard Eve Top Bar (PRD 3.2: Logo 32dp + "eve" on left, search & overflow menu on right)
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_launcher_foreground),
                        contentDescription = "eve logo",
                        modifier = Modifier
                            .size(36.dp)
                            .padding(start = 4.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "eve",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                EveIconButton(
                    imageVector = EveIcons.Search,
                    contentDescription = "Search",
                    onClick = onSearchClick,
                    testTag = "top_bar_search"
                )

                Box {
                    EveIconButton(
                        imageVector = EveIcons.More,
                        contentDescription = "More options",
                        onClick = { overflowMenuExpanded = true },
                        testTag = "top_bar_overflow"
                    )

                    DropdownMenu(
                        expanded = overflowMenuExpanded,
                        onDismissRequest = { overflowMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (viewMode == ViewMode.GRID) "List view" else "Grid view") },
                            leadingIcon = {
                                androidx.compose.material3.Icon(
                                    imageVector = if (viewMode == ViewMode.GRID) EveIcons.List else EveIcons.Grid,
                                    contentDescription = null,
                                    tint = LocalEveIconTint.current
                                )
                            },
                            onClick = {
                                overflowMenuExpanded = false
                                onToggleViewMode()
                            }
                        )

                        DropdownMenuItem(
                            text = { Text("Group by: ${groupingMode.name.lowercase().replaceFirstChar { it.uppercase() }}") },
                            leadingIcon = {
                                androidx.compose.material3.Icon(
                                    imageVector = EveIcons.Folder,
                                    contentDescription = null,
                                    tint = LocalEveIconTint.current
                                )
                            },
                            onClick = {
                                overflowMenuExpanded = false
                                groupSubMenuExpanded = true
                            }
                        )

                        DropdownMenuItem(
                            text = { Text("Sort by: ${sortMode.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() }}") },
                            leadingIcon = {
                                androidx.compose.material3.Icon(
                                    imageVector = EveIcons.Sort,
                                    contentDescription = null,
                                    tint = LocalEveIconTint.current
                                )
                            },
                            onClick = {
                                overflowMenuExpanded = false
                                sortSubMenuExpanded = true
                            }
                        )

                        HorizontalDivider()

                        DropdownMenuItem(
                            text = { Text("Refresh library") },
                            leadingIcon = {
                                androidx.compose.material3.Icon(
                                    imageVector = EveIcons.Refresh,
                                    contentDescription = null,
                                    tint = LocalEveIconTint.current
                                )
                            },
                            onClick = {
                                overflowMenuExpanded = false
                                onRefresh()
                            }
                        )
                    }

                    // Group by submenu
                    DropdownMenu(
                        expanded = groupSubMenuExpanded,
                        onDismissRequest = { groupSubMenuExpanded = false }
                    ) {
                        GroupingMode.entries.forEach { mode ->
                            val isSelected = groupingMode == mode
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = mode.name.lowercase().replaceFirstChar { it.uppercase() },
                                        color = if (isSelected) EveAccent else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    groupSubMenuExpanded = false
                                    onSetGrouping(mode)
                                }
                            )
                        }
                    }

                    // Sort by submenu
                    DropdownMenu(
                        expanded = sortSubMenuExpanded,
                        onDismissRequest = { sortSubMenuExpanded = false }
                    ) {
                        SortMode.entries.forEach { mode ->
                            val isSelected = sortMode == mode
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = mode.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() },
                                        color = if (isSelected) EveAccent else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    sortSubMenuExpanded = false
                                    onSetSort(mode)
                                }
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text(if (sortAscending) "Order: Ascending" else "Order: Descending") },
                            onClick = {
                                sortSubMenuExpanded = false
                                onToggleSortAscending()
                            }
                        )
                    }
                }
            }
        }

        // Thin indeterminate progress bar under top bar while scanning (PRD 3.2)
        AnimatedVisibility(visible = isScanning) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp),
                color = EveAccent,
                trackColor = Color.Transparent
            )
        }
    }
}
