@file:kotlin.OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.example.ui.screens.player

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.provider.Settings
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.model.MediaModel
import com.example.data.settings.EveSettings
import com.example.playback.AspectMode
import com.example.playback.MediaPlaybackManager
import com.example.playback.RepeatState
import com.example.playback.TrackInfo
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.icons.EveSkipButton
import com.example.ui.theme.ChipBackground
import com.example.ui.theme.EveAccent
import com.example.ui.theme.LocalEveIconTint
import com.example.ui.theme.PlayerScrim
import com.example.ui.theme.TrackInactiveDark
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VideoPlayerScreen(
    playbackManager: MediaPlaybackManager,
    settings: EveSettings,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()

    val currentMedia by playbackManager.currentMedia.collectAsState()
    val isPlaying by playbackManager.isPlaying.collectAsState()
    val currentPosition by playbackManager.currentPosition.collectAsState()
    val duration by playbackManager.duration.collectAsState()
    val aspectMode by playbackManager.aspectMode.collectAsState()
    val playbackSpeed by playbackManager.playbackSpeed.collectAsState()
    val repeatState by playbackManager.repeatState.collectAsState()
    val isShuffle by playbackManager.isShuffle.collectAsState()
    val markerA by playbackManager.markerA.collectAsState()
    val markerB by playbackManager.markerB.collectAsState()
    val audioTracks by playbackManager.audioTracks.collectAsState()
    val subtitleTracks by playbackManager.subtitleTracks.collectAsState()
    val sleepTimerRemaining by playbackManager.sleepTimerRemainingSeconds.collectAsState()

    // Overlay visibility state & auto-hide timer (PRD 9.1: 4s default)
    var isOverlayVisible by remember { mutableStateOf(true) }
    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Screen lock mode (PRD 9.1: lock control)
    var isScreenLocked by remember { mutableStateOf(false) }

    // HUD overlays
    var volumeHudValue by remember { mutableFloatStateOf(-1f) }
    var brightnessHudValue by remember { mutableFloatStateOf(-1f) }
    var seekHudText by remember { mutableStateOf<String?>(null) }
    var doubleTapBadgeText by remember { mutableStateOf<String?>(null) }
    var isFastPlayActive by remember { mutableStateOf(false) }

    // Zoom scale from pinch
    var zoomScale by remember { mutableFloatStateOf(1.0f) }

    // Remaining vs total time toggle
    var showRemainingTime by remember { mutableStateOf(true) }

    // Dialogs & sheets
    var showAdvancedSheet by remember { mutableStateOf(false) }
    var showTracksSheet by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showJumpDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }

    // System Brightness & Audio Manager
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    // Keep screen on while playing
    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Set sensor orientation initially (PRD 9.4)
        val originalOrientation = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            activity?.requestedOrientation = originalOrientation
        }
    }

    // Auto-hide controls effect
    LaunchedEffect(isOverlayVisible, isPlaying, lastInteractionTime) {
        if (isOverlayVisible && isPlaying && settings.hudTimeoutSeconds > 0) {
            delay(settings.hudTimeoutSeconds * 1000L)
            isOverlayVisible = false
        }
    }

    // Current system clock
    var currentTimeString by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val format = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTimeString = format.format(Date())
            delay(30000L)
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("video_player_container")
    ) {
        val screenWidth = maxWidth
        val screenHeight = maxHeight

        // 1. Video Surface Layer (ExoPlayer)
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = playbackManager.player
                    useController = false
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    resizeMode = when (aspectMode) {
                        AspectMode.BEST_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        AspectMode.FIT_SCREEN -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                        AspectMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        AspectMode.CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        AspectMode.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        AspectMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                }
            },
            update = { playerView ->
                playerView.player = playbackManager.player
                playerView.resizeMode = when (aspectMode) {
                    AspectMode.BEST_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    AspectMode.FIT_SCREEN -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                    AspectMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    AspectMode.CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    AspectMode.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    AspectMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(scaleX = zoomScale, scaleY = zoomScale)
        )

        // 2. Gesture Detector Layer (PRD 9.2)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isScreenLocked) {
                    if (isScreenLocked) {
                        detectTapGestures(
                            onTap = {
                                isOverlayVisible = !isOverlayVisible
                            }
                        )
                        return@pointerInput
                    }

                    detectTapGestures(
                        onTap = {
                            isOverlayVisible = !isOverlayVisible
                            lastInteractionTime = System.currentTimeMillis()
                        },
                        onDoubleTap = { offset ->
                            lastInteractionTime = System.currentTimeMillis()
                            val xFraction = offset.x / size.width
                            when {
                                xFraction < 0.25f && settings.doubleTapSeek -> {
                                    // Jump backwards
                                    val jumpSec = settings.doubleTapJumpSeconds
                                    playbackManager.jumpBy(-jumpSec)
                                    doubleTapBadgeText = "◀◀ ${jumpSec}s"
                                    scope.launch {
                                        delay(800)
                                        doubleTapBadgeText = null
                                    }
                                }
                                xFraction > 0.75f && settings.doubleTapSeek -> {
                                    // Jump forward
                                    val jumpSec = settings.doubleTapJumpSeconds
                                    playbackManager.jumpBy(jumpSec)
                                    doubleTapBadgeText = "▶▶ ${jumpSec}s"
                                    scope.launch {
                                        delay(800)
                                        doubleTapBadgeText = null
                                    }
                                }
                                else -> {
                                    if (settings.doubleTapPlayPause) {
                                        playbackManager.togglePlayPause()
                                    }
                                }
                            }
                        },
                        onLongPress = {
                            if (settings.tapAndHoldFastPlay) {
                                isFastPlayActive = true
                                playbackManager.startFastPlayHold(settings.fastPlaySpeed)
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    if (settings.pinchZoom) {
                        detectTransformGestures { _, _, zoom, _ ->
                            zoomScale = (zoomScale * zoom).coerceIn(0.5f, 3.0f)
                        }
                    }
                }
        )

        // 3. HUD Overlays (Center indicators for Volume, Brightness, Seek, Fast-Play)
        // Double tap badge
        doubleTapBadgeText?.let { badge ->
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xCC141414))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = badge,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        // Fast-Play pill
        if (isFastPlayActive) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 80.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCCFF0000))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable {
                        isFastPlayActive = false
                        playbackManager.stopFastPlayHold()
                    }
            ) {
                Text(
                    text = "▶▶ ${settings.fastPlaySpeed}x Fast-Play (tap to release)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        // 4. Lock Screen handle if locked (PRD 9.1: Lock control)
        if (isScreenLocked) {
            AnimatedVisibility(
                visible = isOverlayVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x80000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                isScreenLocked = false
                                isOverlayVisible = true
                            },
                        colors = CardDefaults.cardColors(containerColor = Color(0xDD141414))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = EveIcons.Unlock,
                                contentDescription = "Unlock",
                                tint = EveAccent,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Tap to unlock controls",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
            return@BoxWithConstraints
        }

        // 5. Overlay Chrome (Top Bar + Bottom Bar)
        AnimatedVisibility(
            visible = isOverlayVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // TOP OVERLAY (PRD 9.1)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PlayerScrim)
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .align(Alignment.TopCenter)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        EveIconButton(
                            imageVector = EveIcons.Back,
                            contentDescription = "Back",
                            onClick = onBack
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Centred video title (22sp, 1 line, ellipsis per PRD 2.3 / 9.1)
                        Text(
                            text = currentMedia?.title ?: "Video",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Clock top-right 18sp
                        Text(
                            text = currentTimeString,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        EveIconButton(
                            imageVector = EveIcons.Queue,
                            contentDescription = "Playlist queue",
                            onClick = { showQueueSheet = true }
                        )
                    }

                    // Quick-action chips row (PRD 9.1: speed, sleep timer, sub delay, audio delay)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PlayerQuickChip(
                            label = "${playbackSpeed}x",
                            icon = EveIcons.Speed,
                            onClick = { showSpeedDialog = true }
                        )

                        PlayerQuickChip(
                            label = if (sleepTimerRemaining != null) "${sleepTimerRemaining!! / 60}m" else "Sleep",
                            icon = EveIcons.SleepTimer,
                            isHighlighted = sleepTimerRemaining != null,
                            onClick = { showSleepTimerDialog = true }
                        )

                        PlayerQuickChip(
                            label = aspectMode.displayName,
                            icon = EveIcons.AspectRatio,
                            onClick = { playbackManager.cycleAspectMode() }
                        )

                        PlayerQuickChip(
                            label = if (markerA != null) "A-B (ON)" else "A-B Repeat",
                            icon = EveIcons.Repeat,
                            isHighlighted = markerA != null,
                            onClick = {
                                if (markerA == null) {
                                    playbackManager.setMarkerA()
                                } else if (markerB == null) {
                                    playbackManager.setMarkerB()
                                } else {
                                    playbackManager.clearABRepeat()
                                }
                            }
                        )
                    }
                }

                // BOTTOM OVERLAY (PRD 9.1)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PlayerScrim)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .align(Alignment.BottomCenter)
                ) {
                    // Row 3: Elapsed time on left, total / remaining on right (tap toggles)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val elapsedSeconds = currentPosition / 1000
                        val elapsedFormatted = String.format(Locale.US, "%02d:%02d", elapsedSeconds / 60, elapsedSeconds % 60)
                        Text(
                            text = elapsedFormatted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )

                        val totalSeconds = duration / 1000
                        val remainingSeconds = (duration - currentPosition) / 1000
                        val rightFormatted = if (showRemainingTime) {
                            String.format(Locale.US, "-%02d:%02d", (remainingSeconds / 60).coerceAtLeast(0), (remainingSeconds % 60).coerceAtLeast(0))
                        } else {
                            String.format(Locale.US, "%02d:%02d", totalSeconds / 60, totalSeconds % 60)
                        }

                        Text(
                            text = rightFormatted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { showRemainingTime = !showRemainingTime }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }

                    // Row 2: Full-width seek bar (PRD 9.1 / 9.3)
                    // Inactive track 30% white, played part and thumb accent #FF0000
                    val progressRatio = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
                    var isSeeking by remember { mutableStateOf(false) }
                    var seekDragRatio by remember { mutableFloatStateOf(0f) }

                    Slider(
                        value = if (isSeeking) seekDragRatio else progressRatio,
                        onValueChange = {
                            isSeeking = true
                            seekDragRatio = it
                            lastInteractionTime = System.currentTimeMillis()
                        },
                        onValueChangeFinished = {
                            isSeeking = false
                            val targetMs = (seekDragRatio * duration).toLong()
                            playbackManager.seekTo(targetMs)
                            lastInteractionTime = System.currentTimeMillis()
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = EveAccent,
                            activeTrackColor = EveAccent,
                            inactiveTrackColor = TrackInactiveDark
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Row 1: Main Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left group: Tracks & Orientation
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            EveIconButton(
                                imageVector = EveIcons.AudioTracks,
                                contentDescription = "Tracks",
                                onClick = { showTracksSheet = true },
                                iconSize = 28.dp
                            )
                            EveIconButton(
                                imageVector = EveIcons.Orientation,
                                contentDescription = "Orientation",
                                onClick = {
                                    val cur = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                    activity?.requestedOrientation = if (cur == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    } else {
                                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    }
                                },
                                iconSize = 28.dp
                            )
                        }

                        // Centre group: Previous, Rewind 10, Play/Pause (48dp solid glyph, NO circle!), Forward 10, Next
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            EveIconButton(
                                imageVector = EveIcons.Previous,
                                contentDescription = "Previous",
                                onClick = { playbackManager.previous() },
                                iconSize = 30.dp
                            )

                            EveSkipButton(
                                seconds = settings.jumpAmountSeconds,
                                isForward = false,
                                onClick = { playbackManager.jumpBy(-settings.jumpAmountSeconds) }
                            )

                            // Play/Pause: 48dp plain white glyph, no circle background! (PRD 2.4 / 9.1)
                            EveIconButton(
                                imageVector = if (isPlaying) EveIcons.Pause else EveIcons.Play,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                onClick = { playbackManager.togglePlayPause() },
                                iconSize = 48.dp,
                                tint = Color.White,
                                testTag = "player_play_pause_button"
                            )

                            EveSkipButton(
                                seconds = settings.jumpAmountSeconds,
                                isForward = true,
                                onClick = { playbackManager.jumpBy(settings.jumpAmountSeconds) }
                            )

                            EveIconButton(
                                imageVector = EveIcons.Next,
                                contentDescription = "Next",
                                onClick = { playbackManager.next() },
                                iconSize = 30.dp
                            )
                        }

                        // Right group: Lock & More/Advanced
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            EveIconButton(
                                imageVector = EveIcons.Lock,
                                contentDescription = "Lock controls",
                                onClick = {
                                    isScreenLocked = true
                                    isOverlayVisible = false
                                },
                                iconSize = 26.dp
                            )
                            EveIconButton(
                                imageVector = EveIcons.More,
                                contentDescription = "Advanced options",
                                onClick = { showAdvancedSheet = true },
                                iconSize = 28.dp
                            )
                        }
                    }
                }
            }
        }
    }

    // Advanced Options Bottom Sheet (PRD 9.1: 7)
    if (showAdvancedSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAdvancedSheet = false },
            containerColor = Color(0xFF141418)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Player Options",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PlayerOptionItem(EveIcons.Speed, "Speed") {
                        showAdvancedSheet = false
                        showSpeedDialog = true
                    }
                    PlayerOptionItem(EveIcons.SleepTimer, "Sleep timer") {
                        showAdvancedSheet = false
                        showSleepTimerDialog = true
                    }
                    PlayerOptionItem(EveIcons.History, "Jump to time") {
                        showAdvancedSheet = false
                        showJumpDialog = true
                    }
                    PlayerOptionItem(EveIcons.Repeat, if (repeatState == RepeatState.OFF) "Repeat" else repeatState.name) {
                        playbackManager.toggleRepeat()
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PlayerOptionItem(EveIcons.Shuffle, if (isShuffle) "Shuffle ON" else "Shuffle") {
                        playbackManager.toggleShuffle()
                    }
                    PlayerOptionItem(EveIcons.AspectRatio, aspectMode.displayName) {
                        playbackManager.cycleAspectMode()
                    }
                    PlayerOptionItem(EveIcons.Lock, "Lock player") {
                        showAdvancedSheet = false
                        isScreenLocked = true
                        isOverlayVisible = false
                    }
                    PlayerOptionItem(EveIcons.AudioTracks, "Tracks") {
                        showAdvancedSheet = false
                        showTracksSheet = true
                    }
                }
            }
        }
    }

    // Tracks & Delays Bottom Sheet (PRD 9.1: 8)
    if (showTracksSheet) {
        ModalBottomSheet(
            onDismissRequest = { showTracksSheet = false },
            containerColor = Color(0xFF141418)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Audio & Subtitle Tracks",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )

                Text("Audio Tracks", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = EveAccent)
                if (audioTracks.isEmpty()) {
                    Text("Default audio stream", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                } else {
                    audioTracks.forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playbackManager.selectTrack(track, isAudio = true)
                                }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = track.name,
                                color = if (track.isSelected) EveAccent else Color.White,
                                fontWeight = if (track.isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                            if (track.isSelected) {
                                Icon(imageVector = EveIcons.Check, contentDescription = null, tint = EveAccent)
                            }
                        }
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.15f))

                Text("Subtitles", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = EveAccent)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { playbackManager.disableSubtitles() }
                        .padding(vertical = 8.dp, horizontal = 6.dp)
                ) {
                    Text("Disable subtitles", color = Color.White)
                }
                subtitleTracks.forEach { track ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                playbackManager.selectTrack(track, isAudio = false)
                            }
                            .padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = track.name,
                            color = if (track.isSelected) EveAccent else Color.White,
                            fontWeight = if (track.isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        if (track.isSelected) {
                            Icon(imageVector = EveIcons.Check, contentDescription = null, tint = EveAccent)
                        }
                    }
                }
            }
        }
    }

    // Playback Speed Dialog
    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Playback Speed") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    speeds.forEach { speed ->
                        val isSel = playbackSpeed == speed
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playbackManager.setSpeed(speed)
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${speed}x",
                                color = if (isSel) EveAccent else MaterialTheme.colorScheme.onSurface,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // Sleep Timer Dialog
    if (showSleepTimerDialog) {
        val options = listOf(5, 10, 15, 30, 45, 60)
        AlertDialog(
            onDismissRequest = { showSleepTimerDialog = false },
            title = { Text("Sleep timer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (sleepTimerRemaining != null) {
                        TextButton(
                            onClick = {
                                playbackManager.cancelSleepTimer()
                                showSleepTimerDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Turn off sleep timer", color = EveAccent)
                        }
                    }
                    options.forEach { min ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playbackManager.startSleepTimer(min)
                                    showSleepTimerDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp)
                        ) {
                            Text("$min minutes")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSleepTimerDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun PlayerQuickChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    isHighlighted: Boolean = false,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isHighlighted) EveAccent.copy(alpha = 0.35f) else ChipBackground)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isHighlighted) EveAccent else Color.White,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal,
                color = if (isHighlighted) EveAccent else Color.White
            )
        }
    }
}

@Composable
fun PlayerOptionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xFF24242A)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
