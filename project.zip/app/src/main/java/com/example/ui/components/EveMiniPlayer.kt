package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MediaModel
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.theme.EveAccent
import com.example.ui.theme.LocalEveIconTint

@Composable
fun EveMiniPlayer(
    media: MediaModel?,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onPlayPauseClick: () -> Unit,
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    onOpenFullPlayer: () -> Unit,
    onDismissPlayer: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = media != null,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = modifier
    ) {
        if (media == null) return@AnimatedVisibility

        val progress = if (durationMs > 0) {
            (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable { onOpenFullPlayer() }
                .draggable(
                    orientation = Orientation.Vertical,
                    state = rememberDraggableState { delta ->
                        if (delta < -25) {
                            onOpenFullPlayer()
                        } else if (delta > 25) {
                            onDismissPlayer()
                        }
                    }
                )
        ) {
            // Thin accent progress line on top (2.5dp) strictly per PRD 3.4
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp),
                color = EveAccent,
                trackColor = Color.White.copy(alpha = 0.15f)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Cover 44dp (8dp radius)
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF222226)),
                    contentAlignment = Alignment.Center
                ) {
                    if (media.isVideo) {
                        EveIconButton(
                            imageVector = EveIcons.Video,
                            contentDescription = "Video",
                            onClick = onOpenFullPlayer,
                            iconSize = 24.dp
                        )
                    } else {
                        EveIconButton(
                            imageVector = EveIcons.Audio,
                            contentDescription = "Audio",
                            onClick = onOpenFullPlayer,
                            iconSize = 24.dp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Title and Artist
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = media.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (media.artist.isNotBlank()) media.artist else if (media.isVideo) media.bucketName else "eve media",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Controls: previous / play-pause / next (white in dark, iconTint in light)
                EveIconButton(
                    imageVector = EveIcons.Previous,
                    contentDescription = "Previous",
                    onClick = onPreviousClick,
                    iconSize = 28.dp
                )

                EveIconButton(
                    imageVector = if (isPlaying) EveIcons.Pause else EveIcons.Play,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    onClick = onPlayPauseClick,
                    iconSize = 32.dp
                )

                EveIconButton(
                    imageVector = EveIcons.Next,
                    contentDescription = "Next",
                    onClick = onNextClick,
                    iconSize = 28.dp
                )
            }
        }
    }
}
