package com.example.ui.screens.audio

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaModel
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.theme.EveAccent

enum class AudioSubTab(val title: String) {
    ARTISTS("Artists"),
    ALBUMS("Albums"),
    TRACKS("Tracks"),
    GENRES("Genres")
}

@Composable
fun AudioTabScreen(
    audios: List<MediaModel>,
    currentPlayingId: String?,
    isPlaying: Boolean,
    onTrackClick: (MediaModel) -> Unit,
    onPlayAll: (List<MediaModel>) -> Unit,
    onShuffleAll: (List<MediaModel>) -> Unit,
    onAppendToQueue: (MediaModel) -> Unit,
    onPlayNext: (MediaModel) -> Unit,
    onAddToPlaylist: (MediaModel) -> Unit,
    onDeleteTrack: (MediaModel) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(AudioSubTab.TRACKS) }
    var activeFilter by remember { mutableStateOf<String?>(null) }
    var filterType by remember { mutableStateOf<String?>(null) } // "artist", "album", "genre"

    Column(modifier = modifier.fillMaxSize()) {
        // Sub-tabs Row (PRD 5.1: Artists · Albums · Tracks · Genres)
        TabRow(
            selectedTabIndex = selectedTab.ordinal,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = EveAccent,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                    color = EveAccent
                )
            }
        ) {
            AudioSubTab.entries.forEach { tab ->
                val isSelected = selectedTab == tab
                Tab(
                    selected = isSelected,
                    onClick = {
                        selectedTab = tab
                        activeFilter = null
                        filterType = null
                    },
                    text = {
                        Text(
                            text = tab.title,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) EveAccent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    modifier = Modifier.testTag("audio_subtab_${tab.name.lowercase()}")
                )
            }
        }

        if (audios.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = EveIcons.Audio,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No audio tracks found",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Music and audio files will appear here",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else if (activeFilter != null) {
            // Filtered drill-down view (Album view or Artist view per PRD 5.3)
            val filteredTracks = remember(audios, activeFilter, filterType) {
                when (filterType) {
                    "artist" -> audios.filter { it.artist == activeFilter }
                    "album" -> audios.filter { it.album == activeFilter }
                    "genre" -> audios.filter { it.genre == activeFilter }
                    else -> audios
                }
            }

            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EveIconButton(
                        imageVector = EveIcons.Back,
                        contentDescription = "Back",
                        onClick = {
                            activeFilter = null
                            filterType = null
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeFilter ?: "",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${filteredTracks.size} tracks",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    EveIconButton(
                        imageVector = EveIcons.Play,
                        contentDescription = "Play all",
                        onClick = { onPlayAll(filteredTracks) }
                    )
                    EveIconButton(
                        imageVector = EveIcons.Shuffle,
                        contentDescription = "Shuffle all",
                        onClick = { onShuffleAll(filteredTracks) }
                    )
                }

                TrackList(
                    tracks = filteredTracks,
                    currentPlayingId = currentPlayingId,
                    isPlaying = isPlaying,
                    onTrackClick = onTrackClick,
                    onAppendToQueue = onAppendToQueue,
                    onPlayNext = onPlayNext,
                    onAddToPlaylist = onAddToPlaylist,
                    onDeleteTrack = onDeleteTrack
                )
            }
        } else {
            when (selectedTab) {
                AudioSubTab.TRACKS -> {
                    TrackList(
                        tracks = audios,
                        currentPlayingId = currentPlayingId,
                        isPlaying = isPlaying,
                        onTrackClick = onTrackClick,
                        onAppendToQueue = onAppendToQueue,
                        onPlayNext = onPlayNext,
                        onAddToPlaylist = onAddToPlaylist,
                        onDeleteTrack = onDeleteTrack
                    )
                }
                AudioSubTab.ARTISTS -> {
                    val artists = remember(audios) {
                        audios.groupBy { it.artist }.map { (artist, list) ->
                            artist to list
                        }.sortedBy { it.first.lowercase() }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(artists, key = { it.first }) { (artist, tracks) ->
                            GroupCard(
                                title = artist,
                                subtitle = "${tracks.size} tracks",
                                icon = EveIcons.Artist,
                                onClick = {
                                    activeFilter = artist
                                    filterType = "artist"
                                }
                            )
                        }
                    }
                }
                AudioSubTab.ALBUMS -> {
                    val albums = remember(audios) {
                        audios.groupBy { it.album }.map { (album, list) ->
                            album to list
                        }.sortedBy { it.first.lowercase() }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(albums, key = { it.first }) { (album, tracks) ->
                            val artist = tracks.firstOrNull()?.artist ?: "Unknown Artist"
                            GroupCard(
                                title = album,
                                subtitle = "$artist · ${tracks.size} tracks",
                                icon = EveIcons.Album,
                                onClick = {
                                    activeFilter = album
                                    filterType = "album"
                                }
                            )
                        }
                    }
                }
                AudioSubTab.GENRES -> {
                    val genres = remember(audios) {
                        audios.groupBy { if (it.genre.isNotBlank()) it.genre else "Other" }.map { (genre, list) ->
                            genre to list
                        }.sortedBy { it.first.lowercase() }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(genres, key = { it.first }) { (genre, tracks) ->
                            GroupCard(
                                title = genre,
                                subtitle = "${tracks.size} tracks",
                                icon = EveIcons.Audio,
                                onClick = {
                                    activeFilter = genre
                                    filterType = "genre"
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrackList(
    tracks: List<MediaModel>,
    currentPlayingId: String?,
    isPlaying: Boolean,
    onTrackClick: (MediaModel) -> Unit,
    onAppendToQueue: (MediaModel) -> Unit,
    onPlayNext: (MediaModel) -> Unit,
    onAddToPlaylist: (MediaModel) -> Unit,
    onDeleteTrack: (MediaModel) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(tracks, key = { it.id }) { track ->
            val isCurrent = track.id == currentPlayingId
            TrackListItem(
                track = track,
                isCurrent = isCurrent,
                isPlaying = isPlaying && isCurrent,
                onClick = { onTrackClick(track) },
                onAppendToQueue = { onAppendToQueue(track) },
                onPlayNext = { onPlayNext(track) },
                onAddToPlaylist = { onAddToPlaylist(track) },
                onDelete = { onDeleteTrack(track) }
            )
        }
    }
}

@Composable
fun TrackListItem(
    track: MediaModel,
    isCurrent: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onAppendToQueue: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .background(if (isCurrent) EveAccent.copy(alpha = 0.08f) else Color.Transparent)
            .padding(vertical = 8.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Leading: 40dp square cover art (rounded 6dp) or playing animated equalizer
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF222228)),
            contentAlignment = Alignment.Center
        ) {
            if (isCurrent && isPlaying) {
                // Animated 3-bar equalizer glyph in accent red (PRD 5.2)
                AnimatedEqualizerBars()
            } else {
                Icon(
                    imageVector = EveIcons.Audio,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = if (isCurrent) EveAccent else Color.White.copy(alpha = 0.45f)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Title and Subtitle: artist · album · duration
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isCurrent) EveAccent else MaterialTheme.colorScheme.onSurface
            )
            val subText = listOfNotNull(
                track.artist.ifBlank { null },
                track.album.ifBlank { null },
                track.durationFormatted.ifBlank { null }
            ).joinToString(" · ")

            Text(
                text = subText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Box {
            EveIconButton(
                imageVector = EveIcons.More,
                contentDescription = "Options",
                onClick = { menuExpanded = true },
                iconSize = 20.dp
            )

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Play") },
                    onClick = {
                        menuExpanded = false
                        onClick()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Play next") },
                    onClick = {
                        menuExpanded = false
                        onPlayNext()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Append to queue") },
                    onClick = {
                        menuExpanded = false
                        onAppendToQueue()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Add to playlist") },
                    onClick = {
                        menuExpanded = false
                        onAddToPlaylist()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Delete", color = EveAccent) },
                    onClick = {
                        menuExpanded = false
                        onDelete()
                    }
                )
            }
        }
    }
}

/**
 * Animated 3-bar equalizer glyph in accent red strictly per PRD 5.2
 */
@Composable
fun AnimatedEqualizerBars(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "eq_bars")
    val h1 by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "h1"
    )
    val h2 by transition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(350),
            repeatMode = RepeatMode.Reverse
        ),
        label = "h2"
    )
    val h3 by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450),
            repeatMode = RepeatMode.Reverse
        ),
        label = "h3"
    )

    Row(
        modifier = modifier.size(20.dp),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Box(
            modifier = Modifier
                .width(3.5.dp)
                .height(20.dp * h1)
                .background(EveAccent, RoundedCornerShape(1.dp))
        )
        Box(
            modifier = Modifier
                .width(3.5.dp)
                .height(20.dp * h2)
                .background(EveAccent, RoundedCornerShape(1.dp))
        )
        Box(
            modifier = Modifier
                .width(3.5.dp)
                .height(20.dp * h3)
                .background(EveAccent, RoundedCornerShape(1.dp))
        )
    }
}

@Composable
fun GroupCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF222228)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = Color.White.copy(alpha = 0.45f)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
