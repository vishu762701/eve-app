package com.example.ui.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.mediastore.MediaItemModel
import com.example.ui.theme.EveRedPrimary

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlayerBottomOverlay(
    currentPosition: Long,
    duration: Long,
    isPlaying: Boolean,
    pointA: Long?,
    pointB: Long?,
    isLandscape: Boolean,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onRewind10: () -> Unit,
    onForward10: () -> Unit,
    onSeek: (Long) -> Unit,
    onScrubbingChanged: (Boolean) -> Unit,
    onOpenTracks: () -> Unit,
    onToggleOrientation: () -> Unit,
    onCycleAspectRatio: () -> Unit,
    onLongPressAspectRatio: () -> Unit,
    onOpenMore: () -> Unit,
    onClearAbRepeat: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showRemainingTime by remember { mutableStateOf(false) }

    val hasAbRepeat = (pointA != null || pointB != null)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.Black.copy(alpha = 0.55f),
                        Color.Black.copy(alpha = 0.9f)
                    )
                )
            )
            .padding(top = 16.dp, bottom = 12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {

            // 4. A-B Repeat Active Buttons: above time at bottom-left
            if (hasAbRepeat) {
                Row(
                    modifier = Modifier
                        .padding(start = 24.dp, bottom = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF141414).copy(alpha = 0.85f))
                            .clickable(onClick = onClearAbRepeat)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset A-B",
                            tint = EveRedPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset A-B", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF141414).copy(alpha = 0.85f))
                            .clickable(onClick = onClearAbRepeat)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop Repeat",
                            tint = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stop Repeat", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            // 3. Time texts above the seek bar:
            // elapsed on left (margin start 24dp), total/remaining on right (margin end 24dp)
            // Tapping either one toggles the right text
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = MediaItemModel.formatDuration(currentPosition),
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        showRemainingTime = !showRemainingTime
                    }
                )

                val rightTimeText = if (showRemainingTime) {
                    val remaining = (duration - currentPosition).coerceAtLeast(0L)
                    "-${MediaItemModel.formatDuration(remaining)}"
                } else {
                    MediaItemModel.formatDuration(duration)
                }

                Text(
                    text = rightTimeText,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        showRemainingTime = !showRemainingTime
                    }
                )
            }

            // 2. Seek Bar above control row: full width, 4dp visible track, round thumb expanding on press
            EveSeekBar(
                currentPosition = currentPosition,
                duration = duration,
                pointA = pointA,
                pointB = pointB,
                onScrubbingChanged = onScrubbingChanged,
                onSeek = onSeek,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            )

            // 1. Control Row, one single row, 3 groups spread across the width:
            // LEFT: audio/sub (32dp), orientation lock (32dp)
            // CENTER: prev (32dp), rewind 10s (32dp with 8sp "10"), PLAY/PAUSE (48dp), fwd 10s (32dp with 8sp "10"), next (32dp)
            // RIGHT: aspect-ratio (32dp), more (32dp)
            // Side margins: 0dp in portrait, 24dp in landscape.
            // Center gap: 8dp in portrait, 24dp in landscape.
            val sideMargin = if (isLandscape) 24.dp else 0.dp
            val centerGap = if (isLandscape) 24.dp else 8.dp

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = sideMargin, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // LEFT GROUP: Audio/sub tracks (32dp) + Orientation lock (32dp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(start = 12.dp)
                ) {
                    IconButton(
                        onClick = onOpenTracks,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Subtitles,
                            contentDescription = "Tracks & Subtitles",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    IconButton(
                        onClick = onToggleOrientation,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ScreenRotation,
                            contentDescription = "Orientation Lock",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                // CENTER GROUP: Previous (32dp), Rewind 10s (32dp), PLAY/PAUSE (48dp), Forward 10s (32dp), Next (32dp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(centerGap)
                ) {
                    // Previous (32dp)
                    IconButton(
                        onClick = onPrevious,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Rewind 10s (32dp, small bold 8sp "10" number)
                    IconButton(
                        onClick = onRewind10,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    ) {
                        Rewind10Icon(tint = Color.White)
                    }

                    // PLAY / PAUSE (48dp, crossfade animation)
                    IconButton(
                        onClick = onPlayPause,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                    ) {
                        AnimatedContent(
                            targetState = isPlaying,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(150)) togetherWith fadeOut(animationSpec = tween(150))
                            },
                            label = "PlayPauseCrossfade"
                        ) { playing ->
                            if (playing) {
                                Icon(
                                    imageVector = Icons.Default.Pause,
                                    contentDescription = "Pause",
                                    tint = Color.White,
                                    modifier = Modifier.size(48.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(48.dp)
                                )
                            }
                        }
                    }

                    // Forward 10s (32dp, small bold 8sp "10" number)
                    IconButton(
                        onClick = onForward10,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    ) {
                        Forward10Icon(tint = Color.White)
                    }

                    // Next (32dp)
                    IconButton(
                        onClick = onNext,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                // RIGHT GROUP: Aspect ratio (32dp) + More (32dp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(end = 12.dp)
                ) {
                    // Aspect ratio icon: tap = cycle modes, long-press = open menu with all modes
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .combinedClickable(
                                onClick = onCycleAspectRatio,
                                onLongClick = onLongPressAspectRatio
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AspectRatio,
                            contentDescription = "Aspect Ratio",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // More icon (32dp): opens advanced options
                    IconButton(
                        onClick = onOpenMore,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More Options",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }
    }
}
