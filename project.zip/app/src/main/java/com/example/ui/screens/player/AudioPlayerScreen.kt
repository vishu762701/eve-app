package com.example.ui.screens.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.playback.MediaPlaybackManager
import com.example.playback.RepeatState
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.icons.EveSkipButton
import com.example.ui.theme.EveAccent
import com.example.ui.theme.TrackInactiveDark
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioPlayerScreen(
    playbackManager: MediaPlaybackManager,
    onCollapse: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentMedia by playbackManager.currentMedia.collectAsState()
    val isPlaying by playbackManager.isPlaying.collectAsState()
    val currentPosition by playbackManager.currentPosition.collectAsState()
    val duration by playbackManager.duration.collectAsState()
    val repeatState by playbackManager.repeatState.collectAsState()
    val isShuffle by playbackManager.isShuffle.collectAsState()
    val queue by playbackManager.queue.collectAsState()
    val currentIndex by playbackManager.currentIndex.collectAsState()
    val playbackSpeed by playbackManager.playbackSpeed.collectAsState()

    var showQueueSheet by remember { mutableStateOf(false) }
    var isFavorite by remember { mutableStateOf(false) }

    val progress = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
    var isSeeking by remember { mutableStateOf(false) }
    var seekValue by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF16161D),
                        Color(0xFF0C0C0E),
                        Color(0xFF000000)
                    )
                )
            )
            .statusBarsPadding()
            .testTag("audio_player_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header: collapse button, 'Now playing' title, queue toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EveIconButton(
                    imageVector = EveIcons.Back,
                    contentDescription = "Collapse",
                    onClick = onCollapse,
                    iconSize = 26.dp
                )

                Text(
                    text = "Now playing",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = Color.White
                )

                EveIconButton(
                    imageVector = EveIcons.Queue,
                    contentDescription = "Queue",
                    onClick = { showQueueSheet = true },
                    iconSize = 26.dp
                )
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // Album Art: 260dp square, rounded 16dp, subtle drop shadow (PRD 10.2)
            // Swipeable left/right to change tracks!
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .shadow(16.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1F1F26))
                    .draggable(
                        orientation = Orientation.Horizontal,
                        state = rememberDraggableState { delta ->
                            if (delta < -30) {
                                playbackManager.next()
                            } else if (delta > 30) {
                                playbackManager.previous()
                            }
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = EveIcons.Audio,
                    contentDescription = null,
                    modifier = Modifier.size(96.dp),
                    tint = EveAccent.copy(alpha = 0.85f)
                )
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // Track info: Title 20sp bold, Artist 15sp, Favorite heart
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentMedia?.title ?: "No audio track",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = currentMedia?.artist?.ifBlank { "Unknown Artist" } ?: "Unknown Artist",
                        fontSize = 15.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                EveIconButton(
                    imageVector = if (isFavorite) EveIcons.Favorite else EveIcons.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) EveAccent else Color.White.copy(alpha = 0.7f),
                    onClick = { isFavorite = !isFavorite }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Seek bar
            Slider(
                value = if (isSeeking) seekValue else progress,
                onValueChange = {
                    isSeeking = true
                    seekValue = it
                },
                onValueChangeFinished = {
                    isSeeking = false
                    val targetMs = (seekValue * duration).toLong()
                    playbackManager.seekTo(targetMs)
                },
                colors = SliderDefaults.colors(
                    thumbColor = EveAccent,
                    activeTrackColor = EveAccent,
                    inactiveTrackColor = TrackInactiveDark
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Elapsed and Remaining time row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val elapsedSec = currentPosition / 1000
                Text(
                    text = String.format(Locale.US, "%02d:%02d", elapsedSec / 60, elapsedSec % 60),
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.6f)
                )

                val remSec = ((duration - currentPosition) / 1000).coerceAtLeast(0)
                Text(
                    text = String.format(Locale.US, "-%02d:%02d", remSec / 60, remSec % 60),
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Controls row: shuffle, previous, play/pause (48dp solid glyph), next, repeat
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EveIconButton(
                    imageVector = EveIcons.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (isShuffle) EveAccent else Color.White.copy(alpha = 0.6f),
                    onClick = { playbackManager.toggleShuffle() },
                    iconSize = 24.dp
                )

                EveIconButton(
                    imageVector = EveIcons.Previous,
                    contentDescription = "Previous",
                    onClick = { playbackManager.previous() },
                    iconSize = 36.dp
                )

                // Play/Pause button (48dp solid glyph, NO circle background per PRD 2.4!)
                EveIconButton(
                    imageVector = if (isPlaying) EveIcons.Pause else EveIcons.Play,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    onClick = { playbackManager.togglePlayPause() },
                    iconSize = 48.dp,
                    tint = Color.White
                )

                EveIconButton(
                    imageVector = EveIcons.Next,
                    contentDescription = "Next",
                    onClick = { playbackManager.next() },
                    iconSize = 36.dp
                )

                EveIconButton(
                    imageVector = if (repeatState == RepeatState.ONE) EveIcons.RepeatOne else EveIcons.Repeat,
                    contentDescription = "Repeat",
                    tint = if (repeatState != RepeatState.OFF) EveAccent else Color.White.copy(alpha = 0.6f),
                    onClick = { playbackManager.toggleRepeat() },
                    iconSize = 24.dp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Secondary controls: Rewind 10s, Forward 10s, Speed chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EveSkipButton(
                    seconds = 10,
                    isForward = false,
                    onClick = { playbackManager.jumpBy(-10) }
                )
                Spacer(modifier = Modifier.width(16.dp))
                PlayerQuickChip(
                    label = "${playbackSpeed}x",
                    icon = EveIcons.Speed,
                    onClick = {
                        val next = when (playbackSpeed) {
                            1.0f -> 1.25f
                            1.25f -> 1.5f
                            1.5f -> 2.0f
                            else -> 1.0f
                        }
                        playbackManager.setSpeed(next)
                    }
                )
                Spacer(modifier = Modifier.width(16.dp))
                EveSkipButton(
                    seconds = 10,
                    isForward = true,
                    onClick = { playbackManager.jumpBy(10) }
                )
            }

            Spacer(modifier = Modifier.weight(0.4f))
        }
    }

    // Queue Bottom Sheet (PRD 10.3)
    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = Color(0xFF141418)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Playing Queue (${queue.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(queue) { idx, track ->
                        val isCurrent = idx == currentIndex
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playbackManager.playPlaylist(queue, startIndex = idx)
                                    showQueueSheet = false
                                }
                                .background(if (isCurrent) EveAccent.copy(alpha = 0.12f) else Color.Transparent)
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${idx + 1}",
                                fontSize = 12.sp,
                                color = if (isCurrent) EveAccent else Color.White.copy(alpha = 0.5f),
                                modifier = Modifier.width(24.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = track.title,
                                    fontSize = 14.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isCurrent) EveAccent else Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = track.artist,
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.6f),
                                    maxLines = 1
                                )
                            }
                            EveIconButton(
                                imageVector = EveIcons.Close,
                                contentDescription = "Remove",
                                onClick = { playbackManager.removeFromQueue(idx) },
                                iconSize = 18.dp
                            )
                        }
                    }
                }
            }
        }
    }
}
