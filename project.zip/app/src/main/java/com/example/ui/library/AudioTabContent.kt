package com.example.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PlaylistEntity
import com.example.data.mediastore.MediaItemModel
import com.example.ui.components.AlbumGridCard
import com.example.ui.components.ArtistRow
import com.example.ui.components.GenreCard
import com.example.ui.components.MediaInfoDialog
import com.example.ui.components.MediaItemListRow
import com.example.ui.components.PlaylistCard
import com.example.ui.theme.EveRedPrimary
import kotlinx.coroutines.launch

enum class AudioCategory(val title: String) {
    TRACKS("Tracks"),
    ALBUMS("Albums"),
    ARTISTS("Artists"),
    GENRES("Genres"),
    PLAYLISTS("Playlists")
}

@Composable
fun AudioTabContent(
    audios: List<MediaItemModel>,
    playlists: List<PlaylistEntity>,
    onPlayAudio: (MediaItemModel, List<MediaItemModel>) -> Unit,
    onPlayNext: (MediaItemModel) -> Unit,
    onAddToPlaylist: (MediaItemModel) -> Unit,
    onToggleFavorite: (MediaItemModel) -> Unit,
    onShare: (MediaItemModel) -> Unit,
    onDelete: (MediaItemModel) -> Unit,
    onShuffleAll: (List<MediaItemModel>) -> Unit,
    onRefresh: () -> Unit,
    isScanning: Boolean,
    onOpenPlaylist: (PlaylistEntity) -> Unit
) {
    var selectedCategory by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val trackListState = rememberLazyListState()

    // Drill-down states
    var activeSubFilter by remember { mutableStateOf<Pair<String, List<MediaItemModel>>?>(null) }
    var selectedItemForInfo by remember { mutableStateOf<MediaItemModel?>(null) }

    if (selectedItemForInfo != null) {
        MediaInfoDialog(
            item = selectedItemForInfo!!,
            onDismiss = { selectedItemForInfo = null }
        )
    }

    if (activeSubFilter != null) {
        val (subTitle, subItems) = activeSubFilter!!
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { activeSubFilter = null }) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        subTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${subItems.size} tracks",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { onShuffleAll(subItems) },
                    colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Shuffle", fontSize = 13.sp)
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(bottom = 16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(subItems, key = { it.uri.toString() }) { track ->
                    MediaItemListRow(
                        item = track,
                        onClick = { onPlayAudio(track, subItems) },
                        onToggleFavorite = { onToggleFavorite(track) },
                        onAddToPlaylist = { onAddToPlaylist(track) },
                        onAddToQueue = { onPlayNext(track) },
                        onDelete = { onDelete(track) }
                    )
                }
            }
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Sub-categories: Tracks, Albums, Artists, Genres, Playlists
        ScrollableTabRow(
            selectedTabIndex = selectedCategory,
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = EveRedPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedCategory]),
                    color = EveRedPrimary,
                    height = 2.5.dp
                )
            },
            divider = {}
        ) {
            AudioCategory.entries.forEachIndexed { index, cat ->
                Tab(
                    selected = selectedCategory == index,
                    onClick = { selectedCategory = index },
                    text = {
                        Text(
                            cat.title,
                            fontWeight = if (selectedCategory == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    },
                    selectedContentColor = EveRedPrimary,
                    unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Shuffle All button bar for Tracks & Albums
        if (audios.isNotEmpty() && selectedCategory == 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${audios.size} Tracks",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )

                Button(
                    onClick = { onShuffleAll(audios) },
                    colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Shuffle All", fontSize = 13.sp)
                }
            }
        }

        if (audios.isEmpty()) {
            EmptyAudioView(onRefresh = onRefresh, isScanning = isScanning)
            return
        }

        when (AudioCategory.entries[selectedCategory]) {
            AudioCategory.TRACKS -> {
                // Tracks view with Fast Scroll Index
                Box(modifier = Modifier.fillMaxSize()) {
                    LazyColumn(
                        state = trackListState,
                        contentPadding = PaddingValues(bottom = 16.dp, end = 28.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(audios, key = { it.uri.toString() }) { track ->
                            MediaItemListRow(
                                item = track,
                                onClick = { onPlayAudio(track, audios) },
                                onToggleFavorite = { onToggleFavorite(track) },
                                onAddToPlaylist = { onAddToPlaylist(track) },
                                onAddToQueue = { onPlayNext(track) },
                                onDelete = { onDelete(track) }
                            )
                        }
                    }

                    // Alphabet index bar on right
                    val alphabet = ('A'..'Z').toList()
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .fillMaxHeight()
                            .padding(end = 4.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        alphabet.forEach { letter ->
                            Text(
                                text = letter.toString(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .clickable {
                                        val idx = audios.indexOfFirst {
                                            it.title.startsWith(letter, ignoreCase = true)
                                        }
                                        if (idx != -1) {
                                            scope.launch { trackListState.animateScrollToItem(idx) }
                                        }
                                    }
                                    .padding(vertical = 1.dp, horizontal = 2.dp)
                            )
                        }
                    }
                }
            }

            AudioCategory.ALBUMS -> {
                // Group by album
                val albums = remember(audios) {
                    audios.groupBy { it.album.ifBlank { "Unknown Album" } }
                        .map { (albumName, tracks) ->
                            AlbumInfo(
                                name = albumName,
                                artist = tracks.firstOrNull()?.artist ?: "Unknown Artist",
                                trackCount = tracks.size,
                                tracks = tracks
                            )
                        }
                        .sortedBy { it.name }
                }

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(albums, key = { it.name }) { album ->
                        AlbumGridCard(
                            albumName = album.name,
                            artistName = album.artist,
                            trackCount = album.trackCount,
                            onClick = {
                                activeSubFilter = album.name to album.tracks
                            }
                        )
                    }
                }
            }

            AudioCategory.ARTISTS -> {
                // Group by artist
                val artists = remember(audios) {
                    audios.groupBy { it.artist.ifBlank { "Unknown Artist" } }
                        .map { (artistName, tracks) ->
                            ArtistInfo(
                                name = artistName,
                                trackCount = tracks.size,
                                tracks = tracks
                            )
                        }
                        .sortedBy { it.name }
                }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(artists, key = { it.name }) { artist ->
                        ArtistRow(
                            artistName = artist.name,
                            trackCount = artist.trackCount,
                            onClick = {
                                activeSubFilter = artist.name to artist.tracks
                            }
                        )
                    }
                }
            }

            AudioCategory.GENRES -> {
                // Group by genre
                val genres = remember(audios) {
                    audios.groupBy { it.genre.ifBlank { "Various" } }
                        .map { (genreName, tracks) ->
                            GenreInfo(
                                name = genreName,
                                trackCount = tracks.size,
                                tracks = tracks
                            )
                        }
                        .sortedBy { it.name }
                }

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(genres, key = { it.name }) { genre ->
                        GenreCard(
                            genreName = genre.name,
                            trackCount = genre.trackCount,
                            onClick = {
                                activeSubFilter = genre.name to genre.tracks
                            }
                        )
                    }
                }
            }

            AudioCategory.PLAYLISTS -> {
                if (playlists.isEmpty()) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Text(
                            "No playlists yet",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(playlists, key = { it.id }) { playlist ->
                            PlaylistCard(
                                playlist = playlist,
                                onClick = { onOpenPlaylist(playlist) },
                                onPlay = { onOpenPlaylist(playlist) },
                                onRename = {},
                                onDelete = {}
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class AlbumInfo(
    val name: String,
    val artist: String,
    val trackCount: Int,
    val tracks: List<MediaItemModel>
)

private data class ArtistInfo(
    val name: String,
    val trackCount: Int,
    val tracks: List<MediaItemModel>
)

private data class GenreInfo(
    val name: String,
    val trackCount: Int,
    val tracks: List<MediaItemModel>
)

@Composable
private fun EmptyAudioView(
    onRefresh: () -> Unit,
    isScanning: Boolean
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                shape = CircleShape,
                color = EveRedPrimary.copy(alpha = 0.12f),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.Audiotrack,
                        contentDescription = null,
                        tint = EveRedPrimary,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "No audio tracks found",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                "Transfer your songs and audio files to device storage to play them offline in eve.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onRefresh,
                enabled = !isScanning,
                colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isScanning) "Scanning Storage..." else "Scan Storage")
            }
        }
    }
}
