package com.example.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Build
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.draw.clip
import com.example.ui.theme.EveRedPrimary
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.EveApplication
import com.example.data.preferences.UserSettings
import com.example.player.AspectRatioMode
import com.example.player.MediaPlaybackManager
import com.example.ui.components.AudioDelayDialog
import com.example.ui.components.EqualizerBottomSheet
import com.example.ui.components.QueueBottomSheet
import com.example.ui.components.SleepTimerDialog
import com.example.ui.components.SubtitleSettingsDialog
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

private enum class PlayerGestureMode {
    NONE, BRIGHTNESS, VOLUME, SEEK, PINCH
}

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(
    playbackManager: MediaPlaybackManager,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // User settings preferences
    val app = EveApplication.instance
    val userSettings by app.preferencesRepository.userSettingsFlow.collectAsState(initial = UserSettings())

    // Player state from MediaPlaybackManager
    val currentMedia by playbackManager.currentMediaItem.collectAsState()
    val isPlaying by playbackManager.isPlaying.collectAsState()
    val currentPosition by playbackManager.currentPosition.collectAsState()
    val duration by playbackManager.duration.collectAsState()
    val playbackSpeed by playbackManager.playbackSpeed.collectAsState()
    val aspectRatioMode by playbackManager.aspectRatioMode.collectAsState()
    val repeatMode by playbackManager.repeatMode.collectAsState()
    val shuffleMode by playbackManager.shuffleMode.collectAsState()
    val queue by playbackManager.queue.collectAsState()
    val currentQueueIndex by playbackManager.currentQueueIndex.collectAsState()

    val audioTracks by playbackManager.audioTracks.collectAsState()
    val subtitleTracks by playbackManager.subtitleTracks.collectAsState()
    val audioDelayMs by playbackManager.audioDelayMs.collectAsState()
    val subtitleDelayMs by playbackManager.subtitleDelayMs.collectAsState()
    val pointA by playbackManager.abRepeatPointA.collectAsState()
    val pointB by playbackManager.abRepeatPointB.collectAsState()
    val sleepTimerSec by playbackManager.sleepTimerRemainingSeconds.collectAsState()

    // Audio manager for volume control
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var currentVolumeRatio by remember {
        val initialVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        mutableFloatStateOf(initialVol.toFloat() / maxVolume.toFloat())
    }

    // Window brightness state
    var currentBrightness by remember {
        val attr = activity?.window?.attributes
        val b = if (attr != null && attr.screenBrightness in 0f..1f) attr.screenBrightness else 0.5f
        mutableFloatStateOf(b)
    }

    // UI overlays & lock state
    var areControlsVisible by remember { mutableStateOf(true) }
    var isScreenLocked by remember { mutableStateOf(false) }
    var isUserScrubbingSeekBar by remember { mutableStateOf(false) }

    // HUD overlays
    var showBrightnessHud by remember { mutableStateOf(false) }
    var showVolumeHud by remember { mutableStateOf(false) }
    var showSeekHud by remember { mutableStateOf(false) }
    var seekTargetPosition by remember { mutableLongStateOf(0L) }
    var seekDeltaMs by remember { mutableLongStateOf(0L) }
    var showFastPlayBadge by remember { mutableStateOf(false) }

    var showDoubleTapBadge by remember { mutableStateOf(false) }
    var doubleTapBadgeForward by remember { mutableStateOf(true) }
    var doubleTapBadgeSec by remember { mutableIntStateOf(20) }

    // Video scale for pinch zoom
    var videoScale by remember { mutableFloatStateOf(1.0f) }

    // Dialog & Bottom Sheet visibility
    var showMoreSheet by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showJumpToTimeDialog by remember { mutableStateOf(false) }
    var showVideoInfoDialog by remember { mutableStateOf(false) }
    var showAspectRatioMenuDialog by remember { mutableStateOf(false) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showAudioDelayDialog by remember { mutableStateOf(false) }
    var showSubtitleSettingsDialog by remember { mutableStateOf(false) }
    var showAbRepeatDialog by remember { mutableStateOf(false) }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    // Subtitle file picker launcher
    val subtitlePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            playbackManager.loadExternalSubtitle(uri, label = uri.lastPathSegment ?: "External Subtitle")
            scope.launch { snackbarHostState.showSnackbar("Subtitle loaded: ${uri.lastPathSegment}") }
        }
    }

    // Screenshot helper function
    val triggerScreenshot: () -> Unit = {
        val media = currentMedia
        if (media == null) {
            scope.launch { snackbarHostState.showSnackbar("No active video to capture") }
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("Capturing frame...")
                val savedUri = VideoFrameCapture.captureAndSaveFrame(context, media, currentPosition)
                if (savedUri != null) {
                    snackbarHostState.showSnackbar("Screenshot saved to Pictures/eve")
                } else {
                    snackbarHostState.showSnackbar("Failed to capture screenshot")
                }
            }
        }
    }

    // Auto-hide controls timer:
    // Auto-hide after 4 seconds while playing.
    // Never auto-hide while paused or while dragging the seek bar.
    LaunchedEffect(areControlsVisible, isPlaying, isUserScrubbingSeekBar) {
        if (areControlsVisible && isPlaying && !isUserScrubbingSeekBar && !isScreenLocked) {
            delay(4000L)
            areControlsVisible = false
        }
    }

    // System bars immersion management
    DisposableEffect(areControlsVisible, isScreenLocked) {
        val window = activity?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (!areControlsVisible || isScreenLocked) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            val window = activity?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Keep screen on during playback
    DisposableEffect(Unit) {
        val window = activity?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        // VIDEO SURFACE BOX:
        // Enforce 16:9 and 4:3 ratios when selected!
        val videoContainerModifier = when (aspectRatioMode) {
            AspectRatioMode.RATIO_16_9 -> Modifier
                .aspectRatio(16f / 9f, matchHeightConstraintsFirst = isLandscape)
            AspectRatioMode.RATIO_4_3 -> Modifier
                .aspectRatio(4f / 3f, matchHeightConstraintsFirst = isLandscape)
            else -> Modifier.fillMaxSize()
        }

        Box(
            modifier = videoContainerModifier,
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = playbackManager.getExoPlayer()
                        useController = false
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { playerView ->
                    playerView.player = playbackManager.getExoPlayer()
                    playerView.resizeMode = when (aspectRatioMode) {
                        AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        AspectRatioMode.CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        AspectRatioMode.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        AspectRatioMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = videoScale,
                        scaleY = videoScale
                    )
            )
        }

        // GESTURE HANDLING OVERLAY
        var lastTapTime by remember { mutableLongStateOf(0L) }
        var lastTapPos by remember { mutableStateOf(Offset.Zero) }
        var singleTapJob by remember { mutableStateOf<Job?>(null) }
        var doubleTapJob by remember { mutableStateOf<Job?>(null) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isScreenLocked, userSettings, duration, currentPosition, playbackSpeed) {
                    if (isScreenLocked) return@pointerInput

                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val startPos = down.position
                        val downTime = System.currentTimeMillis()
                        var currentPointers = 1
                        var maxPointers = 1
                        var isLongPressActive = false
                        var gestureMode = PlayerGestureMode.NONE
                        var initialSpeed = playbackSpeed
                        var seekAccumulatorPx = 0f
                        var initialSeekPos = currentPosition
                        var hasMovedBeyondSlop = false
                        var previousDistance = 0f

                        // Long-press detection: hold down 450ms for 2.0x speed
                        val longPressJob = scope.launch {
                            delay(450L)
                            if (!hasMovedBeyondSlop && currentPointers == 1) {
                                isLongPressActive = true
                                showFastPlayBadge = true
                                initialSpeed = playbackSpeed
                                playbackManager.setPlaybackSpeed(2.0f)
                            }
                        }

                        try {
                            while (true) {
                                val event = awaitPointerEvent()
                                val activeChanges = event.changes.filter { it.pressed }
                                currentPointers = activeChanges.size
                                if (currentPointers > maxPointers) {
                                    maxPointers = currentPointers
                                }

                                if (activeChanges.isEmpty()) {
                                    break
                                }

                                // 2-finger pinch zoom
                                if (currentPointers == 2 && userSettings.gesturePinchZoomEnabled) {
                                    longPressJob.cancel()
                                    gestureMode = PlayerGestureMode.PINCH
                                    val p1 = activeChanges[0].position
                                    val p2 = activeChanges[1].position
                                    val dx = p1.x - p2.x
                                    val dy = p1.y - p2.y
                                    val dist = sqrt(dx * dx + dy * dy)
                                    if (previousDistance > 0f) {
                                        val zoomFactor = dist / previousDistance
                                        videoScale = (videoScale * zoomFactor).coerceIn(0.5f, 3.0f)
                                    }
                                    previousDistance = dist
                                    activeChanges.forEach { it.consume() }
                                    continue
                                }

                                if (currentPointers == 1 && !isLongPressActive) {
                                    val change = activeChanges[0]
                                    val totalDx = change.position.x - startPos.x
                                    val totalDy = change.position.y - startPos.y

                                    if (!hasMovedBeyondSlop) {
                                        if (abs(totalDx) > 16 || abs(totalDy) > 16) {
                                            hasMovedBeyondSlop = true
                                            longPressJob.cancel()
                                        }
                                    }

                                    if (gestureMode == PlayerGestureMode.NONE && hasMovedBeyondSlop) {
                                        val isVertical = abs(totalDy) > 2 * abs(totalDx) && abs(totalDy) >= size.height * 0.05f
                                        val isHorizontal = abs(totalDx) > 2 * abs(totalDy) && abs(totalDx) >= 20

                                        if (isVertical) {
                                            val xRatio = startPos.x / size.width
                                            if (xRatio < 3f / 7f) {
                                                if (userSettings.gestureBrightnessEnabled) {
                                                    gestureMode = PlayerGestureMode.BRIGHTNESS
                                                }
                                            } else if (xRatio > 4f / 7f) {
                                                if (userSettings.gestureVolumeEnabled) {
                                                    gestureMode = PlayerGestureMode.VOLUME
                                                }
                                            }
                                        } else if (isHorizontal) {
                                            if (userSettings.gestureSeekEnabled) {
                                                gestureMode = PlayerGestureMode.SEEK
                                                initialSeekPos = currentPosition
                                                seekAccumulatorPx = 0f
                                            }
                                        }
                                    }

                                    when (gestureMode) {
                                        PlayerGestureMode.BRIGHTNESS -> {
                                            change.consume()
                                            val deltaRatio = -change.positionChange().y / size.height
                                            currentBrightness = (currentBrightness + deltaRatio).coerceIn(0.01f, 1f)
                                            activity?.let { act ->
                                                val lp = act.window.attributes
                                                lp.screenBrightness = currentBrightness
                                                act.window.attributes = lp
                                            }
                                            showBrightnessHud = true
                                        }
                                        PlayerGestureMode.VOLUME -> {
                                            change.consume()
                                            val deltaRatio = -change.positionChange().y / size.height
                                            currentVolumeRatio = (currentVolumeRatio + deltaRatio).coerceIn(0f, 1f)
                                            val targetVol = (currentVolumeRatio * maxVolume).roundToInt().coerceIn(0, maxVolume)
                                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                                            showVolumeHud = true
                                        }
                                        PlayerGestureMode.SEEK -> {
                                            change.consume()
                                            seekAccumulatorPx += change.positionChange().x
                                            val seekWindowMs = (duration.coerceAtLeast(60000L).coerceAtMost(3600000L) / 4).coerceAtLeast(30000L)
                                            val deltaMs = ((seekAccumulatorPx / size.width) * seekWindowMs).toLong()
                                            seekTargetPosition = (initialSeekPos + deltaMs).coerceIn(0L, duration.coerceAtLeast(0L))
                                            seekDeltaMs = seekTargetPosition - initialSeekPos
                                            showSeekHud = true
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        } finally {
                            longPressJob.cancel()
                            if (isLongPressActive) {
                                showFastPlayBadge = false
                                playbackManager.setPlaybackSpeed(initialSpeed)
                            }

                            if (gestureMode == PlayerGestureMode.SEEK) {
                                playbackManager.seekTo(seekTargetPosition)
                                scope.launch {
                                    delay(1000L)
                                    showSeekHud = false
                                }
                            } else if (gestureMode == PlayerGestureMode.BRIGHTNESS || gestureMode == PlayerGestureMode.VOLUME) {
                                scope.launch {
                                    delay(1000L)
                                    showBrightnessHud = false
                                    showVolumeHud = false
                                }
                            } else if (gestureMode == PlayerGestureMode.NONE && !hasMovedBeyondSlop) {
                                // TAP GESTURE
                                if (maxPointers == 3) {
                                    // Three finger tap = screenshot
                                    triggerScreenshot()
                                } else if (maxPointers == 1) {
                                    val tapPos = startPos
                                    val now = System.currentTimeMillis()
                                    val dist = sqrt((tapPos.x - lastTapPos.x) * (tapPos.x - lastTapPos.x) + (tapPos.y - lastTapPos.y) * (tapPos.y - lastTapPos.y))

                                    if (now - lastTapTime < 320L && dist < 70f) {
                                        // Double Tap
                                        singleTapJob?.cancel()
                                        singleTapJob = null
                                        lastTapTime = 0L

                                        if (userSettings.gestureDoubleTapEnabled) {
                                            val xRatio = tapPos.x / size.width
                                            val jumpSec = if (userSettings.defaultSeekIntervalSec > 0) userSettings.defaultSeekIntervalSec else 20

                                            if (xRatio < 0.25f) {
                                                // Jump back 20s
                                                playbackManager.seekBy(-jumpSec * 1000L)
                                                doubleTapBadgeForward = false
                                                doubleTapBadgeSec = jumpSec
                                                showDoubleTapBadge = true
                                                doubleTapJob?.cancel()
                                                doubleTapJob = scope.launch {
                                                    delay(800L)
                                                    showDoubleTapBadge = false
                                                }
                                            } else if (xRatio > 0.75f) {
                                                // Jump forward 20s
                                                playbackManager.seekBy(jumpSec * 1000L)
                                                doubleTapBadgeForward = true
                                                doubleTapBadgeSec = jumpSec
                                                showDoubleTapBadge = true
                                                doubleTapJob?.cancel()
                                                doubleTapJob = scope.launch {
                                                    delay(800L)
                                                    showDoubleTapBadge = false
                                                }
                                            } else {
                                                // Middle half: play/pause
                                                playbackManager.togglePlayPause()
                                            }
                                        } else {
                                            areControlsVisible = !areControlsVisible
                                        }
                                    } else {
                                        // Potential single tap
                                        lastTapTime = now
                                        lastTapPos = tapPos
                                        singleTapJob = scope.launch {
                                            delay(300L)
                                            areControlsVisible = !areControlsVisible
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        )

        // HUD OVERLAYS:
        // Brightness HUD Slider (left side)
        BrightnessHudSlider(
            brightness = currentBrightness,
            visible = showBrightnessHud,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 24.dp)
        )

        // Volume HUD Slider (right side)
        VolumeHudSlider(
            volumeRatio = currentVolumeRatio,
            visible = showVolumeHud,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp)
        )

        // Seek HUD (center)
        SeekHudOverlay(
            targetPosition = seekTargetPosition,
            deltaMs = seekDeltaMs,
            duration = duration,
            visible = showSeekHud,
            modifier = Modifier.align(Alignment.Center)
        )

        // Fast-Play 2.0x Badge (top center)
        FastPlayBadge(
            visible = showFastPlayBadge,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
        )

        // Double-Tap Seek Badge (left or right side)
        if (showDoubleTapBadge) {
            DoubleTapSeekBadge(
                isForward = doubleTapBadgeForward,
                seconds = doubleTapBadgeSec,
                visible = showDoubleTapBadge,
                modifier = Modifier
                    .align(if (doubleTapBadgeForward) Alignment.CenterEnd else Alignment.CenterStart)
                    .padding(horizontal = 48.dp)
            )
        }

        // TOP OVERLAY (translucent dark scrim, 150ms animated visibility)
        AnimatedVisibility(
            visible = areControlsVisible && !isScreenLocked,
            enter = fadeIn(animationSpec = tween(150)) + slideInVertically(
                animationSpec = tween(150),
                initialOffsetY = { -it / 2 }
            ),
            exit = fadeOut(animationSpec = tween(150)) + slideOutVertically(
                animationSpec = tween(150),
                targetOffsetY = { -it / 2 }
            ),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            PlayerTopOverlay(
                title = currentMedia?.title ?: "Video",
                playlistSize = queue.size,
                playbackSpeed = playbackSpeed,
                sleepTimerSec = sleepTimerSec,
                subtitleDelayMs = subtitleDelayMs,
                audioDelayMs = audioDelayMs,
                onBack = onBack,
                onScreenshot = triggerScreenshot,
                onOpenQueue = { showQueueSheet = true },
                onOpenSpeed = { showSpeedDialog = true },
                onOpenSleepTimer = { showSleepTimerDialog = true },
                onOpenSubtitleSettings = { showSubtitleSettingsDialog = true },
                onResetSubtitleDelay = {
                    playbackManager.setSubtitleDelay(0L)
                    scope.launch { snackbarHostState.showSnackbar("Subtitle delay reset to 0") }
                },
                onOpenAudioDelay = { showAudioDelayDialog = true },
                onResetAudioDelay = {
                    playbackManager.setAudioDelay(0L)
                    scope.launch { snackbarHostState.showSnackbar("Audio delay reset to 0") }
                }
            )
        }

        // BOTTOM OVERLAY (stacked from bottom to top, 150ms animated visibility)
        AnimatedVisibility(
            visible = areControlsVisible && !isScreenLocked,
            enter = fadeIn(animationSpec = tween(150)) + slideInVertically(
                animationSpec = tween(150),
                initialOffsetY = { it / 2 }
            ),
            exit = fadeOut(animationSpec = tween(150)) + slideOutVertically(
                animationSpec = tween(150),
                targetOffsetY = { it / 2 }
            ),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            PlayerBottomOverlay(
                currentPosition = currentPosition,
                duration = duration,
                isPlaying = isPlaying,
                pointA = pointA,
                pointB = pointB,
                isLandscape = isLandscape,
                onPlayPause = { playbackManager.togglePlayPause() },
                onPrevious = { playbackManager.playPrevious() },
                onNext = { playbackManager.playNext() },
                onRewind10 = { playbackManager.seekBy(-10000L) },
                onForward10 = { playbackManager.seekBy(10000L) },
                onSeek = { targetMs -> playbackManager.seekTo(targetMs) },
                onScrubbingChanged = { isScrubbing -> isUserScrubbingSeekBar = isScrubbing },
                onOpenTracks = { showTracksDialog = true },
                onToggleOrientation = {
                    activity?.let { act ->
                        val newOrientation = if (isLandscape) {
                            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        } else {
                            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        }
                        act.requestedOrientation = newOrientation
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                if (newOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                                    "Locked Portrait"
                                else
                                    "Locked Landscape"
                            )
                        }
                    }
                },
                onCycleAspectRatio = {
                    val next = when (aspectRatioMode) {
                        AspectRatioMode.FIT -> AspectRatioMode.FILL
                        AspectRatioMode.FILL -> AspectRatioMode.CROP
                        AspectRatioMode.CROP -> AspectRatioMode.RATIO_16_9
                        AspectRatioMode.RATIO_16_9 -> AspectRatioMode.RATIO_4_3
                        AspectRatioMode.RATIO_4_3 -> AspectRatioMode.FIT
                    }
                    playbackManager.setAspectRatioMode(next)
                    val label = when (next) {
                        AspectRatioMode.FIT -> "Fit Screen"
                        AspectRatioMode.FILL -> "Fill / Stretch"
                        AspectRatioMode.CROP -> "Crop to Fill"
                        AspectRatioMode.RATIO_16_9 -> "16:9 Widescreen"
                        AspectRatioMode.RATIO_4_3 -> "4:3 Standard"
                    }
                    scope.launch { snackbarHostState.showSnackbar(label) }
                },
                onLongPressAspectRatio = {
                    showAspectRatioMenuDialog = true
                },
                onOpenMore = { showMoreSheet = true },
                onClearAbRepeat = {
                    playbackManager.clearAbRepeat()
                    scope.launch { snackbarHostState.showSnackbar("A-B repeat cleared") }
                }
            )
        }

        // LOCK SCREEN: Swipe to unlock
        if (isScreenLocked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 36.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                SwipeToUnlock(
                    onUnlock = {
                        isScreenLocked = false
                        areControlsVisible = true
                        scope.launch { snackbarHostState.showSnackbar("Player unlocked") }
                    }
                )
            }
        }

        // Toast / Status snackbar host
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 70.dp)
        )
    }

    // DIALOGS & BOTTOM SHEETS:
    // Advanced Options Bottom Sheet (More icon)
    if (showMoreSheet) {
        val currentSleepSec = sleepTimerSec
        AdvancedOptionsBottomSheet(
            repeatMode = repeatMode,
            shuffleMode = shuffleMode,
            playbackSpeed = playbackSpeed,
            isSleepTimerActive = (currentSleepSec != null && currentSleepSec > 0),
            onLockPlayer = { isScreenLocked = true },
            onOpenSleepTimer = { showSleepTimerDialog = true },
            onOpenSpeed = { showSpeedDialog = true },
            onOpenJumpToTime = { showJumpToTimeDialog = true },
            onOpenEqualizer = { showEqualizerSheet = true },
            onPlayAsAudio = {
                scope.launch { snackbarHostState.showSnackbar("Continuing in background audio mode") }
                onBack()
            },
            onPictureInPicture = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
                    val params = PictureInPictureParams.Builder().build()
                    activity.enterPictureInPictureMode(params)
                } else {
                    scope.launch { snackbarHostState.showSnackbar("Picture-in-Picture not supported") }
                }
            },
            onToggleRepeat = { playbackManager.toggleRepeatMode() },
            onToggleShuffle = { playbackManager.toggleShuffle() },
            onOpenAbRepeat = { showAbRepeatDialog = true },
            onOpenVideoInfo = { showVideoInfoDialog = true },
            onDismiss = { showMoreSheet = false }
        )
    }

    // Playback Speed Dialog
    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Playback Speed") },
            text = {
                Column {
                    speeds.forEach { speed ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playbackManager.setPlaybackSpeed(speed)
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = playbackSpeed == speed,
                                onClick = {
                                    playbackManager.setPlaybackSpeed(speed)
                                    showSpeedDialog = false
                                },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = EveRedPrimary
                                )
                            )
                            Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                            Text(
                                text = "${speed}x",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // Jump To Time Dialog
    if (showJumpToTimeDialog) {
        JumpToTimeDialog(
            currentPosition = currentPosition,
            duration = duration,
            onJump = { targetMs -> playbackManager.seekTo(targetMs) },
            onDismiss = { showJumpToTimeDialog = false }
        )
    }

    // Video Information Dialog
    if (showVideoInfoDialog) {
        val exo = playbackManager.getExoPlayer()
        val vw = exo.videoSize.width
        val vh = exo.videoSize.height

        VideoInfoDialog(
            mediaItem = currentMedia,
            duration = duration,
            videoWidth = vw,
            videoHeight = vh,
            audioTracksCount = audioTracks.size,
            subtitlesCount = subtitleTracks.size,
            onDismiss = { showVideoInfoDialog = false }
        )
    }

    // Aspect Ratio Selection Menu (long-press)
    if (showAspectRatioMenuDialog) {
        AspectRatioMenuDialog(
            currentMode = aspectRatioMode,
            onSelectMode = { mode -> playbackManager.setAspectRatioMode(mode) },
            onDismiss = { showAspectRatioMenuDialog = false }
        )
    }

    // Unified Tracks & Subtitles Dialog
    if (showTracksDialog) {
        TracksSelectionDialog(
            audioTracks = audioTracks,
            subtitleTracks = subtitleTracks,
            onSelectAudio = { group, track -> playbackManager.selectAudioTrack(group, track) },
            onSelectSubtitle = { group, track -> playbackManager.selectSubtitleTrack(group, track) },
            onDisableSubtitle = { playbackManager.selectSubtitleTrack(-1, -1) },
            onLoadExternalSubtitle = {
                subtitlePickerLauncher.launch(arrayOf("*/*"))
                showTracksDialog = false
            },
            onDismiss = { showTracksDialog = false }
        )
    }

    // Queue Bottom Sheet
    if (showQueueSheet) {
        QueueBottomSheet(
            queue = queue,
            currentIndex = currentQueueIndex,
            onSelectTrack = { index ->
                if (index in queue.indices) {
                    playbackManager.playMedia(queue[index], startPositionMs = 0L, newQueue = queue)
                    showQueueSheet = false
                }
            },
            onRemoveTrack = { index ->
                playbackManager.removeFromQueue(index)
            },
            onDismiss = { showQueueSheet = false }
        )
    }

    // Equalizer Bottom Sheet
    if (showEqualizerSheet) {
        val eqState by playbackManager.equalizerManager.state.collectAsState()
        EqualizerBottomSheet(
            equalizerState = eqState,
            onToggleEnabled = { playbackManager.equalizerManager.setEnabled(it) },
            onBandLevelChange = { b, l -> playbackManager.equalizerManager.setBandLevel(b, l) },
            onSelectPreset = { playbackManager.equalizerManager.setPreset(it) },
            onBassBoostChange = { playbackManager.equalizerManager.setBassBoost(it) },
            onDismiss = { showEqualizerSheet = false }
        )
    }

    // Sleep Timer Dialog
    if (showSleepTimerDialog) {
        SleepTimerDialog(
            currentRemainingSec = sleepTimerSec,
            onSetTimer = { mins -> playbackManager.startSleepTimer(mins) },
            onCancelTimer = { playbackManager.cancelSleepTimer() },
            onDismiss = { showSleepTimerDialog = false }
        )
    }

    // Audio Delay Dialog
    if (showAudioDelayDialog) {
        AudioDelayDialog(
            currentDelayMs = audioDelayMs,
            onDelayChange = { playbackManager.setAudioDelay(it) },
            onDismiss = { showAudioDelayDialog = false }
        )
    }

    // Subtitle Settings Dialog
    if (showSubtitleSettingsDialog) {
        SubtitleSettingsDialog(
            currentDelayMs = subtitleDelayMs,
            onDelayChange = { playbackManager.setSubtitleDelay(it) },
            onLoadExternalSubtitle = {
                subtitlePickerLauncher.launch(arrayOf("*/*"))
                showSubtitleSettingsDialog = false
            },
            onDismiss = { showSubtitleSettingsDialog = false }
        )
    }

    // A-B Repeat Loop Dialog
    if (showAbRepeatDialog) {
        AbRepeatDialog(
            pointA = pointA,
            pointB = pointB,
            currentPosition = currentPosition,
            onSetPointA = { playbackManager.setAbRepeatPointA(it) },
            onSetPointB = { playbackManager.setAbRepeatPointB(it) },
            onClear = { playbackManager.clearAbRepeat() },
            onDismiss = { showAbRepeatDialog = false }
        )
    }
}
