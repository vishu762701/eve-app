@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui.screens.video

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.PlaybackHistory
import com.example.data.model.MediaModel
import com.example.data.settings.GroupingMode
import com.example.data.settings.ViewMode
import com.example.ui.icons.EveIconButton
import com.example.ui.icons.EveIcons
import com.example.ui.theme.EveAccent
import com.example.ui.theme.LocalEveIconTint

data class VideoGroup(
    val groupKey: String,
    val title: String,
    val items: List<MediaModel>
)

@Composable
fun VideoTabScreen(
    videos: List<MediaModel>,
    historyList: List<PlaybackHistory>,
    seenMediaIds: Set<String>,
    groupingMode: GroupingMode,
    viewMode: ViewMode,
    selectedIds: Set<String>,
    onSelectMedia: (MediaModel) -> Unit,
    onToggleSelection: (MediaModel) -> Unit,
    onPlayMedia: (MediaModel, Long) -> Unit,
    onPlayGroup: (List<MediaModel>) -> Unit,
    onAppendToQueue: (MediaModel) -> Unit,
    onPlayNext: (MediaModel) -> Unit,
    onAddToPlaylist: (MediaModel) -> Unit,
    onMarkSeenToggle: (MediaModel, Boolean) -> Unit,
    onDeleteMedia: (MediaModel) -> Unit,
    onSetGrouping: (GroupingMode) -> Unit,
    modifier: Modifier = Modifier
) {
    // Sub-folder/group inspection state
    var activeGroup by remember { mutableStateOf<VideoGroup?>(null) }
    var selectedMediaForInfo by remember { mutableStateOf<MediaModel?>(null) }

    val historyMap = remember(historyList) {
        historyList.associateBy { it.mediaId }
    }

    if (activeGroup != null) {
        // Folder or Group drilled-down screen (PRD 4.1)
        Column(modifier = modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                EveIconButton(
                    imageVector = EveIcons.Back,
                    contentDescription = "Back",
                    onClick = { activeGroup = null }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activeGroup!!.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${activeGroup!!.items.size} videos",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                EveIconButton(
                    imageVector = EveIcons.Play,
                    contentDescription = "Play all",
                    onClick = { onPlayGroup(activeGroup!!.items) }
                )
            }

            VideoListOrGrid(
                items = activeGroup!!.items,
                historyMap = historyMap,
                seenMediaIds = seenMediaIds,
                viewMode = viewMode,
                selectedIds = selectedIds,
                onMediaClick = { media ->
                    if (selectedIds.isNotEmpty()) {
                        onToggleSelection(media)
                    } else {
                        val hist = historyMap[media.id]
                        onPlayMedia(media, hist?.positionMs ?: 0L)
                    }
                },
                onMediaLongClick = { media -> onToggleSelection(media) },
                onAppendToQueue = onAppendToQueue,
                onPlayNext = onPlayNext,
                onAddToPlaylist = onAddToPlaylist,
                onMarkSeenToggle = onMarkSeenToggle,
                onDeleteMedia = onDeleteMedia,
                onShowInfo = { selectedMediaForInfo = it }
            )
        }
        return
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Quick Grouping Chips Row (PRD 4.1: Name default, Folder, None)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GroupingMode.entries.forEach { mode ->
                val isSelected = groupingMode == mode
                FilterChip(
                    selected = isSelected,
                    onClick = { onSetGrouping(mode) },
                    label = {
                        Text(
                            text = mode.name.lowercase().replaceFirstChar { it.uppercase() },
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) EveAccent else MaterialTheme.colorScheme.onSurface
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EveAccent.copy(alpha = 0.12f),
                        selectedLabelColor = EveAccent
                    )
                )
            }
        }

        if (videos.isEmpty()) {
            // Empty state (PRD 3.5 / 13)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = EveIcons.Video,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No videos found",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Videos in device storage will appear here",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            when (groupingMode) {
                GroupingMode.NONE -> {
                    VideoListOrGrid(
                        items = videos,
                        historyMap = historyMap,
                        seenMediaIds = seenMediaIds,
                        viewMode = viewMode,
                        selectedIds = selectedIds,
                        onMediaClick = { media ->
                            if (selectedIds.isNotEmpty()) {
                                onToggleSelection(media)
                            } else {
                                val hist = historyMap[media.id]
                                onPlayMedia(media, hist?.positionMs ?: 0L)
                            }
                        },
                        onMediaLongClick = { media -> onToggleSelection(media) },
                        onAppendToQueue = onAppendToQueue,
                        onPlayNext = onPlayNext,
                        onAddToPlaylist = onAddToPlaylist,
                        onMarkSeenToggle = onMarkSeenToggle,
                        onDeleteMedia = onDeleteMedia,
                        onShowInfo = { selectedMediaForInfo = it }
                    )
                }
                GroupingMode.NAME -> {
                    val groups = remember(videos) {
                        videos.groupBy { it.nameGroupKey }.map { (key, list) ->
                            VideoGroup(
                                groupKey = key,
                                title = key,
                                items = list
                            )
                        }
                    }
                    GroupListOrGrid(
                        groups = groups,
                        historyMap = historyMap,
                        viewMode = viewMode,
                        onGroupClick = { group ->
                            if (group.items.size == 1) {
                                val item = group.items.first()
                                val hist = historyMap[item.id]
                                onPlayMedia(item, hist?.positionMs ?: 0L)
                            } else {
                                activeGroup = group
                            }
                        },
                        onPlayGroup = onPlayGroup
                    )
                }
                GroupingMode.FOLDER -> {
                    val folderGroups = remember(videos) {
                        videos.groupBy { it.bucketId }.map { (bucketId, list) ->
                            val folderName = list.firstOrNull()?.bucketName ?: "Folder"
                            VideoGroup(
                                groupKey = bucketId,
                                title = folderName,
                                items = list
                            )
                        }
                    }
                    GroupListOrGrid(
                        groups = folderGroups,
                        historyMap = historyMap,
                        viewMode = viewMode,
                        onGroupClick = { group ->
                            activeGroup = group
                        },
                        onPlayGroup = onPlayGroup
                    )
                }
            }
        }
    }

    // Media Info Dialog (PRD 4.5)
    selectedMediaForInfo?.let { media ->
        AlertDialog(
            onDismissRequest = { selectedMediaForInfo = null },
            title = { Text("Video Information") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Title: ${media.title}", style = MaterialTheme.typography.bodyMedium)
                    Text("Duration: ${media.durationFormatted}", style = MaterialTheme.typography.bodyMedium)
                    Text("Resolution: ${if (media.width > 0) "${media.width}x${media.height}" else "Standard"}", style = MaterialTheme.typography.bodyMedium)
                    Text("Size: ${media.sizeFormatted}", style = MaterialTheme.typography.bodyMedium)
                    Text("Folder: ${media.bucketName}", style = MaterialTheme.typography.bodyMedium)
                    if (media.filePath.isNotBlank()) {
                        Text("Path: ${media.filePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedMediaForInfo = null }) {
                    Text("Close", color = EveAccent)
                }
            }
        )
    }
}

@Composable
private fun VideoListOrGrid(
    items: List<MediaModel>,
    historyMap: Map<String, PlaybackHistory>,
    seenMediaIds: Set<String>,
    viewMode: ViewMode,
    selectedIds: Set<String>,
    onMediaClick: (MediaModel) -> Unit,
    onMediaLongClick: (MediaModel) -> Unit,
    onAppendToQueue: (MediaModel) -> Unit,
    onPlayNext: (MediaModel) -> Unit,
    onAddToPlaylist: (MediaModel) -> Unit,
    onMarkSeenToggle: (MediaModel, Boolean) -> Unit,
    onDeleteMedia: (MediaModel) -> Unit,
    onShowInfo: (MediaModel) -> Unit
) {
    if (viewMode == ViewMode.GRID) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 170.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items, key = { it.id }) { video ->
                val isSelected = selectedIds.contains(video.id)
                val hist = historyMap[video.id]
                val isSeen = seenMediaIds.contains(video.id) || (hist?.completed == true)

                VideoGridCard(
                    media = video,
                    history = hist,
                    isSeen = isSeen,
                    isSelected = isSelected,
                    onClick = { onMediaClick(video) },
                    onLongClick = { onMediaLongClick(video) },
                    onAppendToQueue = { onAppendToQueue(video) },
                    onPlayNext = { onPlayNext(video) },
                    onAddToPlaylist = { onAddToPlaylist(video) },
                    onMarkSeen = { onMarkSeenToggle(video, !isSeen) },
                    onDelete = { onDeleteMedia(video) },
                    onShowInfo = { onShowInfo(video) }
                )
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items, key = { it.id }) { video ->
                val isSelected = selectedIds.contains(video.id)
                val hist = historyMap[video.id]
                val isSeen = seenMediaIds.contains(video.id) || (hist?.completed == true)

                VideoListItem(
                    media = video,
                    history = hist,
                    isSeen = isSeen,
                    isSelected = isSelected,
                    onClick = { onMediaClick(video) },
                    onLongClick = { onMediaLongClick(video) },
                    onAppendToQueue = { onAppendToQueue(video) },
                    onPlayNext = { onPlayNext(video) },
                    onAddToPlaylist = { onAddToPlaylist(video) },
                    onMarkSeen = { onMarkSeenToggle(video, !isSeen) },
                    onDelete = { onDeleteMedia(video) },
                    onShowInfo = { onShowInfo(video) }
                )
            }
        }
    }
}

@Composable
private fun GroupListOrGrid(
    groups: List<VideoGroup>,
    historyMap: Map<String, PlaybackHistory>,
    viewMode: ViewMode,
    onGroupClick: (VideoGroup) -> Unit,
    onPlayGroup: (List<MediaModel>) -> Unit
) {
    if (viewMode == ViewMode.GRID) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 170.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(groups, key = { it.groupKey }) { group ->
                GroupGridCard(
                    group = group,
                    onClick = { onGroupClick(group) },
                    onPlayAll = { onPlayGroup(group.items) }
                )
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(groups, key = { it.groupKey }) { group ->
                GroupListItem(
                    group = group,
                    onClick = { onGroupClick(group) },
                    onPlayAll = { onPlayGroup(group.items) }
                )
            }
        }
    }
}

/**
 * 16:10 Video Grid Card strictly per PRD 4.2:
 * 16:10 thumbnail with rounded corners, duration badge bottom-right (10sp, dark translucent),
 * thin accent progress bar at bottom edge for partially watched videos, "new/unseen" small accent dot,
 * title below (2 lines max), meta line below (resolution · size).
 */
@Composable
fun VideoGridCard(
    media: MediaModel,
    history: PlaybackHistory?,
    isSeen: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onAppendToQueue: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onMarkSeen: () -> Unit,
    onDelete: () -> Unit,
    onShowInfo: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    val watchedFraction = if (history != null && history.durationMs > 0 && history.positionMs > 0) {
        (history.positionMs.toFloat() / history.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .then(
                if (isSelected) Modifier.border(2.dp, EveAccent, RoundedCornerShape(12.dp))
                else Modifier
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("video_card_${media.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column {
            // 16:10 Thumbnail
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 10f)
                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                    .background(Color(0xFF1B1B20)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = EveIcons.Video,
                    contentDescription = null,
                    modifier = Modifier.size(38.dp),
                    tint = Color.White.copy(alpha = 0.35f)
                )

                // Unseen dot top-left (PRD 4.2)
                if (!isSeen && watchedFraction == 0f) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(EveAccent)
                    )
                }

                // Selected Checkmark overlay (PRD 4.6)
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(EveAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = EveIcons.Check,
                            contentDescription = "Selected",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Duration badge bottom-right (10sp, dark translucent)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = media.durationFormatted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Watched progress bar at bottom edge
                if (watchedFraction > 0f) {
                    LinearProgressIndicator(
                        progress = { watchedFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .align(Alignment.BottomCenter),
                        color = EveAccent,
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )
                }
            }

            // Title & Meta below thumbnail
            Column(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = media.title,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )

                    Box {
                        EveIconButton(
                            imageVector = EveIcons.More,
                            contentDescription = "Menu",
                            onClick = { menuExpanded = true },
                            iconSize = 18.dp,
                            modifier = Modifier.size(28.dp)
                        )

                        VideoContextMenu(
                            expanded = menuExpanded,
                            onDismiss = { menuExpanded = false },
                            isSeen = isSeen,
                            onPlay = onClick,
                            onAppendToQueue = onAppendToQueue,
                            onPlayNext = onPlayNext,
                            onAddToPlaylist = onAddToPlaylist,
                            onMarkSeen = onMarkSeen,
                            onShowInfo = onShowInfo,
                            onDelete = onDelete
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                val metaText = listOfNotNull(
                    media.resolutionFormatted.ifBlank { null },
                    media.sizeFormatted.ifBlank { null }
                ).joinToString(" · ")

                Text(
                    text = metaText.ifBlank { media.bucketName },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun VideoListItem(
    media: MediaModel,
    history: PlaybackHistory?,
    isSeen: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onAppendToQueue: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onMarkSeen: () -> Unit,
    onDelete: () -> Unit,
    onShowInfo: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    val watchedFraction = if (history != null && history.durationMs > 0 && history.positionMs > 0) {
        (history.positionMs.toFloat() / history.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .then(
                if (isSelected) Modifier.border(2.dp, EveAccent, RoundedCornerShape(10.dp))
                else Modifier
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .background(MaterialTheme.colorScheme.surface)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Small 16:10 Thumbnail
        Box(
            modifier = Modifier
                .width(96.dp)
                .aspectRatio(16f / 10f)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1B1B20)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = EveIcons.Video,
                contentDescription = null,
                modifier = Modifier.size(24.dp),
                tint = Color.White.copy(alpha = 0.35f)
            )

            // Duration badge
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xCC000000))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = media.durationFormatted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            if (watchedFraction > 0f) {
                LinearProgressIndicator(
                    progress = { watchedFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.5.dp)
                        .align(Alignment.BottomCenter),
                    color = EveAccent,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!isSeen && watchedFraction == 0f) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(EveAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = media.title,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(2.dp))
            val metaText = listOfNotNull(
                media.resolutionFormatted.ifBlank { null },
                media.sizeFormatted.ifBlank { null }
            ).joinToString(" · ")

            Text(
                text = metaText.ifBlank { media.bucketName },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Box {
            EveIconButton(
                imageVector = EveIcons.More,
                contentDescription = "Options",
                onClick = { menuExpanded = true },
                iconSize = 22.dp
            )

            VideoContextMenu(
                expanded = menuExpanded,
                onDismiss = { menuExpanded = false },
                isSeen = isSeen,
                onPlay = onClick,
                onAppendToQueue = onAppendToQueue,
                onPlayNext = onPlayNext,
                onAddToPlaylist = onAddToPlaylist,
                onMarkSeen = onMarkSeen,
                onShowInfo = onShowInfo,
                onDelete = onDelete
            )
        }
    }
}

@Composable
fun GroupGridCard(
    group: VideoGroup,
    onClick: () -> Unit,
    onPlayAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 10f)
                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                    .background(Color(0xFF222228)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = EveIcons.Folder,
                    contentDescription = null,
                    modifier = Modifier.size(44.dp),
                    tint = Color.White.copy(alpha = 0.4f)
                )

                // Badge showing "N videos" (PRD 4.1 / 4.2)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${group.items.size} videos",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
                Text(
                    text = group.title,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${group.items.size} items",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun GroupListItem(
    group: VideoGroup,
    onClick: () -> Unit,
    onPlayAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .background(MaterialTheme.colorScheme.surface)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(84.dp)
                .aspectRatio(16f / 10f)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF222228)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = EveIcons.Folder,
                contentDescription = null,
                modifier = Modifier.size(28.dp),
                tint = Color.White.copy(alpha = 0.45f)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = group.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${group.items.size} videos",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        EveIconButton(
            imageVector = EveIcons.Play,
            contentDescription = "Play all",
            onClick = onPlayAll,
            iconSize = 24.dp
        )
    }
}

@Composable
fun VideoContextMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    isSeen: Boolean,
    onPlay: () -> Unit,
    onAppendToQueue: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onMarkSeen: () -> Unit,
    onShowInfo: () -> Unit,
    onDelete: () -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss
    ) {
        DropdownMenuItem(
            text = { Text("Play") },
            onClick = {
                onDismiss()
                onPlay()
            }
        )
        DropdownMenuItem(
            text = { Text("Play next") },
            onClick = {
                onDismiss()
                onPlayNext()
            }
        )
        DropdownMenuItem(
            text = { Text("Append to queue") },
            onClick = {
                onDismiss()
                onAppendToQueue()
            }
        )
        DropdownMenuItem(
            text = { Text("Add to playlist") },
            onClick = {
                onDismiss()
                onAddToPlaylist()
            }
        )
        DropdownMenuItem(
            text = { Text(if (isSeen) "Mark as unplayed" else "Mark as played") },
            onClick = {
                onDismiss()
                onMarkSeen()
            }
        )
        DropdownMenuItem(
            text = { Text("Information") },
            onClick = {
                onDismiss()
                onShowInfo()
            }
        )
        DropdownMenuItem(
            text = { Text("Delete", color = EveAccent) },
            onClick = {
                onDismiss()
                onDelete()
            }
        )
    }
}
