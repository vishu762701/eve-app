package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// eve Design System Colours (PRD 2.1)
val EveAccent = Color(0xFFFF0000)

// AMOLED Theme (default)
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF0A0A0C)
val AmoledSurfaceVariant = Color(0xFF141418)
val AmoledOnSurface = Color(0xFFF5F5F7)
val AmoledOnSurfaceVariant = Color(0xFFA0A0AB)

// Dark Theme
val DarkBackground = Color(0xFF0F0F12)
val DarkSurface = Color(0xFF17171C)
val DarkSurfaceVariant = Color(0xFF22222B)
val DarkOnSurface = Color(0xFFF5F5F7)
val DarkOnSurfaceVariant = Color(0xFFA0A0AB)

// Light Theme
val LightBackground = Color(0xFFF9F9FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8E8EE)
val LightOnSurface = Color(0xFF151518)
val LightOnSurfaceVariant = Color(0xFF5A5A66)

// Icon tints
val IconTintDark = Color(0xFFFFFFFF)
val IconTintLight = Color(0xFF333333)

// Player scrim & tracks
val PlayerScrim = Color(0xC0141414) // #141414 at 75%
val TrackInactiveDark = Color(0x4DFFFFFF) // White at 30%
val TrackInactiveLight = Color(0x4D888888) // Grey at 30%
val ChipBackground = Color(0xC0141414)
