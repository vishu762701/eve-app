package com.example.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.mediastore.MediaFolder
import com.example.data.mediastore.MediaItemModel
import com.example.ui.components.FolderCard
import com.example.ui.components.MediaInfoDialog
import com.example.ui.components.MediaItemGridCard
import com.example.ui.components.MediaItemListRow
import com.example.ui.theme.EveRedPrimary

enum class VideoGrouping {
    NONE,
    FOLDER
}

@Composable
fun VideoTabContent(
    videos: List<MediaItemModel>,
    videoFolders: List<MediaFolder>,
    isGridView: Boolean,
    onToggleGridView: () -> Unit,
    onOpenSort: () -> Unit,
    onRefresh: () -> Unit,
    isScanning: Boolean,
    onPlayVideo: (MediaItemModel, List<MediaItemModel>) -> Unit,
    onPlayNext: (MediaItemModel) -> Unit,
    onAddToPlaylist: (MediaItemModel) -> Unit,
    onToggleFavorite: (MediaItemModel) -> Unit,
    onShare: (MediaItemModel) -> Unit,
    onDelete: (MediaItemModel) -> Unit,
    getFolderVideos: suspend (String) -> List<MediaItemModel>
) {
    var grouping by remember { mutableStateOf(VideoGrouping.NONE) }
    var selectedFolder by remember { mutableStateOf<MediaFolder?>(null) }
    var folderVideos by remember { mutableStateOf<List<MediaItemModel>>(emptyList()) }
    var selectedItemForInfo by remember { mutableStateOf<MediaItemModel?>(null) }

    if (selectedItemForInfo != null) {
        MediaInfoDialog(
            item = selectedItemForInfo!!,
            onDismiss = { selectedItemForInfo = null }
        )
    }

    if (selectedFolder != null) {
        // Folder detail view
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { selectedFolder = null }) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        selectedFolder!!.folderName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${folderVideos.size} videos",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = onToggleGridView) {
                    Icon(
                        if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                        contentDescription = "Toggle View"
                    )
                }
            }

            if (isGridView) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(170.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(folderVideos, key = { it.uri.toString() }) { item ->
                        MediaItemGridCard(
                            item = item,
                            onClick = { onPlayVideo(item, folderVideos) },
                            onToggleFavorite = { onToggleFavorite(item) },
                            onAddToPlaylist = { onAddToPlaylist(item) },
                            onAddToQueue = { onPlayNext(item) },
                            onDelete = { onDelete(item) }
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(folderVideos, key = { it.uri.toString() }) { item ->
                        MediaItemListRow(
                            item = item,
                            onClick = { onPlayVideo(item, folderVideos) },
                            onToggleFavorite = { onToggleFavorite(item) },
                            onAddToPlaylist = { onAddToPlaylist(item) },
                            onAddToQueue = { onPlayNext(item) },
                            onDelete = { onDelete(item) }
                        )
                    }
                }
            }
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Sub-header controls: Group By Chips + View Toggle + Sort
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = grouping == VideoGrouping.NONE,
                    onClick = { grouping = VideoGrouping.NONE },
                    label = { Text("All Videos (${videos.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EveRedPrimary,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = grouping == VideoGrouping.FOLDER,
                    onClick = { grouping = VideoGrouping.FOLDER },
                    label = { Text("Folders (${videoFolders.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EveRedPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (grouping == VideoGrouping.NONE) {
                    IconButton(onClick = onToggleGridView) {
                        Icon(
                            if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                            contentDescription = "Toggle Grid/List",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onOpenSort) {
                        Icon(
                            Icons.Default.Sort,
                            contentDescription = "Sort",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (grouping == VideoGrouping.FOLDER) {
            if (videoFolders.isEmpty()) {
                EmptyVideoView(onRefresh = onRefresh, isScanning = isScanning)
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(videoFolders, key = { it.bucketId ?: it.folderName }) { folder ->
                        FolderCard(
                            folder = folder,
                            onClick = {
                                kotlinx.coroutines.MainScope().run {
                                    // Trigger folder load
                                }
                                selectedFolder = folder
                                folderVideos = videos.filter { it.bucketId == folder.bucketId || it.folderName == folder.folderName }
                            }
                        )
                    }
                }
            }
        } else {
            // Grouping: NONE
            if (videos.isEmpty()) {
                EmptyVideoView(onRefresh = onRefresh, isScanning = isScanning)
            } else if (isGridView) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(170.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(videos, key = { it.uri.toString() }) { item ->
                        MediaItemGridCard(
                            item = item,
                            onClick = { onPlayVideo(item, videos) },
                            onToggleFavorite = { onToggleFavorite(item) },
                            onAddToPlaylist = { onAddToPlaylist(item) },
                            onAddToQueue = { onPlayNext(item) },
                            onDelete = { onDelete(item) }
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(videos, key = { it.uri.toString() }) { item ->
                        MediaItemListRow(
                            item = item,
                            onClick = { onPlayVideo(item, videos) },
                            onToggleFavorite = { onToggleFavorite(item) },
                            onAddToPlaylist = { onAddToPlaylist(item) },
                            onAddToQueue = { onPlayNext(item) },
                            onDelete = { onDelete(item) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyVideoView(
    onRefresh: () -> Unit,
    isScanning: Boolean
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                shape = CircleShape,
                color = EveRedPrimary.copy(alpha = 0.12f),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.Movie,
                        contentDescription = null,
                        tint = EveRedPrimary,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "No videos found",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                "Place video files on your device storage to watch them offline in eve.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onRefresh,
                enabled = !isScanning,
                colors = ButtonDefaults.buttonColors(containerColor = EveRedPrimary)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isScanning) "Scanning Storage..." else "Scan Storage")
            }
        }
    }
}
