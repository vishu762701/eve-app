package com.example.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.KeyboardDoubleArrowLeft
import androidx.compose.material.icons.filled.KeyboardDoubleArrowRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.mediastore.MediaItemModel
import com.example.ui.theme.EveRedPrimary
import kotlin.math.roundToInt

/**
 * Rewind 10s icon with small bold 8sp "10" number over the icon.
 */
@Composable
fun Rewind10Icon(
    modifier: Modifier = Modifier,
    tint: Color = Color.White
) {
    Box(
        modifier = modifier.size(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.RotateLeft,
            contentDescription = "Rewind 10s",
            tint = tint,
            modifier = Modifier.size(28.dp)
        )
        Text(
            text = "10",
            color = tint,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

/**
 * Forward 10s icon with small bold 8sp "10" number over the icon.
 */
@Composable
fun Forward10Icon(
    modifier: Modifier = Modifier,
    tint: Color = Color.White
) {
    Box(
        modifier = modifier.size(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.RotateRight,
            contentDescription = "Forward 10s",
            tint = tint,
            modifier = Modifier.size(28.dp)
        )
        Text(
            text = "10",
            color = tint,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

/**
 * Eve Seek Bar:
 * - Full width
 * - Thin track (4dp visible track, translucent light-grey background, ACCENT-colored progress)
 * - Round thumb that becomes bigger while pressed (12dp -> 20dp)
 * - A-B repeat markers at position A and B above the track
 */
@Composable
fun EveSeekBar(
    currentPosition: Long,
    duration: Long,
    pointA: Long?,
    pointB: Long?,
    onScrubbingChanged: (Boolean) -> Unit,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(0f) }

    val normalProgress = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
    val displayFraction = if (isScrubbing) scrubFraction else normalProgress

    val thumbRadius by animateDpAsState(
        targetValue = if (isScrubbing) 10.dp else 6.dp,
        animationSpec = tween(120),
        label = "thumbRadius"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(36.dp)
            .pointerInput(duration) {
                detectTapGestures(
                    onPress = { offset ->
                        if (duration <= 0) return@detectTapGestures
                        isScrubbing = true
                        onScrubbingChanged(true)
                        val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                        scrubFraction = fraction
                        tryAwaitRelease()
                        isScrubbing = false
                        onScrubbingChanged(false)
                        onSeek((scrubFraction * duration).toLong())
                    }
                )
            }
            .pointerInput(duration) {
                detectDragGestures(
                    onDragStart = { offset ->
                        if (duration <= 0) return@detectDragGestures
                        isScrubbing = true
                        onScrubbingChanged(true)
                        scrubFraction = (offset.x / size.width).coerceIn(0f, 1f)
                    },
                    onDrag = { change, _ ->
                        if (duration <= 0) return@detectDragGestures
                        change.consume()
                        scrubFraction = (change.position.x / size.width).coerceIn(0f, 1f)
                    },
                    onDragEnd = {
                        if (duration > 0) {
                            onSeek((scrubFraction * duration).toLong())
                        }
                        isScrubbing = false
                        onScrubbingChanged(false)
                    },
                    onDragCancel = {
                        isScrubbing = false
                        onScrubbingChanged(false)
                    }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val trackHeight = 4.dp.toPx()
            val centerY = size.height / 2f
            val width = size.width
            val thumbRadiusPx = thumbRadius.toPx()

            // Inactive track (translucent light-grey)
            drawRoundRect(
                color = Color.White.copy(alpha = 0.35f),
                topLeft = Offset(0f, centerY - trackHeight / 2f),
                size = Size(width, trackHeight),
                cornerRadius = CornerRadius(trackHeight / 2f, trackHeight / 2f)
            )

            // Active track (Accent color)
            val progressWidth = width * displayFraction
            if (progressWidth > 0f) {
                drawRoundRect(
                    color = EveRedPrimary,
                    topLeft = Offset(0f, centerY - trackHeight / 2f),
                    size = Size(progressWidth, trackHeight),
                    cornerRadius = CornerRadius(trackHeight / 2f, trackHeight / 2f)
                )
            }

            // A-B Repeat Markers
            if (duration > 0) {
                pointA?.let { pa ->
                    val fracA = (pa.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                    val xA = width * fracA
                    drawLine(
                        color = Color.White,
                        start = Offset(xA, centerY - 8.dp.toPx()),
                        end = Offset(xA, centerY + 8.dp.toPx()),
                        strokeWidth = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }

                pointB?.let { pb ->
                    val fracB = (pb.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                    val xB = width * fracB
                    drawLine(
                        color = EveRedPrimary,
                        start = Offset(xB, centerY - 8.dp.toPx()),
                        end = Offset(xB, centerY + 8.dp.toPx()),
                        strokeWidth = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // Thumb
            val thumbCenterX = progressWidth.coerceIn(thumbRadiusPx, width - thumbRadiusPx)
            drawCircle(
                color = EveRedPrimary,
                radius = thumbRadiusPx,
                center = Offset(thumbCenterX, centerY)
            )
            // Subtle white inner core for thumb
            drawCircle(
                color = Color.White,
                radius = (thumbRadiusPx * 0.45f).coerceAtLeast(1.5f),
                center = Offset(thumbCenterX, centerY)
            )
        }
    }
}

/**
 * Swipe to unlock control at the bottom of the screen when locked.
 */
@Composable
fun SwipeToUnlock(
    onUnlock: () -> Unit,
    modifier: Modifier = Modifier
) {
    val trackWidthDp = 260.dp
    val trackHeightDp = 56.dp
    val handleSizeDp = 48.dp

    var dragOffsetPx by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .width(trackWidthDp)
            .height(trackHeightDp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xFF141414).copy(alpha = 0.85f))
            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(28.dp)),
        contentAlignment = Alignment.CenterStart
    ) {
        // Track text
        Text(
            text = "Swipe to unlock »»",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.Center)
        )

        // Handle
        Box(
            modifier = Modifier
                .offset { IntOffset(dragOffsetPx.roundToInt(), 0) }
                .padding(start = 4.dp)
                .size(handleSizeDp)
                .clip(CircleShape)
                .background(EveRedPrimary)
                .pointerInput(Unit) {
                    val maxDragPx = (trackWidthDp - handleSizeDp - 8.dp).toPx()
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragOffsetPx = (dragOffsetPx + dragAmount.x).coerceIn(0f, maxDragPx)
                        },
                        onDragEnd = {
                            if (dragOffsetPx >= maxDragPx * 0.8f) {
                                onUnlock()
                            }
                            dragOffsetPx = 0f
                        },
                        onDragCancel = {
                            dragOffsetPx = 0f
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Unlock Handle",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

/**
 * Slim vertical Brightness HUD slider on the left side of the screen.
 */
@Composable
fun BrightnessHudSlider(
    brightness: Float,
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(150)),
        exit = fadeOut(tween(300)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .width(36.dp)
                .height(170.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF141414).copy(alpha = 0.85f))
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(18.dp))
                .padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = Icons.Default.BrightnessMedium,
                contentDescription = "Brightness",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )

            // Vertical Track
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .weight(1f)
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White.copy(alpha = 0.25f)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(brightness.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(3.dp))
                        .background(EveRedPrimary)
                )
            }

            Text(
                text = "${(brightness * 100).roundToInt()}%",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Slim vertical Volume HUD slider on the right side of the screen.
 */
@Composable
fun VolumeHudSlider(
    volumeRatio: Float,
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(150)),
        exit = fadeOut(tween(300)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .width(36.dp)
                .height(170.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF141414).copy(alpha = 0.85f))
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(18.dp))
                .padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = if (volumeRatio <= 0f) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                contentDescription = "Volume",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )

            // Vertical Track
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .weight(1f)
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White.copy(alpha = 0.25f)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(volumeRatio.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(3.dp))
                        .background(EveRedPrimary)
                )
            }

            Text(
                text = "${(volumeRatio * 100).roundToInt()}%",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Seek HUD overlay in center showing target time and delta ("+00:23").
 */
@Composable
fun SeekHudOverlay(
    targetPosition: Long,
    deltaMs: Long,
    duration: Long,
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(150)),
        exit = fadeOut(tween(300)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF141414).copy(alpha = 0.85f))
                .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val deltaSign = if (deltaMs >= 0) "+" else "-"
            val deltaSec = (Math.abs(deltaMs) / 1000)
            val deltaFormatted = String.format("%s%02d:%02d", deltaSign, deltaSec / 60, deltaSec % 60)

            Text(
                text = MediaItemModel.formatDuration(targetPosition),
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "[$deltaFormatted]",
                    color = EveRedPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                if (duration > 0) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "/ ${MediaItemModel.formatDuration(duration)}",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * Fast-play 2.0x badge shown at top center while holding.
 */
@Composable
fun FastPlayBadge(
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(100)),
        exit = fadeOut(tween(150)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF141414).copy(alpha = 0.9f))
                .border(1.5.dp, EveRedPrimary, RoundedCornerShape(20.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.FastForward,
                contentDescription = null,
                tint = EveRedPrimary,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "2X",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
        }
    }
}

/**
 * Animated double-tap seek badge on left/right side.
 */
@Composable
fun DoubleTapSeekBadge(
    isForward: Boolean,
    seconds: Int,
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(100)),
        exit = fadeOut(tween(250)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF141414).copy(alpha = 0.85f))
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isForward) Icons.Default.KeyboardDoubleArrowRight else Icons.Default.KeyboardDoubleArrowLeft,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${seconds}s",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
