package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.db.FavoriteEntity
import com.example.data.db.MediaSeenEntity
import com.example.data.db.PlaybackHistory
import com.example.data.db.PlaylistEntity
import com.example.data.model.MediaModel
import com.example.data.settings.EveSettings
import com.example.data.settings.ResumeMode
import com.example.data.settings.SortMode
import com.example.ui.components.EveBottomNav
import com.example.ui.components.EveFloatingPlayButton
import com.example.ui.components.EveMiniPlayer
import com.example.ui.components.EveTab
import com.example.ui.components.EveTopBar
import com.example.ui.screens.audio.AudioTabScreen
import com.example.ui.screens.browse.BrowseTabScreen
import com.example.ui.screens.more.MoreTabScreen
import com.example.ui.screens.player.AudioPlayerScreen
import com.example.ui.screens.player.VideoPlayerScreen
import com.example.ui.screens.playlists.PlaylistsTabScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.video.VideoTabScreen
import com.example.ui.theme.EveAccent
import com.example.ui.theme.EveTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = application as EveApplication
            EveApp(app)
        }
    }
}

@Composable
fun EveApp(app: EveApplication) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val settings by app.settingsRepository.settingsFlow.collectAsState(initial = EveSettings())
    val currentMedia by app.playbackManager.currentMedia.collectAsState()
    val isPlaying by app.playbackManager.isPlaying.collectAsState()
    val currentPosition by app.playbackManager.currentPosition.collectAsState()
    val duration by app.playbackManager.duration.collectAsState()

    // DB flows
    val historyList by app.database.historyDao().getAllHistory().collectAsState(initial = emptyList())
    val playlists by app.database.playlistDao().getAllPlaylists().collectAsState(initial = emptyList())
    val favorites by app.database.favoriteDao().getAllFavorites().collectAsState(initial = emptyList())
    val seenItems by app.database.seenDao().getAllSeen().collectAsState(initial = emptyList())
    val seenIds = remember(seenItems) { seenItems.map { it.mediaId }.toSet() }

    // Media store scanned items
    var rawVideos by remember { mutableStateOf<List<MediaModel>>(emptyList()) }
    var rawAudios by remember { mutableStateOf<List<MediaModel>>(emptyList()) }
    var isScanning by remember { mutableStateOf(false) }

    // Navigation & active screens
    var currentTab by remember { mutableStateOf(EveTab.VIDEO) }
    var isVideoPlayerOpen by remember { mutableStateOf(false) }
    var isAudioPlayerOpen by remember { mutableStateOf(false) }
    var isSettingsOpen by remember { mutableStateOf(false) }

    // Search state
    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    // Multi-select state
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    // Resume Dialog state
    var resumeTargetMedia by remember { mutableStateOf<MediaModel?>(null) }
    var resumeTargetPosition by remember { mutableStateOf(0L) }

    // Permission launcher
    val permissions = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        scope.launch {
            isScanning = true
            rawVideos = app.mediaScanner.scanVideos()
            rawAudios = app.mediaScanner.scanAudio()
            isScanning = false
        }
    }

    LaunchedEffect(Unit) {
        val hasPermission = permissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (hasPermission) {
            isScanning = true
            rawVideos = app.mediaScanner.scanVideos()
            rawAudios = app.mediaScanner.scanAudio()
            isScanning = false
        } else {
            permissionLauncher.launch(permissions)
            // Also populate default items so app is never blank
            rawVideos = app.mediaScanner.scanVideos()
            rawAudios = app.mediaScanner.scanAudio()
        }
    }

    // Refresh function
    val refreshLibrary: () -> Unit = {
        scope.launch {
            isScanning = true
            rawVideos = app.mediaScanner.scanVideos()
            rawAudios = app.mediaScanner.scanAudio()
            isScanning = false
        }
    }

    // Sort & Search filtered lists
    val filteredVideos = remember(rawVideos, searchQuery, settings.sortMode, settings.sortAscending) {
        var list = if (searchQuery.isNotBlank()) {
            rawVideos.filter { it.title.contains(searchQuery, ignoreCase = true) }
        } else rawVideos

        list = when (settings.sortMode) {
            SortMode.NAME -> list.sortedBy { it.title.lowercase() }
            SortMode.FILE_NAME -> list.sortedBy { it.title.lowercase() }
            SortMode.LENGTH -> list.sortedBy { it.durationMs }
            SortMode.DATE_MODIFIED -> list.sortedBy { it.dateModified }
            SortMode.INSERTION_DATE -> list.sortedBy { it.dateAdded }
        }
        if (!settings.sortAscending) list.reversed() else list
    }

    val filteredAudios = remember(rawAudios, searchQuery) {
        if (searchQuery.isNotBlank()) {
            rawAudios.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.artist.contains(searchQuery, ignoreCase = true) ||
                it.album.contains(searchQuery, ignoreCase = true)
            }
        } else rawAudios
    }

    EveTheme(themeMode = settings.theme) {
        // Video Player Fullscreen Modal
        if (isVideoPlayerOpen) {
            VideoPlayerScreen(
                playbackManager = app.playbackManager,
                settings = settings,
                onBack = { isVideoPlayerOpen = false }
            )
            return@EveTheme
        }

        // Settings Screen
        if (isSettingsOpen) {
            SettingsScreen(
                settings = settings,
                onBack = { isSettingsOpen = false },
                onSetTheme = { scope.launch { app.settingsRepository.setTheme(it) } },
                onSetGrouping = { scope.launch { app.settingsRepository.setGroupingMode(it) } },
                onSetResumeMode = { scope.launch { app.settingsRepository.setResumeMode(it) } },
                onSetHudTimeout = { scope.launch { app.settingsRepository.setHudTimeoutSeconds(it) } },
                onSetJumpAmount = { scope.launch { app.settingsRepository.setJumpAmountSeconds(it) } },
                onSetDoubleTapJump = { scope.launch { app.settingsRepository.setDoubleTapJumpSeconds(it) } },
                onSetFastPlaySpeed = { scope.launch { app.settingsRepository.setFastPlaySpeed(it) } },
                onSetGesture = { name, enabled -> scope.launch { app.settingsRepository.setGesture(name, enabled) } },
                onSetShowThumbnails = { scope.launch { app.settingsRepository.setShowThumbnails(it) } },
                onSetMediaSeenMarking = { scope.launch { app.settingsRepository.setMediaSeenMarking(it) } },
                onSetIncognito = { scope.launch { app.settingsRepository.setIncognitoMode(it) } },
                onSetAudioDucking = { scope.launch { app.settingsRepository.setAudioDucking(it) } },
                onClearHistory = { scope.launch(Dispatchers.IO) { app.database.historyDao().clearAllHistory() } }
            )
            return@EveTheme
        }

        // Main Scaffold
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                Column {
                    EveTopBar(
                        isScanning = isScanning,
                        selectedCount = selectedIds.size,
                        viewMode = settings.viewMode,
                        groupingMode = settings.groupingMode,
                        sortMode = settings.sortMode,
                        sortAscending = settings.sortAscending,
                        onSearchClick = { isSearchActive = !isSearchActive },
                        onToggleViewMode = {
                            scope.launch {
                                val next = if (settings.viewMode == com.example.data.settings.ViewMode.GRID)
                                    com.example.data.settings.ViewMode.LIST else com.example.data.settings.ViewMode.GRID
                                app.settingsRepository.setViewMode(next)
                            }
                        },
                        onSetGrouping = { scope.launch { app.settingsRepository.setGroupingMode(it) } },
                        onSetSort = { scope.launch { app.settingsRepository.setSortMode(it, settings.sortAscending) } },
                        onToggleSortAscending = { scope.launch { app.settingsRepository.toggleSortAscending() } },
                        onRefresh = refreshLibrary,
                        onClearSelection = { selectedIds = emptySet() },
                        onPlaySelected = {
                            val selectedItems = rawVideos.filter { selectedIds.contains(it.id) }
                            if (selectedItems.isNotEmpty()) {
                                app.playbackManager.playPlaylist(selectedItems, 0)
                                isVideoPlayerOpen = true
                                selectedIds = emptySet()
                            }
                        },
                        onAppendSelected = {
                            rawVideos.filter { selectedIds.contains(it.id) }.forEach {
                                app.playbackManager.appendToQueue(it)
                            }
                            selectedIds = emptySet()
                        },
                        onDeleteSelected = {
                            selectedIds = emptySet()
                        }
                    )

                    // Search field animation
                    AnimatedVisibility(visible = isSearchActive) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Search title, artist or folder...") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = EveAccent,
                                    cursorColor = EveAccent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            },
            bottomBar = {
                Column {
                    // Mini player shown above bottom bar when media is active (PRD 3.4)
                    EveMiniPlayer(
                        media = currentMedia,
                        isPlaying = isPlaying,
                        positionMs = currentPosition,
                        durationMs = duration,
                        onPlayPauseClick = { app.playbackManager.togglePlayPause() },
                        onPreviousClick = { app.playbackManager.previous() },
                        onNextClick = { app.playbackManager.next() },
                        onOpenFullPlayer = {
                            if (currentMedia?.isVideo == true) {
                                isVideoPlayerOpen = true
                            } else {
                                isAudioPlayerOpen = true
                            }
                        },
                        onDismissPlayer = {
                            app.playbackManager.pause()
                        }
                    )

                    EveBottomNav(
                        currentTab = currentTab,
                        onTabSelected = { currentTab = it }
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentTab) {
                    EveTab.VIDEO -> {
                        VideoTabScreen(
                            videos = filteredVideos,
                            historyList = historyList,
                            seenMediaIds = seenIds,
                            groupingMode = settings.groupingMode,
                            viewMode = settings.viewMode,
                            selectedIds = selectedIds,
                            onSelectMedia = { selectedIds = selectedIds + it.id },
                            onToggleSelection = { media ->
                                selectedIds = if (selectedIds.contains(media.id)) {
                                    selectedIds - media.id
                                } else {
                                    selectedIds + media.id
                                }
                            },
                            onPlayMedia = { media, savedPos ->
                                if (settings.resumeMode == ResumeMode.ASK && savedPos > 5000L) {
                                    resumeTargetMedia = media
                                    resumeTargetPosition = savedPos
                                } else if (settings.resumeMode == ResumeMode.ALWAYS && savedPos > 5000L) {
                                    app.playbackManager.playMedia(media, savedPos)
                                    isVideoPlayerOpen = true
                                } else {
                                    app.playbackManager.playMedia(media, 0L)
                                    isVideoPlayerOpen = true
                                }
                            },
                            onPlayGroup = { list ->
                                app.playbackManager.playPlaylist(list, 0)
                                isVideoPlayerOpen = true
                            },
                            onAppendToQueue = { app.playbackManager.appendToQueue(it) },
                            onPlayNext = { app.playbackManager.playNext(it) },
                            onAddToPlaylist = { media ->
                                scope.launch(Dispatchers.IO) {
                                    val playlistId = app.database.playlistDao().insertPlaylist(
                                        PlaylistEntity(name = "Quick Playlist", kind = "video")
                                    )
                                    app.database.playlistDao().insertPlaylistItem(
                                        com.example.data.db.PlaylistItemEntity(
                                            playlistId = playlistId,
                                            mediaId = media.id,
                                            uri = media.uri,
                                            title = media.title,
                                            durationMs = media.durationMs,
                                            isVideo = true
                                        )
                                    )
                                }
                            },
                            onMarkSeenToggle = { media, markSeen ->
                                scope.launch(Dispatchers.IO) {
                                    if (markSeen) {
                                        app.database.seenDao().markSeen(MediaSeenEntity(media.id))
                                    } else {
                                        app.database.seenDao().markUnseen(media.id)
                                    }
                                }
                            },
                            onDeleteMedia = { media ->
                                rawVideos = rawVideos.filter { it.id != media.id }
                            },
                            onSetGrouping = { mode ->
                                scope.launch { app.settingsRepository.setGroupingMode(mode) }
                            }
                        )

                        // Floating Play button on Video Tab (PRD 3.3)
                        EveFloatingPlayButton(
                            onClick = {
                                if (filteredVideos.isNotEmpty()) {
                                    app.playbackManager.playPlaylist(filteredVideos, 0)
                                    isVideoPlayerOpen = true
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(16.dp)
                        )
                    }
                    EveTab.AUDIO -> {
                        AudioTabScreen(
                            audios = filteredAudios,
                            currentPlayingId = currentMedia?.id,
                            isPlaying = isPlaying,
                            onTrackClick = { track ->
                                app.playbackManager.playMedia(track, 0L)
                                isAudioPlayerOpen = true
                            },
                            onPlayAll = { list ->
                                app.playbackManager.playPlaylist(list, 0)
                                isAudioPlayerOpen = true
                            },
                            onShuffleAll = { list ->
                                val shuffled = list.shuffled()
                                app.playbackManager.playPlaylist(shuffled, 0)
                                isAudioPlayerOpen = true
                            },
                            onAppendToQueue = { app.playbackManager.appendToQueue(it) },
                            onPlayNext = { app.playbackManager.playNext(it) },
                            onAddToPlaylist = { track ->
                                scope.launch(Dispatchers.IO) {
                                    val playlistId = app.database.playlistDao().insertPlaylist(
                                        PlaylistEntity(name = "Audio Favorites", kind = "audio")
                                    )
                                    app.database.playlistDao().insertPlaylistItem(
                                        com.example.data.db.PlaylistItemEntity(
                                            playlistId = playlistId,
                                            mediaId = track.id,
                                            uri = track.uri,
                                            title = track.title,
                                            artist = track.artist,
                                            durationMs = track.durationMs,
                                            isVideo = false
                                        )
                                    )
                                }
                            },
                            onDeleteTrack = { track ->
                                rawAudios = rawAudios.filter { it.id != track.id }
                            }
                        )

                        // Floating Play button on Audio Tab (PRD 3.3)
                        EveFloatingPlayButton(
                            onClick = {
                                if (filteredAudios.isNotEmpty()) {
                                    app.playbackManager.playPlaylist(filteredAudios, 0)
                                    isAudioPlayerOpen = true
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(16.dp)
                        )
                    }
                    EveTab.BROWSE -> {
                        BrowseTabScreen(
                            favorites = favorites,
                            onAddFavorite = { path, name, isFolder ->
                                scope.launch(Dispatchers.IO) {
                                    app.database.favoriteDao().addFavorite(
                                        FavoriteEntity(
                                            mediaId = path,
                                            uri = path,
                                            title = name,
                                            isFolder = isFolder
                                        )
                                    )
                                }
                            },
                            onRemoveFavorite = { path ->
                                scope.launch(Dispatchers.IO) {
                                    app.database.favoriteDao().removeFavorite(path)
                                }
                            },
                            onPlayFile = { path, isVideo ->
                                val file = File(path)
                                val model = MediaModel(
                                    id = "file_${file.hashCode()}",
                                    title = file.nameWithoutExtension,
                                    uri = path,
                                    durationMs = 0L,
                                    isVideo = isVideo
                                )
                                app.playbackManager.playMedia(model, 0L)
                                if (isVideo) {
                                    isVideoPlayerOpen = true
                                } else {
                                    isAudioPlayerOpen = true
                                }
                            },
                            allScannedMedia = rawVideos + rawAudios
                        )
                    }
                    EveTab.PLAYLISTS -> {
                        PlaylistsTabScreen(
                            playlists = playlists,
                            history = historyList,
                            favorites = favorites,
                            recentMedia = rawVideos.take(20),
                            onCreatePlaylist = { name, kind ->
                                scope.launch(Dispatchers.IO) {
                                    app.database.playlistDao().insertPlaylist(
                                        PlaylistEntity(name = name, kind = kind)
                                    )
                                }
                            },
                            onDeletePlaylist = { id ->
                                scope.launch(Dispatchers.IO) {
                                    app.database.playlistDao().deletePlaylist(id)
                                }
                            },
                            onPlayHistoryItem = { hist ->
                                val media = (rawVideos + rawAudios).find { it.id == hist.mediaId }
                                    ?: MediaModel(
                                        id = hist.mediaId,
                                        title = hist.title,
                                        uri = hist.uri,
                                        durationMs = hist.durationMs,
                                        isVideo = hist.isVideo
                                    )
                                app.playbackManager.playMedia(media, hist.positionMs)
                                if (hist.isVideo) isVideoPlayerOpen = true else isAudioPlayerOpen = true
                            },
                            onClearHistory = {
                                scope.launch(Dispatchers.IO) {
                                    app.database.historyDao().clearAllHistory()
                                }
                            },
                            onPlayMedia = { media ->
                                app.playbackManager.playMedia(media, 0L)
                                if (media.isVideo) isVideoPlayerOpen = true else isAudioPlayerOpen = true
                            }
                        )
                    }
                    EveTab.MORE -> {
                        val sleepSeconds by app.playbackManager.sleepTimerRemainingSeconds.collectAsState()
                        MoreTabScreen(
                            onOpenSettings = { isSettingsOpen = true },
                            onOpenHistory = { currentTab = EveTab.PLAYLISTS },
                            onOpenEqualizer = { isSettingsOpen = true },
                            onSetSleepTimer = { app.playbackManager.startSleepTimer(it) },
                            activeSleepTimerSeconds = sleepSeconds,
                            onCancelSleepTimer = { app.playbackManager.cancelSleepTimer() }
                        )
                    }
                }
            }
        }

        // Full Audio Player Modal
        AnimatedVisibility(
            visible = isAudioPlayerOpen,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(150)) + fadeIn(animationSpec = tween(150)),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(150)) + fadeOut(animationSpec = tween(150))
        ) {
            AudioPlayerScreen(
                playbackManager = app.playbackManager,
                onCollapse = { isAudioPlayerOpen = false }
            )
        }

        // Resume Playback Prompt Dialog (PRD 9.4: Ask mode)
        resumeTargetMedia?.let { target ->
            val posSeconds = resumeTargetPosition / 1000
            val formatted = String.format("%02d:%02d", posSeconds / 60, posSeconds % 60)

            AlertDialog(
                onDismissRequest = { resumeTargetMedia = null },
                title = { Text("Resume playback?") },
                text = { Text("Do you want to continue '${target.title}' from $formatted or start from the beginning?") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            app.playbackManager.playMedia(target, resumeTargetPosition)
                            isVideoPlayerOpen = true
                            resumeTargetMedia = null
                        }
                    ) {
                        Text("Resume at $formatted", color = EveAccent, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            app.playbackManager.playMedia(target, 0L)
                            isVideoPlayerOpen = true
                            resumeTargetMedia = null
                        }
                    ) {
                        Text("Start over")
                    }
                }
            )
        }
    }
}
