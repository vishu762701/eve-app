package com.example.playback

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.db.AppDatabase
import com.example.data.db.PlaybackHistory
import com.example.data.model.MediaModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class RepeatState {
    OFF, ALL, ONE
}

enum class AspectMode(val displayName: String) {
    BEST_FIT("Best fit"),
    FIT_SCREEN("Fit screen"),
    FILL("Fill"),
    CROP("Crop"),
    RATIO_16_9("16:9"),
    RATIO_4_3("4:3")
}

data class TrackInfo(
    val id: String,
    val name: String,
    val language: String,
    val isSelected: Boolean,
    val trackGroupIndex: Int,
    val trackIndex: Int
)

@OptIn(UnstableApi::class)
class MediaPlaybackManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val database = AppDatabase.getInstance(context)

    val player: ExoPlayer = ExoPlayer.Builder(context)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            true
        )
        .build()

    // State flows
    private val _currentMedia = MutableStateFlow<MediaModel?>(null)
    val currentMedia: StateFlow<MediaModel?> = _currentMedia.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _bufferedPosition = MutableStateFlow(0L)
    val bufferedPosition: StateFlow<Long> = _bufferedPosition.asStateFlow()

    private val _queue = MutableStateFlow<List<MediaModel>>(emptyList())
    val queue: StateFlow<List<MediaModel>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _normalSpeedBeforeHold = MutableStateFlow(1.0f)

    private val _repeatState = MutableStateFlow(RepeatState.OFF)
    val repeatState: StateFlow<RepeatState> = _repeatState.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _aspectMode = MutableStateFlow(AspectMode.BEST_FIT)
    val aspectMode: StateFlow<AspectMode> = _aspectMode.asStateFlow()

    // A-B Repeat
    private val _markerA = MutableStateFlow<Long?>(null)
    val markerA: StateFlow<Long?> = _markerA.asStateFlow()

    private val _markerB = MutableStateFlow<Long?>(null)
    val markerB: StateFlow<Long?> = _markerB.asStateFlow()

    // Delays
    private val _audioDelayMs = MutableStateFlow(0L)
    val audioDelayMs: StateFlow<Long> = _audioDelayMs.asStateFlow()

    private val _subtitleDelayMs = MutableStateFlow(0L)
    val subtitleDelayMs: StateFlow<Long> = _subtitleDelayMs.asStateFlow()

    // Sleep timer
    private val _sleepTimerRemainingSeconds = MutableStateFlow<Int?>(null)
    val sleepTimerRemainingSeconds: StateFlow<Int?> = _sleepTimerRemainingSeconds.asStateFlow()
    private var sleepTimerJob: Job? = null

    // Tracks
    private val _audioTracks = MutableStateFlow<List<TrackInfo>>(emptyList())
    val audioTracks: StateFlow<List<TrackInfo>> = _audioTracks.asStateFlow()

    private val _subtitleTracks = MutableStateFlow<List<TrackInfo>>(emptyList())
    val subtitleTracks: StateFlow<List<TrackInfo>> = _subtitleTracks.asStateFlow()

    private var positionTrackerJob: Job? = null
    private var lastSaveTime = 0L

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) {
                    startPositionTracker()
                } else {
                    saveCurrentPosition()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _duration.value = player.duration.coerceAtLeast(0L)
                } else if (playbackState == Player.STATE_ENDED) {
                    saveCurrentPosition(completed = true)
                    handlePlaybackEnded()
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                updateTracksList(tracks)
            }
        })
    }

    private fun startPositionTracker() {
        positionTrackerJob?.cancel()
        positionTrackerJob = scope.launch {
            while (isActive) {
                val pos = player.currentPosition.coerceAtLeast(0L)
                val dur = player.duration.coerceAtLeast(0L)
                _currentPosition.value = pos
                _duration.value = dur
                _bufferedPosition.value = player.bufferedPosition.coerceAtLeast(0L)

                // Check A-B Repeat loop
                val b = _markerB.value
                val a = _markerA.value
                if (b != null && a != null && pos >= b) {
                    player.seekTo(a)
                }

                // Save resume position every 5s per PRD 12
                val now = System.currentTimeMillis()
                if (now - lastSaveTime >= 5000L) {
                    lastSaveTime = now
                    saveCurrentPosition()
                }

                delay(200L)
            }
        }
    }

    fun playMedia(media: MediaModel, startPositionMs: Long = 0L) {
        val currentList = _queue.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == media.id }
        if (index >= 0) {
            _currentIndex.value = index
        } else {
            currentList.add(media)
            _queue.value = currentList
            _currentIndex.value = currentList.size - 1
        }
        playItemInternal(media, startPositionMs)
    }

    fun playPlaylist(items: List<MediaModel>, startIndex: Int = 0, startPositionMs: Long = 0L) {
        if (items.isEmpty()) return
        _queue.value = items
        val validIndex = startIndex.coerceIn(0, items.size - 1)
        _currentIndex.value = validIndex
        playItemInternal(items[validIndex], startPositionMs)
    }

    private fun playItemInternal(media: MediaModel, startPositionMs: Long) {
        _currentMedia.value = media
        _currentPosition.value = startPositionMs
        _duration.value = media.durationMs
        clearABRepeat()

        val exoItem = MediaItem.fromUri(Uri.parse(media.uri))
        player.setMediaItem(exoItem)
        player.prepare()
        if (startPositionMs > 0) {
            player.seekTo(startPositionMs)
        }
        player.playWhenReady = true
    }

    fun togglePlayPause() {
        if (player.isPlaying) {
            player.pause()
        } else {
            player.play()
        }
    }

    fun play() {
        player.play()
    }

    fun pause() {
        player.pause()
    }

    fun seekTo(positionMs: Long) {
        val target = positionMs.coerceIn(0L, _duration.value.coerceAtLeast(0L))
        player.seekTo(target)
        _currentPosition.value = target
    }

    fun jumpBy(seconds: Int) {
        val newPos = player.currentPosition + (seconds * 1000L)
        seekTo(newPos)
    }

    fun next() {
        val q = _queue.value
        if (q.isEmpty()) return
        val nextIndex = (_currentIndex.value + 1) % q.size
        _currentIndex.value = nextIndex
        playItemInternal(q[nextIndex], 0L)
    }

    fun previous() {
        val q = _queue.value
        if (q.isEmpty()) return
        // If current position > 3s, restart current item; else go to previous item
        if (player.currentPosition > 3000L) {
            player.seekTo(0L)
        } else {
            val prevIndex = if (_currentIndex.value - 1 < 0) q.size - 1 else _currentIndex.value - 1
            _currentIndex.value = prevIndex
            playItemInternal(q[prevIndex], 0L)
        }
    }

    fun setSpeed(speed: Float) {
        _playbackSpeed.value = speed
        player.playbackParameters = PlaybackParameters(speed)
    }

    fun startFastPlayHold(speed: Float = 2.0f) {
        _normalSpeedBeforeHold.value = _playbackSpeed.value
        player.playbackParameters = PlaybackParameters(speed)
    }

    fun stopFastPlayHold() {
        player.playbackParameters = PlaybackParameters(_normalSpeedBeforeHold.value)
    }

    fun toggleRepeat() {
        _repeatState.value = when (_repeatState.value) {
            RepeatState.OFF -> {
                player.repeatMode = Player.REPEAT_MODE_ALL
                RepeatState.ALL
            }
            RepeatState.ALL -> {
                player.repeatMode = Player.REPEAT_MODE_ONE
                RepeatState.ONE
            }
            RepeatState.ONE -> {
                player.repeatMode = Player.REPEAT_MODE_OFF
                RepeatState.OFF
            }
        }
    }

    fun toggleShuffle() {
        val newShuffle = !_isShuffle.value
        _isShuffle.value = newShuffle
        player.shuffleModeEnabled = newShuffle
    }

    fun setMarkerA() {
        _markerA.value = player.currentPosition
    }

    fun setMarkerB() {
        val cur = player.currentPosition
        val a = _markerA.value ?: 0L
        if (cur > a) {
            _markerB.value = cur
        }
    }

    fun clearABRepeat() {
        _markerA.value = null
        _markerB.value = null
    }

    fun cycleAspectMode() {
        val modes = AspectMode.entries
        val nextOrdinal = (_aspectMode.value.ordinal + 1) % modes.size
        _aspectMode.value = modes[nextOrdinal]
    }

    fun setAspectMode(mode: AspectMode) {
        _aspectMode.value = mode
    }

    fun setAudioDelay(delayMs: Long) {
        _audioDelayMs.value = delayMs
    }

    fun setSubtitleDelay(delayMs: Long) {
        _subtitleDelayMs.value = delayMs
    }

    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerRemainingSeconds.value = null
            return
        }
        _sleepTimerRemainingSeconds.value = minutes * 60
        sleepTimerJob = scope.launch {
            var remaining = minutes * 60
            while (remaining > 0 && isActive) {
                delay(1000L)
                remaining--
                _sleepTimerRemainingSeconds.value = remaining
            }
            if (isActive) {
                pause()
                _sleepTimerRemainingSeconds.value = null
            }
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingSeconds.value = null
    }

    fun appendToQueue(media: MediaModel) {
        val list = _queue.value.toMutableList()
        list.add(media)
        _queue.value = list
    }

    fun playNext(media: MediaModel) {
        val list = _queue.value.toMutableList()
        val insertIndex = (_currentIndex.value + 1).coerceAtMost(list.size)
        list.add(insertIndex, media)
        _queue.value = list
    }

    fun removeFromQueue(index: Int) {
        val list = _queue.value.toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            _queue.value = list
            if (_currentIndex.value >= list.size) {
                _currentIndex.value = (list.size - 1).coerceAtLeast(0)
            }
        }
    }

    private fun handlePlaybackEnded() {
        when (_repeatState.value) {
            RepeatState.ONE -> {
                seekTo(0L)
                play()
            }
            RepeatState.ALL -> next()
            RepeatState.OFF -> {
                if (_currentIndex.value < _queue.value.size - 1) {
                    next()
                } else {
                    _isPlaying.value = false
                }
            }
        }
    }

    private fun saveCurrentPosition(completed: Boolean = false) {
        val media = _currentMedia.value ?: return
        val pos = player.currentPosition
        val dur = player.duration
        scope.launch(Dispatchers.IO) {
            database.historyDao().insertOrUpdate(
                PlaybackHistory(
                    mediaId = media.id,
                    uri = media.uri,
                    title = media.title,
                    artist = media.artist,
                    durationMs = dur,
                    positionMs = if (completed) 0L else pos,
                    lastPlayedTimestamp = System.currentTimeMillis(),
                    isVideo = media.isVideo,
                    completed = completed
                )
            )
        }
    }

    private fun updateTracksList(tracks: Tracks) {
        val audioList = mutableListOf<TrackInfo>()
        val subList = mutableListOf<TrackInfo>()

        for (groupIndex in 0 until tracks.groups.size) {
            val group = tracks.groups[groupIndex]
            val trackType = group.type
            for (trackIndex in 0 until group.length) {
                val format = group.getTrackFormat(trackIndex)
                val isSelected = group.isTrackSelected(trackIndex)
                val trackName = format.label ?: format.language ?: "Track ${trackIndex + 1}"
                val trackInfo = TrackInfo(
                    id = "${groupIndex}_$trackIndex",
                    name = trackName,
                    language = format.language ?: "",
                    isSelected = isSelected,
                    trackGroupIndex = groupIndex,
                    trackIndex = trackIndex
                )
                if (trackType == C.TRACK_TYPE_AUDIO) {
                    audioList.add(trackInfo)
                } else if (trackType == C.TRACK_TYPE_TEXT) {
                    subList.add(trackInfo)
                }
            }
        }
        _audioTracks.value = audioList
        _subtitleTracks.value = subList
    }

    fun selectTrack(trackInfo: TrackInfo, isAudio: Boolean) {
        val trackType = if (isAudio) C.TRACK_TYPE_AUDIO else C.TRACK_TYPE_TEXT
        val tracks = player.currentTracks
        for (group in tracks.groups) {
            if (group.type == trackType) {
                val override = TrackSelectionOverride(
                    group.mediaTrackGroup,
                    listOf(trackInfo.trackIndex)
                )
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(trackType, false)
                    .setOverrideForType(override)
                    .build()
                break
            }
        }
    }

    fun disableSubtitles() {
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()
    }

    fun release() {
        saveCurrentPosition()
        positionTrackerJob?.cancel()
        sleepTimerJob?.cancel()
        player.release()
    }
}
