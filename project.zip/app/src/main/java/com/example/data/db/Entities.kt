package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playback_history")
data class PlaybackHistory(
    @PrimaryKey val mediaId: String,
    val uri: String,
    val title: String,
    val artist: String = "",
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val lastPlayedTimestamp: Long = System.currentTimeMillis(),
    val isVideo: Boolean = true,
    val completed: Boolean = false
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val kind: String = "video", // "video" or "audio"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val playlistId: Long,
    val mediaId: String,
    val uri: String,
    val title: String,
    val artist: String = "",
    val durationMs: Long = 0L,
    val orderIndex: Int = 0,
    val isVideo: Boolean = true
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val mediaId: String,
    val uri: String,
    val title: String,
    val isFolder: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "media_seen")
data class MediaSeenEntity(
    @PrimaryKey val mediaId: String,
    val isSeen: Boolean = true,
    val markedAt: Long = System.currentTimeMillis()
)
