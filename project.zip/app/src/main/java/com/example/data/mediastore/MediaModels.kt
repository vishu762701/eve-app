package com.example.data.mediastore

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MediaItemModel(
    val id: Long,
    val uri: Uri,
    val title: String,
    val displayName: String,
    val artist: String = "",
    val album: String = "",
    val genre: String = "",
    val duration: Long = 0L,
    val size: Long = 0L,
    val dateModified: Long = 0L,
    val mimeType: String = "",
    val folderName: String = "",
    val folderPath: String = "",
    val bucketId: String = "",
    val bucketDisplayName: String = "",
    val isVideo: Boolean = false,
    val width: Int = 0,
    val height: Int = 0,
    val lastPositionMs: Long = 0L,
    val isFavorite: Boolean = false
) {
    val formattedDuration: String
        get() = formatDuration(duration)

    val formattedSize: String
        get() = formatFileSize(size)

    val formattedDate: String
        get() = formatDate(dateModified)

    val resolutionLabel: String
        get() = when {
            height >= 2160 || width >= 3840 -> "4K"
            height >= 1440 || width >= 2560 -> "2K"
            height >= 1080 || width >= 1920 -> "1080p"
            height >= 720 || width >= 1280 -> "720p"
            height >= 480 || width >= 640 -> "480p"
            height > 0 -> "${height}p"
            else -> ""
        }

    val isUnplayed: Boolean
        get() = lastPositionMs == 0L

    companion object {
        fun formatDuration(durationMs: Long): String {
            if (durationMs <= 0) return "00:00"
            val totalSeconds = durationMs / 1000
            val seconds = totalSeconds % 60
            val minutes = (totalSeconds / 60) % 60
            val hours = totalSeconds / 3600
            return if (hours > 0) {
                String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
            }
        }

        fun formatFileSize(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(Locale.getDefault(), "%.1f GB", gb)
                mb >= 1.0 -> String.format(Locale.getDefault(), "%.1f MB", mb)
                kb >= 1.0 -> String.format(Locale.getDefault(), "%.1f KB", kb)
                else -> "$bytes B"
            }
        }

        fun formatDate(timestampSec: Long): String {
            if (timestampSec <= 0) return ""
            val date = Date(timestampSec * 1000)
            val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
            return sdf.format(date)
        }
    }
}

data class MediaFolder(
    val bucketId: String = "",
    val folderName: String,
    val folderPath: String,
    val itemCount: Int,
    val totalSize: Long = 0L,
    val isVideo: Boolean,
    val sampleUri: Uri?
) {
    val formattedSize: String
        get() = MediaItemModel.formatFileSize(totalSize)
}

data class StorageFileItem(
    val file: java.io.File,
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long = 0L,
    val isMedia: Boolean = false,
    val isVideo: Boolean = false,
    val itemCount: Int = 0
) {
    val formattedSize: String
        get() = MediaItemModel.formatFileSize(size)

    fun toMediaItem(): MediaItemModel {
        return MediaItemModel(
            id = path.hashCode().toLong(),
            uri = Uri.fromFile(file),
            title = file.nameWithoutExtension,
            displayName = file.name,
            artist = "Storage",
            size = size,
            mimeType = if (isVideo) "video/*" else "audio/*",
            dateModified = file.lastModified() / 1000,
            isVideo = isVideo
        )
    }
}
