package com.example.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "eve_settings")

enum class AppThemeMode {
    AMOLED, DARK, LIGHT, SYSTEM
}

enum class GroupingMode {
    NAME, FOLDER, NONE
}

enum class ViewMode {
    GRID, LIST
}

enum class SortMode {
    NAME, FILE_NAME, LENGTH, DATE_MODIFIED, INSERTION_DATE
}

enum class ResumeMode {
    ASK, ALWAYS, NEVER
}

data class EveSettings(
    val theme: AppThemeMode = AppThemeMode.AMOLED,
    val groupingMode: GroupingMode = GroupingMode.NAME,
    val viewMode: ViewMode = ViewMode.GRID,
    val sortMode: SortMode = SortMode.NAME,
    val sortAscending: Boolean = true,
    val showThumbnails: Boolean = true,
    val mediaSeenMarking: Boolean = true,
    val incognitoMode: Boolean = false,
    val screenOrientation: String = "SENSOR",
    val resumeMode: ResumeMode = ResumeMode.ASK,
    val hudTimeoutSeconds: Int = 4,
    val showSeekButtons: Boolean = true,
    val jumpAmountSeconds: Int = 10,
    val doubleTapJumpSeconds: Int = 20,
    val fastPlaySpeed: Float = 2.0f,
    val keepScreenOn: Boolean = true,
    val volumeSwipe: Boolean = true,
    val brightnessSwipe: Boolean = true,
    val seekSwipe: Boolean = true,
    val doubleTapSeek: Boolean = true,
    val doubleTapPlayPause: Boolean = true,
    val pinchZoom: Boolean = true,
    val tapAndHoldFastPlay: Boolean = true,
    val threeFingerScreenshot: Boolean = false,
    val audioDucking: Boolean = true,
    val autoLoadSubtitles: Boolean = true,
    val subtitleSizeSp: Float = 18f
)

class SettingsRepository(private val context: Context) {
    private val dataStore = context.dataStore

    private object PreferencesKeys {
        val THEME = stringPreferencesKey("theme")
        val GROUPING_MODE = stringPreferencesKey("grouping_mode")
        val VIEW_MODE = stringPreferencesKey("view_mode")
        val SORT_MODE = stringPreferencesKey("sort_mode")
        val SORT_ASCENDING = booleanPreferencesKey("sort_ascending")
        val SHOW_THUMBNAILS = booleanPreferencesKey("show_thumbnails")
        val MEDIA_SEEN_MARKING = booleanPreferencesKey("media_seen_marking")
        val INCOGNITO_MODE = booleanPreferencesKey("incognito_mode")
        val SCREEN_ORIENTATION = stringPreferencesKey("screen_orientation")
        val RESUME_MODE = stringPreferencesKey("resume_mode")
        val HUD_TIMEOUT_SECONDS = intPreferencesKey("hud_timeout_seconds")
        val SHOW_SEEK_BUTTONS = booleanPreferencesKey("show_seek_buttons")
        val JUMP_AMOUNT_SECONDS = intPreferencesKey("jump_amount_seconds")
        val DOUBLE_TAP_JUMP_SECONDS = intPreferencesKey("double_tap_jump_seconds")
        val FAST_PLAY_SPEED = floatPreferencesKey("fast_play_speed")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val VOLUME_SWIPE = booleanPreferencesKey("volume_swipe")
        val BRIGHTNESS_SWIPE = booleanPreferencesKey("brightness_swipe")
        val SEEK_SWIPE = booleanPreferencesKey("seek_swipe")
        val DOUBLE_TAP_SEEK = booleanPreferencesKey("double_tap_seek")
        val DOUBLE_TAP_PLAY_PAUSE = booleanPreferencesKey("double_tap_play_pause")
        val PINCH_ZOOM = booleanPreferencesKey("pinch_zoom")
        val TAP_AND_HOLD_FAST_PLAY = booleanPreferencesKey("tap_and_hold_fast_play")
        val THREE_FINGER_SCREENSHOT = booleanPreferencesKey("three_finger_screenshot")
        val AUDIO_DUCKING = booleanPreferencesKey("audio_ducking")
        val AUTO_LOAD_SUBTITLES = booleanPreferencesKey("auto_load_subtitles")
        val SUBTITLE_SIZE_SP = floatPreferencesKey("subtitle_size_sp")
    }

    val settingsFlow: Flow<EveSettings> = dataStore.data.map { preferences ->
        EveSettings(
            theme = try {
                AppThemeMode.valueOf(preferences[PreferencesKeys.THEME] ?: AppThemeMode.AMOLED.name)
            } catch (e: Exception) { AppThemeMode.AMOLED },
            groupingMode = try {
                GroupingMode.valueOf(preferences[PreferencesKeys.GROUPING_MODE] ?: GroupingMode.NAME.name)
            } catch (e: Exception) { GroupingMode.NAME },
            viewMode = try {
                ViewMode.valueOf(preferences[PreferencesKeys.VIEW_MODE] ?: ViewMode.GRID.name)
            } catch (e: Exception) { ViewMode.GRID },
            sortMode = try {
                SortMode.valueOf(preferences[PreferencesKeys.SORT_MODE] ?: SortMode.NAME.name)
            } catch (e: Exception) { SortMode.NAME },
            sortAscending = preferences[PreferencesKeys.SORT_ASCENDING] ?: true,
            showThumbnails = preferences[PreferencesKeys.SHOW_THUMBNAILS] ?: true,
            mediaSeenMarking = preferences[PreferencesKeys.MEDIA_SEEN_MARKING] ?: true,
            incognitoMode = preferences[PreferencesKeys.INCOGNITO_MODE] ?: false,
            screenOrientation = preferences[PreferencesKeys.SCREEN_ORIENTATION] ?: "SENSOR",
            resumeMode = try {
                ResumeMode.valueOf(preferences[PreferencesKeys.RESUME_MODE] ?: ResumeMode.ASK.name)
            } catch (e: Exception) { ResumeMode.ASK },
            hudTimeoutSeconds = preferences[PreferencesKeys.HUD_TIMEOUT_SECONDS] ?: 4,
            showSeekButtons = preferences[PreferencesKeys.SHOW_SEEK_BUTTONS] ?: true,
            jumpAmountSeconds = preferences[PreferencesKeys.JUMP_AMOUNT_SECONDS] ?: 10,
            doubleTapJumpSeconds = preferences[PreferencesKeys.DOUBLE_TAP_JUMP_SECONDS] ?: 20,
            fastPlaySpeed = preferences[PreferencesKeys.FAST_PLAY_SPEED] ?: 2.0f,
            keepScreenOn = preferences[PreferencesKeys.KEEP_SCREEN_ON] ?: true,
            volumeSwipe = preferences[PreferencesKeys.VOLUME_SWIPE] ?: true,
            brightnessSwipe = preferences[PreferencesKeys.BRIGHTNESS_SWIPE] ?: true,
            seekSwipe = preferences[PreferencesKeys.SEEK_SWIPE] ?: true,
            doubleTapSeek = preferences[PreferencesKeys.DOUBLE_TAP_SEEK] ?: true,
            doubleTapPlayPause = preferences[PreferencesKeys.DOUBLE_TAP_PLAY_PAUSE] ?: true,
            pinchZoom = preferences[PreferencesKeys.PINCH_ZOOM] ?: true,
            tapAndHoldFastPlay = preferences[PreferencesKeys.TAP_AND_HOLD_FAST_PLAY] ?: true,
            threeFingerScreenshot = preferences[PreferencesKeys.THREE_FINGER_SCREENSHOT] ?: false,
            audioDucking = preferences[PreferencesKeys.AUDIO_DUCKING] ?: true,
            autoLoadSubtitles = preferences[PreferencesKeys.AUTO_LOAD_SUBTITLES] ?: true,
            subtitleSizeSp = preferences[PreferencesKeys.SUBTITLE_SIZE_SP] ?: 18f
        )
    }

    suspend fun setTheme(theme: AppThemeMode) {
        dataStore.edit { it[PreferencesKeys.THEME] = theme.name }
    }

    suspend fun setGroupingMode(mode: GroupingMode) {
        dataStore.edit { it[PreferencesKeys.GROUPING_MODE] = mode.name }
    }

    suspend fun setViewMode(mode: ViewMode) {
        dataStore.edit { it[PreferencesKeys.VIEW_MODE] = mode.name }
    }

    suspend fun setSortMode(mode: SortMode, ascending: Boolean) {
        dataStore.edit {
            it[PreferencesKeys.SORT_MODE] = mode.name
            it[PreferencesKeys.SORT_ASCENDING] = ascending
        }
    }

    suspend fun toggleSortAscending() {
        dataStore.edit {
            val current = it[PreferencesKeys.SORT_ASCENDING] ?: true
            it[PreferencesKeys.SORT_ASCENDING] = !current
        }
    }

    suspend fun setScreenOrientation(orientation: String) {
        dataStore.edit { it[PreferencesKeys.SCREEN_ORIENTATION] = orientation }
    }

    suspend fun setResumeMode(mode: ResumeMode) {
        dataStore.edit { it[PreferencesKeys.RESUME_MODE] = mode.name }
    }

    suspend fun setHudTimeoutSeconds(seconds: Int) {
        dataStore.edit { it[PreferencesKeys.HUD_TIMEOUT_SECONDS] = seconds }
    }

    suspend fun setShowSeekButtons(show: Boolean) {
        dataStore.edit { it[PreferencesKeys.SHOW_SEEK_BUTTONS] = show }
    }

    suspend fun setJumpAmountSeconds(seconds: Int) {
        dataStore.edit { it[PreferencesKeys.JUMP_AMOUNT_SECONDS] = seconds }
    }

    suspend fun setDoubleTapJumpSeconds(seconds: Int) {
        dataStore.edit { it[PreferencesKeys.DOUBLE_TAP_JUMP_SECONDS] = seconds }
    }

    suspend fun setFastPlaySpeed(speed: Float) {
        dataStore.edit { it[PreferencesKeys.FAST_PLAY_SPEED] = speed }
    }

    suspend fun setKeepScreenOn(keep: Boolean) {
        dataStore.edit { it[PreferencesKeys.KEEP_SCREEN_ON] = keep }
    }

    suspend fun setGesture(gestureName: String, enabled: Boolean) {
        dataStore.edit {
            when (gestureName) {
                "volume" -> it[PreferencesKeys.VOLUME_SWIPE] = enabled
                "brightness" -> it[PreferencesKeys.BRIGHTNESS_SWIPE] = enabled
                "seek" -> it[PreferencesKeys.SEEK_SWIPE] = enabled
                "double_tap_seek" -> it[PreferencesKeys.DOUBLE_TAP_SEEK] = enabled
                "double_tap_play_pause" -> it[PreferencesKeys.DOUBLE_TAP_PLAY_PAUSE] = enabled
                "pinch_zoom" -> it[PreferencesKeys.PINCH_ZOOM] = enabled
                "tap_hold_fast_play" -> it[PreferencesKeys.TAP_AND_HOLD_FAST_PLAY] = enabled
                "three_finger_screenshot" -> it[PreferencesKeys.THREE_FINGER_SCREENSHOT] = enabled
            }
        }
    }

    suspend fun setShowThumbnails(show: Boolean) {
        dataStore.edit { it[PreferencesKeys.SHOW_THUMBNAILS] = show }
    }

    suspend fun setMediaSeenMarking(marking: Boolean) {
        dataStore.edit { it[PreferencesKeys.MEDIA_SEEN_MARKING] = marking }
    }

    suspend fun setIncognitoMode(incognito: Boolean) {
        dataStore.edit { it[PreferencesKeys.INCOGNITO_MODE] = incognito }
    }

    suspend fun setAudioDucking(ducking: Boolean) {
        dataStore.edit { it[PreferencesKeys.AUDIO_DUCKING] = ducking }
    }
}
