package com.example.data.model

import java.util.Locale

data class MediaModel(
    val id: String,
    val title: String,
    val uri: String,
    val mimeType: String = "video/mp4",
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val dateModified: Long = 0L,
    val dateAdded: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val bucketId: String = "",
    val bucketName: String = "",
    val artist: String = "",
    val album: String = "",
    val genre: String = "",
    val trackNumber: Int = 0,
    val isVideo: Boolean = true,
    val filePath: String = ""
) {
    val durationFormatted: String
        get() {
            val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            return if (hours > 0) {
                String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }

    val sizeFormatted: String
        get() {
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(Locale.US, "%.1f GB", gb)
                mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
                kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
                else -> "$sizeBytes B"
            }
        }

    val resolutionFormatted: String
        get() {
            return if (width > 0 && height > 0) {
                when {
                    height >= 2160 || width >= 3840 -> "4K"
                    height >= 1080 || width >= 1920 -> "1080p"
                    height >= 720 || width >= 1280 -> "720p"
                    height >= 480 -> "480p"
                    else -> "${width}x${height}"
                }
            } else ""
        }

    /**
     * Extracts group key for Group by Name (PRD 4.1):
     * "videos whose titles start with the same word (ignoring digits, season/episode markers)
     * become one group card ('N videos')"
     */
    val nameGroupKey: String
        get() {
            var cleaned = title.trim()
            // Strip brackets [720p], (2022)
            cleaned = cleaned.replace(Regex("\\[.*?\\]"), "").replace(Regex("\\(.*?\\)"), "").trim()
            // Strip S01E02 or similar patterns
            cleaned = cleaned.replace(Regex("(?i)[sS]\\d+[eE]\\d+.*"), "").trim()
            // Strip trailing digits, episode numbers
            cleaned = cleaned.replace(Regex("[-_.]"), " ").trim()
            val words = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (words.isNotEmpty()) {
                val first = words.first()
                if (first.length > 2) {
                    return first.replaceFirstChar { it.uppercase() }
                }
                if (words.size > 1) {
                    return "${first.uppercase()} ${words[1].replaceFirstChar { it.uppercase() }}"
                }
                return first.replaceFirstChar { it.uppercase() }
            }
            return if (title.isNotBlank()) title.take(1).uppercase() else "#"
        }
}
