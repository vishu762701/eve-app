package com.example.data.media

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.data.model.MediaModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaStoreScanner(private val context: Context) {

    suspend fun scanVideos(): List<MediaModel> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<MediaModel>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.DATA
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
        val queryUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        try {
            context.contentResolver.query(
                queryUri,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleColumn = cursor.getColumnIndex(MediaStore.Video.Media.TITLE)
                val displayNameColumn = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val durationColumn = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val sizeColumn = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val dateModifiedColumn = cursor.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)
                val dateAddedColumn = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val widthColumn = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightColumn = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val bucketIdColumn = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_ID)
                val bucketNameColumn = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val dataColumn = cursor.getColumnIndex(MediaStore.Video.Media.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val title = if (titleColumn >= 0) cursor.getString(titleColumn) ?: "" else ""
                    val displayName = if (displayNameColumn >= 0) cursor.getString(displayNameColumn) ?: "" else ""
                    val duration = if (durationColumn >= 0) cursor.getLong(durationColumn) else 0L
                    val size = if (sizeColumn >= 0) cursor.getLong(sizeColumn) else 0L
                    val dateModified = if (dateModifiedColumn >= 0) cursor.getLong(dateModifiedColumn) else 0L
                    val dateAdded = if (dateAddedColumn >= 0) cursor.getLong(dateAddedColumn) else 0L
                    val width = if (widthColumn >= 0) cursor.getInt(widthColumn) else 0
                    val height = if (heightColumn >= 0) cursor.getInt(heightColumn) else 0
                    val bucketId = if (bucketIdColumn >= 0) cursor.getString(bucketIdColumn) ?: "default" else "default"
                    val bucketName = if (bucketNameColumn >= 0) cursor.getString(bucketNameColumn) ?: "Videos" else "Videos"
                    val filePath = if (dataColumn >= 0) cursor.getString(dataColumn) ?: "" else ""

                    val contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

                    videos.add(
                        MediaModel(
                            id = "video_$id",
                            title = if (title.isNotBlank()) title else displayName.substringBeforeLast("."),
                            uri = contentUri.toString(),
                            mimeType = "video/mp4",
                            durationMs = duration,
                            sizeBytes = size,
                            dateModified = dateModified,
                            dateAdded = dateAdded,
                            width = width,
                            height = height,
                            bucketId = bucketId,
                            bucketName = bucketName,
                            isVideo = true,
                            filePath = filePath
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // If no videos found on device, include default sample media so user can test player features immediately
        if (videos.isEmpty()) {
            videos.addAll(getDemoVideos())
        }

        videos
    }

    suspend fun scanAudio(): List<MediaModel> = withContext(Dispatchers.IO) {
        val audios = mutableListOf<MediaModel>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DATA
        )

        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"
        val queryUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        try {
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
            context.contentResolver.query(
                queryUri,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val displayNameColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val durationColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val sizeColumn = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val dateModifiedColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED)
                val dateAddedColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                val artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val trackColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TRACK)
                val dataColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val title = if (titleColumn >= 0) cursor.getString(titleColumn) ?: "" else ""
                    val displayName = if (displayNameColumn >= 0) cursor.getString(displayNameColumn) ?: "" else ""
                    val duration = if (durationColumn >= 0) cursor.getLong(durationColumn) else 0L
                    val size = if (sizeColumn >= 0) cursor.getLong(sizeColumn) else 0L
                    val dateModified = if (dateModifiedColumn >= 0) cursor.getLong(dateModifiedColumn) else 0L
                    val dateAdded = if (dateAddedColumn >= 0) cursor.getLong(dateAddedColumn) else 0L
                    val artist = if (artistColumn >= 0) cursor.getString(artistColumn) ?: "Unknown Artist" else "Unknown Artist"
                    val album = if (albumColumn >= 0) cursor.getString(albumColumn) ?: "Unknown Album" else "Unknown Album"
                    val track = if (trackColumn >= 0) cursor.getInt(trackColumn) else 0
                    val filePath = if (dataColumn >= 0) cursor.getString(dataColumn) ?: "" else ""

                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

                    audios.add(
                        MediaModel(
                            id = "audio_$id",
                            title = if (title.isNotBlank()) title else displayName.substringBeforeLast("."),
                            uri = contentUri.toString(),
                            mimeType = "audio/mpeg",
                            durationMs = duration,
                            sizeBytes = size,
                            dateModified = dateModified,
                            dateAdded = dateAdded,
                            artist = if (artist == "<unknown>") "Unknown Artist" else artist,
                            album = if (album == "<unknown>") "Unknown Album" else album,
                            trackNumber = track,
                            isVideo = false,
                            filePath = filePath
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // If no audio files found on device, include default sample media for immediate testing
        if (audios.isEmpty()) {
            audios.addAll(getDemoAudios())
        }

        audios
    }

    private fun getDemoVideos(): List<MediaModel> {
        return listOf(
            MediaModel(
                id = "sample_video_1",
                title = "Big Buck Bunny - S01E01 - 1080p",
                uri = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                durationMs = 596000L,
                sizeBytes = 158000000L,
                width = 1920,
                height = 1080,
                bucketId = "sample_downloads",
                bucketName = "Download",
                dateModified = System.currentTimeMillis() / 1000 - 3600,
                isVideo = true
            ),
            MediaModel(
                id = "sample_video_2",
                title = "Big Buck Bunny - S01E02 - 1080p",
                uri = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                durationMs = 596000L,
                sizeBytes = 158000000L,
                width = 1920,
                height = 1080,
                bucketId = "sample_downloads",
                bucketName = "Download",
                dateModified = System.currentTimeMillis() / 1000 - 7200,
                isVideo = true
            ),
            MediaModel(
                id = "sample_video_3",
                title = "Elephants Dream - Open Movie",
                uri = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                durationMs = 653000L,
                sizeBytes = 142000000L,
                width = 1920,
                height = 1080,
                bucketId = "sample_movies",
                bucketName = "Movies",
                dateModified = System.currentTimeMillis() / 1000 - 86400,
                isVideo = true
            ),
            MediaModel(
                id = "sample_video_4",
                title = "For Bigger Blazes - Nature Clip",
                uri = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                durationMs = 15000L,
                sizeBytes = 22000000L,
                width = 1280,
                height = 720,
                bucketId = "sample_camera",
                bucketName = "Camera",
                dateModified = System.currentTimeMillis() / 1000 - 172800,
                isVideo = true
            ),
            MediaModel(
                id = "sample_video_5",
                title = "Tears of Steel - Sci-Fi",
                uri = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                durationMs = 734000L,
                sizeBytes = 230000000L,
                width = 1920,
                height = 1080,
                bucketId = "sample_movies",
                bucketName = "Movies",
                dateModified = System.currentTimeMillis() / 1000 - 259200,
                isVideo = true
            )
        )
    }

    private fun getDemoAudios(): List<MediaModel> {
        return listOf(
            MediaModel(
                id = "sample_audio_1",
                title = "Nocturne in E-flat Major, Op. 9 No. 2",
                uri = "https://storage.googleapis.com/uamp/The_Kyoto_Connection_-_Wake_Up/01_-_Intro_-_ клавиши.mp3",
                artist = "Frédéric Chopin",
                album = "Classical Masterpieces",
                genre = "Classical",
                durationMs = 265000L,
                sizeBytes = 6400000L,
                trackNumber = 1,
                dateModified = System.currentTimeMillis() / 1000 - 10000,
                isVideo = false
            ),
            MediaModel(
                id = "sample_audio_2",
                title = "Clair de Lune",
                uri = "https://storage.googleapis.com/uamp/The_Kyoto_Connection_-_Wake_Up/02_-_Geisha.mp3",
                artist = "Claude Debussy",
                album = "Classical Masterpieces",
                genre = "Classical",
                durationMs = 312000L,
                sizeBytes = 7500000L,
                trackNumber = 2,
                dateModified = System.currentTimeMillis() / 1000 - 20000,
                isVideo = false
            ),
            MediaModel(
                id = "sample_audio_3",
                title = "Midnight Synth Odyssey",
                uri = "https://storage.googleapis.com/uamp/The_Kyoto_Connection_-_Wake_Up/03_-_Voyage_I.mp3",
                artist = "Starlight Theory",
                album = "Neon Horizon",
                genre = "Synthwave",
                durationMs = 240000L,
                sizeBytes = 5800000L,
                trackNumber = 1,
                dateModified = System.currentTimeMillis() / 1000 - 30000,
                isVideo = false
            ),
            MediaModel(
                id = "sample_audio_4",
                title = "Horizon Echoes",
                uri = "https://storage.googleapis.com/uamp/The_Kyoto_Connection_-_Wake_Up/04_-_The_Music_In_You.mp3",
                artist = "Starlight Theory",
                album = "Neon Horizon",
                genre = "Synthwave",
                durationMs = 295000L,
                sizeBytes = 7100000L,
                trackNumber = 2,
                dateModified = System.currentTimeMillis() / 1000 - 40000,
                isVideo = false
            )
        )
    }
}
