EVE / TELEGRAM UI REFERENCE PACK

Contains 25 user-provided screenshots, preserved without visual edits and numbered in upload order.

Index
01. 01_profile_birthday_context_menu.jpg
02. 02_profile_username_context_menu.jpg
03. 03_profile_phone_context_menu.jpg
04. 04_settings_ask_question_dialog.jpg
05. 05_telegram_premium_screen.jpg
06. 06_language_settings.jpg
07. 07_power_saving_settings.jpg
08. 08_data_storage_save_gallery_streaming_proxy.jpg
09. 09_data_storage_usage_auto_download.jpg
10. 10_privacy_security_lower_section.jpg
11. 11_privacy_settings.jpg
12. 12_security_and_privacy_settings.jpg
13. 13_chat_settings_media_sound.jpg
14. 14_chat_settings_app_icon_gesture.jpg
15. 15_chat_settings_chat_list_view.jpg
16. 16_chat_settings_message_size_theme_wallpaper.jpg
17. 17_account_profile_lower_section.jpg
18. 18_account_profile_edit.jpg
19. 19_settings_categories_help.jpg
20. 20_main_settings_screen.jpg
21. 21_profile_qr_fullscreen.jpg
22. 22_profile_overflow_menu.jpg
23. 23_profile_main_screen.jpg
24. 24_chats_list_bottom_navigation.jpg
25. 25_chats_list_search_bar.jpg

Usage notes for implementation:
- Treat these screenshots as visual references for Telegram Android UI patterns: screen composition, spacing, typography, cards, section headers, switches, dialogs, popup menus, navigation, profile surfaces, QR presentation, and chat-list presentation.
- Inspect the images directly; do not rely only on filenames or this index.
- Do not hardcode sample identity/contact data visible in the screenshots (names, phone numbers, usernames, email fragments, channel data, QR contents). Bind EVE UI to the actual authenticated account and real app data.
- These 25 images are not an exhaustive specification of every EVE exam screen. For screens without a matching screenshot, use the pinned Telegram Android source and existing EVE product requirements/code as references.
- The screenshots are visual references, not authorization to add unrelated Telegram services/features (for example Telegram Premium billing, Telegram Stars, messaging, channels, or proxy infrastructure) unless the EVE product already requires them.
